-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : mar. 19 mai 2026 à 17:15
-- Version du serveur : 8.0.45-0ubuntu0.24.04.1
-- Version de PHP : 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `s171768_db1778784925691`
--

-- --------------------------------------------------------

--
-- Structure de la table `anticheat_settings`
--

CREATE TABLE `anticheat_settings` (
  `ac_code` int NOT NULL,
  `ac_code_trigger_type` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `anticheat_settings`
--

INSERT INTO `anticheat_settings` (`ac_code`, `ac_code_trigger_type`) VALUES
(0, 2),
(1, 2),
(2, 1),
(3, 2),
(4, 1),
(5, 2),
(6, 1),
(7, 2),
(8, 2),
(9, 2),
(10, 2),
(11, 0),
(12, 2),
(13, 0),
(14, 2),
(15, 2),
(16, 2),
(17, 2),
(18, 1),
(19, 1),
(20, 1),
(21, 0),
(22, 1),
(23, 1),
(24, 2),
(25, 1),
(26, 2),
(27, 0),
(28, 0),
(29, 1),
(30, 2),
(31, 2),
(32, 2),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 2),
(38, 1),
(39, 2),
(40, 0),
(41, 0),
(42, 2),
(43, 2),
(44, 2),
(45, 2),
(46, 2),
(47, 1),
(48, 0),
(49, 0),
(50, 0),
(51, 2),
(52, 0);

-- --------------------------------------------------------

--
-- Structure de la table `atms`
--

CREATE TABLE `atms` (
  `id` int NOT NULL,
  `pos_x` float DEFAULT NULL,
  `pos_y` float DEFAULT NULL,
  `pos_z` float DEFAULT NULL,
  `pos_r` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `bans`
--

CREATE TABLE `bans` (
  `id` int NOT NULL,
  `username` varchar(24) DEFAULT NULL,
  `ip` varchar(16) DEFAULT NULL,
  `bannedby` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `permanent` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `billboards`
--

CREATE TABLE `billboards` (
  `id` int NOT NULL,
  `text` int DEFAULT NULL,
  `rentby` int NOT NULL DEFAULT '0',
  `rentdate` int NOT NULL DEFAULT '0',
  `cost` int NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `posRX` float NOT NULL DEFAULT '0',
  `posRY` float NOT NULL DEFAULT '0',
  `posRZ` float NOT NULL DEFAULT '0',
  `int` int NOT NULL DEFAULT '0',
  `vw` int NOT NULL DEFAULT '0',
  `model` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `businesses`
--

CREATE TABLE `businesses` (
  `id` int NOT NULL,
  `ownerid` int DEFAULT '0',
  `owner` varchar(24) DEFAULT 'Nobody',
  `name` varchar(64) DEFAULT 'Unamed Business',
  `message` varchar(128) DEFAULT 'Welcome to the business!',
  `type` tinyint DEFAULT '0',
  `price` int DEFAULT '0',
  `entryfee` int DEFAULT '0',
  `locked` tinyint(1) DEFAULT '1',
  `timestamp` int DEFAULT '0',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `int_x` float DEFAULT '0',
  `int_y` float DEFAULT '0',
  `int_z` float DEFAULT '0',
  `int_a` float DEFAULT '0',
  `interior` tinyint DEFAULT '0',
  `world` int DEFAULT '0',
  `outsideint` tinyint DEFAULT '0',
  `outsidevw` int DEFAULT '0',
  `cash` int DEFAULT '0',
  `products` int DEFAULT '500',
  `robbed` smallint NOT NULL DEFAULT '3',
  `robbing` int DEFAULT NULL,
  `prices0` int NOT NULL DEFAULT '0',
  `prices1` int NOT NULL DEFAULT '0',
  `prices2` int NOT NULL DEFAULT '0',
  `prices3` int NOT NULL DEFAULT '0',
  `prices4` int NOT NULL DEFAULT '0',
  `prices5` int NOT NULL DEFAULT '0',
  `prices6` int NOT NULL DEFAULT '0',
  `prices7` int NOT NULL DEFAULT '0',
  `prices8` int NOT NULL DEFAULT '0',
  `prices9` int NOT NULL DEFAULT '0',
  `prices10` int NOT NULL DEFAULT '0',
  `prices11` int NOT NULL DEFAULT '0',
  `prices12` int NOT NULL DEFAULT '0',
  `prices13` int NOT NULL DEFAULT '0',
  `prices14` int NOT NULL DEFAULT '0',
  `prices15` int NOT NULL DEFAULT '0',
  `prices16` int NOT NULL DEFAULT '0',
  `prices17` int NOT NULL DEFAULT '0',
  `prices18` int NOT NULL DEFAULT '0',
  `prices19` int NOT NULL DEFAULT '0',
  `prices20` int NOT NULL DEFAULT '0',
  `prices21` int NOT NULL DEFAULT '0',
  `prices22` int NOT NULL DEFAULT '0',
  `prices23` int NOT NULL DEFAULT '0',
  `prices24` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `changes`
--

CREATE TABLE `changes` (
  `slot` tinyint DEFAULT NULL,
  `text` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `charges`
--

CREATE TABLE `charges` (
  `id` int NOT NULL,
  `uid` int DEFAULT NULL,
  `chargedby` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `reason` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `clothing`
--

CREATE TABLE `clothing` (
  `id` int NOT NULL,
  `uid` int DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `modelid` smallint DEFAULT NULL,
  `boneid` tinyint DEFAULT NULL,
  `attached` tinyint(1) DEFAULT NULL,
  `pos_x` float DEFAULT NULL,
  `pos_y` float DEFAULT NULL,
  `pos_z` float DEFAULT NULL,
  `rot_x` float DEFAULT NULL,
  `rot_y` float DEFAULT NULL,
  `rot_z` float DEFAULT NULL,
  `scale_x` float DEFAULT NULL,
  `scale_y` float DEFAULT NULL,
  `scale_z` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `divisions`
--

CREATE TABLE `divisions` (
  `id` tinyint DEFAULT NULL,
  `divisionid` tinyint DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `entrances`
--

CREATE TABLE `entrances` (
  `id` int NOT NULL,
  `ownerid` int DEFAULT '0',
  `owner` varchar(24) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `iconid` smallint DEFAULT '1239',
  `locked` tinyint(1) DEFAULT '0',
  `radius` float DEFAULT '3',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `int_x` float DEFAULT '0',
  `int_y` float DEFAULT '0',
  `int_z` float DEFAULT '0',
  `int_a` float DEFAULT '0',
  `interior` tinyint DEFAULT '0',
  `world` int DEFAULT '0',
  `outsideint` tinyint DEFAULT '0',
  `outsidevw` int DEFAULT '0',
  `adminlevel` tinyint DEFAULT '0',
  `factiontype` tinyint DEFAULT '0',
  `vip` tinyint DEFAULT '0',
  `vehicles` tinyint(1) DEFAULT '0',
  `freeze` tinyint(1) DEFAULT '0',
  `password` varchar(64) DEFAULT 'None',
  `label` tinyint(1) DEFAULT '1',
  `mapicon` tinyint NOT NULL DEFAULT '-1',
  `color` int NOT NULL DEFAULT '-256'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `entrances`
--

INSERT INTO `entrances` (`id`, `ownerid`, `owner`, `name`, `iconid`, `locked`, `radius`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `int_x`, `int_y`, `int_z`, `int_a`, `interior`, `world`, `outsideint`, `outsidevw`, `adminlevel`, `factiontype`, `vip`, `vehicles`, `freeze`, `password`, `label`, `mapicon`, `color`) VALUES
(2, 0, NULL, 'Los Santos Dmv', 1318, 0, 3, 1773.73, -1706.78, 13.565, 177.747, -2039.2, -134.043, -50.914, 356.771, 1, 0, 0, 0, 0, 0, 0, 0, 1, 'None', 1, 53, 11184895),
(4, 0, NULL, 'FBI Los Santos', 1318, 0, 3, 326.448, -1513.64, 36.039, 55.323, 246.938, 62.34, 1003.64, 11.913, 6, 4000004, 0, 0, 0, 6, 0, 0, 0, 'None', 1, 20, -256),
(6, 2858, 'Piter_Xvilo', 'Golden City Hall', 1318, 0, 3, 1481.16, -1772.19, 18.789, 359.815, -2171.34, -496.527, -50.85, 270, 0, 4000029, 0, 0, 0, 0, 0, 0, 1, 'None', 1, 35, 178957055),
(9, 0, NULL, 'HOSPITAL LOS-SANOTS', 1314, 0, 3, 1172.12, -1323.48, 15.402, 93.191, 375.087, -106.955, 1013.03, 3.281, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'None', 1, 22, -256),
(13, 0, NULL, 'Grove Street HQ', 1313, 0, 3, 2495.52, -1691.14, 14.766, -32.762, 2323.94, -1147.75, 1050.7, 2.486, 12, 4000013, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 62, -256),
(15, 0, NULL, 'Ballas HQ', 1313, 0, 3, 2233.29, -1159.99, 25.891, 175.301, 2214.39, -1150.69, 1025.8, 294.206, 15, 4000015, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 59, -256),
(16, 1494, 'AZIZ_LFERDA', 'MR7BA BEK', 1313, 0, 3, 2770.74, -1628.68, 12.172, 24.123, 1727.33, -1638.08, 20.219, 177.463, 18, 4000016, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 60, -256),
(20, 0, NULL, 'Los Santos Bank', 1318, 0, 3, 597.754, -1249.41, 18.312, 155.173, 1667.33, -996.004, 683.691, 19.263, 0, 4000020, 0, 0, 0, 0, 0, 0, 1, 'None', 1, 52, -256),
(22, 0, NULL, 'DROGS', 19132, 0, 3, 51.782, -293.662, 1.704, -179.444, 2531.32, -1282.07, 1048.29, 267.468, 2, 4000022, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 12, -256),
(25, 1214, 'BANKAI_DESANTA', 'MAHKAMA', 1247, 0, 3, 1720.22, -1741.17, 13.547, -4.641, -2029.47, 1019.39, 1418.5, 277.87, 0, 4000025, 0, 0, 0, 0, 0, 0, 1, 'None', 1, 20, -256),
(29, 0, NULL, 'Los Hotel', 1313, 0, 3, 1411.43, -1699.72, 13.547, 54.626, 940.874, -18.984, 1000.93, 7.817, 3, 4000029, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 3, -256),
(31, 0, 'Nobody', 'LS VARIOS', 1313, 0, 3, 2151.04, -1789.22, 13.508, 98.589, 315.363, -143.35, 999.602, 203.039, 7, 4000031, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 61, -256),
(40, 0, NULL, 'Golden Casino', 1918, 0, 3, 1462.7, -1010.61, 26.844, 56.673, 1133.46, -15.838, 1000.68, 343.537, 12, 4000040, 0, 0, 0, 0, 0, 0, 1, 'None', 1, 25, -256),
(42, 1964, 'Alfredo_boneli', '[LS] YAKUZA', 1313, 0, 3, 1004.39, -1430.84, 13.547, -172.974, 1132.88, -15.837, 1000.68, 341.063, 12, 4000042, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 19, -256),
(43, 0, NULL, 'HQ ARMY', 1247, 0, 3, 919.468, -1252.19, 16.211, 91.072, 288.744, 167.015, 1007.17, 353.671, 3, 4000043, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(44, 0, NULL, 'TELEPORT LS', 19135, 0, 3, 130.847, -70.865, 1.578, 155.627, 1479.39, -1673.58, 14.047, 175.45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(45, 0, NULL, 'EXIT', 1240, 0, 3, 1266.56, -1291.59, 1061.15, -99.696, 1172.08, -1323.14, 15.403, 250.206, 0, 0, 1, 1, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(47, 0, NULL, 'EXIT TO ALLSAINTS', 1240, 0, 3, 1266.55, -1291.46, 1061.15, -85.72, 1172.12, -1323.45, 14.982, 270.52, 0, 0, 1, 2, 0, 0, 0, 0, 1, 'None', 1, -1, -256),
(52, 0, NULL, 'EXIT TO ALLSAINTS', 1240, 0, 3, 1425.59, 1469.52, 1010.91, 169.78, 1178.99, -1323.57, 14.147, 267.803, 0, 0, 1, 1, 0, 0, 0, 0, 1, 'None', 1, -1, -256),
(53, 0, NULL, 'EXIT TO ALLSAINTS', 1240, 0, 3, 1425.68, 1469.52, 1010.91, -170.347, 1179.55, -1323.47, 14.175, 270, 0, 0, 1, 2, 0, 0, 0, 0, 1, 'None', 1, -1, -256),
(55, 0, NULL, 'GOLDEN FOR LIFE < 3', 1232, 0, 3, -1430.41, -300.715, 14, -36.179, 0, 0, 0, 0, 0, 4000055, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(56, 0, NULL, 'test hna', 1239, 0, 3, -1380.94, -369.775, 14.148, 99.209, 0, 0, 0, 0, 0, 4000056, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(57, 0, NULL, 'lma9bolin hnaya', 1239, 0, 3, -1381.33, -401.721, 14.148, -9.245, 226.297, 1114.37, 1080.98, 99.347, 5, 4000057, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(59, 0, NULL, 'STNA YJI POLICE ILA BKHITI TCHRI [ Driv', 1239, 0, 3, -554.882, 1793.24, 1393.3, 175.773, 0, 0, 0, 0, 0, 4000059, 0, 4000034, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(67, 0, NULL, 'BLAST TSFIYAT L7ISABAT', 1239, 0, 3, 1534.42, -1474.1, 9.5, -99.794, 0, 0, 0, 0, 0, 4000067, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(68, 0, NULL, 'gangs', 1239, 0, 3, 1369.36, -38.473, 1000.92, -152.877, 0, 0, 0, 0, 0, 4000068, 1, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(69, 0, NULL, 'gangs', 1239, 0, 3, 1401.42, -39.102, 1000.91, 105.639, 1260.73, -785.705, 1091.91, 251.273, 5, 4000069, 1, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(71, 1214, 'BANKAI_AKERMAN', 'factions', 1239, 0, 3, 1370.66, -10.106, 1000.92, -72.935, 0, 0, 0, 0, 0, 4000071, 1, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(72, 0, NULL, 'CENE GOLDEN RP', 1239, 0, 3, 1388.79, -22.183, 1000.91, -10.801, 0, 0, 0, 0, 0, 4000072, 1, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(75, 0, NULL, '/fixvw', 1239, 0, 3, 1184.44, -1322.97, 13.569, 86.708, 0, 0, 0, 0, 0, 4000075, 0, 4000074, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(78, 0, NULL, '/fixvw', 1239, 0, 3, 1590.74, -1644.71, 12.051, -11.717, 0, 0, 0, 0, 0, 4000078, 0, 4000076, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(79, 0, NULL, '/fixvw', 1239, 0, 3, 1586.85, -1644.65, 12.074, -103.671, 0, 0, 0, 0, 0, 4000079, 0, 4000076, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(82, 0, NULL, 'DRUGS SUMILAOR', 1239, 0, 3, 631.971, -2375.68, 3.048, 14.448, 2564.19, -1281.43, 1048.29, 80.636, 2, 4000082, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(85, 1765, 'Youssef_Lhaj', 'Los Santos LACAMORA', 1313, 0, 3, 1833.82, -1125.79, 24.68, 73.778, 2214.39, -1150.8, 1025.8, 265.726, 15, 4000085, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 42, -256),
(86, 1279, 'JO9LI__BACK', 'Los Santos Rifa', 1313, 0, 3, 2793.04, -1087.54, 30.719, -81.324, 1702.58, -1667.75, 20.219, 347.301, 18, 4000086, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 40, -256),
(89, 0, NULL, 'EXIT', 1239, 0, 3, 1161.6, -1328.93, 1019.41, 0.361, 1187.18, -1323.9, 13.583, 212.941, 0, 0, 1, 1, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(90, 0, NULL, 'EXIT', 1318, 0, 3, 1161.31, -1328.98, 1019.41, 1.456, 1196, -1326.27, 13.398, 263.783, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(91, 0, NULL, '!', 1239, 0, 3, 1861.26, 2019.34, 7.595, -179.16, 0, 0, 0, 0, 0, 4000091, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(92, 0, NULL, 'EXIT GROVE', 19299, 0, 3, 2324.48, -1149.55, 1050.7, -2.075, 0, 0, 0, 0, 0, 4000092, 12, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(94, 0, NULL, 'GOLDEN 4 LIFE [GLD4LIFE]', 1232, 0, 3, 1720.29, 1399.3, 10.492, -49.985, 0, 0, 0, 0, 0, 4000094, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(95, 0, NULL, 'BLACK.       MAFIA', 1313, 0, 3, 1122.71, -2037.14, 69.894, -86.574, 2324.47, -1149.55, 1050.71, 166.643, 12, 4000095, 0, 0, 0, 0, 0, 0, 0, '2006', 1, -1, -256),
(96, 0, NULL, 'OPEN', 1239, 0, 3, 1587.74, -1635.87, 13.383, 196.231, 1530.6, -1679.71, 5.891, 56.678, 0, 2, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(97, 0, NULL, 'Mafia', 1239, 0, 3, 2018.14, 1918, 12.343, -107.459, 2228.37, -1150.59, 1025.8, 74.468, 15, 4000097, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(98, 0, NULL, 'BLAST I3DAM', 1239, 0, 3, 2539.03, -1630.94, 13.571, 126.608, 2539.21, -1631.15, 13.578, 2.459, 0, 4000098, 0, 0, 7, 0, 0, 0, 0, 'GG', 1, -1, -256),
(99, 0, NULL, 'HQ', 1239, 0, 3, -382.97, -1426.2, 26.316, -75.43, 0, 0, 0, 0, 0, 4000099, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(101, 0, NULL, 'Allsints V2', 1318, 0, 3, 2033.67, -1401.79, 17.289, 152.887, 0, 0, 0, 0, 0, 4000101, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(102, 0, NULL, 'JUST FOR MAFIA', 1239, 0, 3, 1251.39, -2022.16, 59.67, -56.584, 0, 0, 0, 0, 0, 4000102, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(103, 0, NULL, 'LS    BICKERS', 1313, 0, 3, 952.572, -909.648, 45.766, -173.423, 2270.42, -1210.71, 1047.56, 218.836, 10, 4000103, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(104, 0, NULL, 'Governomnt', 1318, 0, 3, 626.966, -571.674, 17.915, -82.127, 1298.87, -796.205, 1084.01, 0, 5, 4000104, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(105, 0, NULL, 'BLASAT TADRIB <3', 1239, 0, 3, 610.778, -583.496, 18.211, -173.772, 287.975, 2537.06, 16.817, 169.45, 0, 4000105, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(106, 0, NULL, 'sat una sola jail', 1239, 0, 3, 1978.59, -2180.04, 13.547, 18.495, 0, 0, 0, 0, 0, 4000106, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(107, 0, NULL, 'EXIT', 1239, 0, 3, 2279.67, -1666.08, 3001.09, 97.811, 1179.55, -1323.47, 14.175, 270, 0, 4000107, 1, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(108, 0, NULL, 'BLACK    MAFIA', 1313, 0, 3, 610.415, -2355.76, 3.048, 1.158, 1727.03, -1637.83, 20.219, 346.347, 18, 4000108, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(109, 0, NULL, 'KOLCHI YGLS', 1239, 0, 3, 285.567, 187.415, 1007.17, -7.645, 0, 0, 0, 0, 0, 4000109, 3, 4000034, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(110, 0, NULL, 'EXIT', 1239, 0, 3, 1534.37, -1672.31, 5.891, 5.292, 1537.75, -1674.44, 13.547, 87.047, 0, 0, 0, 2, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(111, 0, NULL, 'Grove Street House ', 1242, 0, 3, 2513.7, -1650.22, 14.356, 133.592, 2468.84, -1698.45, 1013.51, 74.894, 2, 4000111, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(115, 0, NULL, 'CASPER___ MIKO', 1239, 0, 3, 1548.38, -1363.74, 326.211, 146.385, 2237.59, -1081.64, 1049.02, 181.077, 2, 4000115, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 43, -256),
(116, 0, NULL, 'RichMan', 19132, 0, 3, 315.668, -1139.13, 81.593, -49.62, 975.322, -8.87, 1001.15, 101.006, 3, 4000116, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(119, 0, NULL, '/FIXVW', 1239, 0, 3, 1793.27, -1564.79, 22.929, -158.409, 0, 0, 0, 0, 0, 4000119, 0, 4000118, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(120, 0, NULL, '[LS] Gouvernement', 1239, 0, 3, 1016.83, -1122.85, 23.862, 12.025, 0, 0, 0, 0, 0, 4000120, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(121, 106, 'ZETSU_XVILO', '7OKOMA', 1247, 0, 3, 1017.52, -1090.43, 23.862, -176.874, 288.887, 166.923, 1007.17, 8.611, 3, 4000121, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 30, -256),
(122, 1214, 'BANKAI_LA_RUE_T.C', 'Los Santos Varios', 1313, 0, 3, 2787.07, -1926.07, 13.547, 92.392, 1260.65, -785.211, 1091.91, 263.789, 5, 4000122, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 58, -256),
(124, 2492, '_BRAZELI_BRZ_', 'FAVELAS (BRZ)', 1313, 0, 3, 2218.73, -1053.42, 46.007, -134.071, 2214.4, -1150.53, 1025.8, 266.562, 15, 4000124, 0, 0, 0, 0, 0, 0, 0, 'BRZ', 1, 6, -256),
(125, 435, 'RINIO_', 'YAKHUZA', 1313, 0, 3, 2522.76, -2018.98, 14.074, 44.893, 2468.84, -1698.15, 1013.51, 78.92, 2, 4000125, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 43, -256),
(126, 0, NULL, 'XVILO', 1313, 0, 3, 502.796, -1930.68, 9.078, -3.563, 234.158, 1063.72, 1084.21, 202.521, 6, 4000126, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(127, 0, NULL, 'disco titan', 1580, 0, 3, 824.288, -849.544, 69.921, 15.176, 1204.82, -13.852, 1000.92, 332.068, 2, 4000127, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(129, 0, NULL, '/GETKV ILA BGHITI  T3MR DIR3 O DAM', 1239, 0, 3, 2224.27, -1153.89, 1025.8, 83.149, 0, 0, 0, 0, 0, 4000129, 15, 4000085, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(130, 0, NULL, '/GETKV ILA BGHITI  T3MR DIR3 O DAM', 1239, 0, 3, 2226.01, -1148.6, 1025.8, 105.058, 0, 0, 0, 0, 0, 4000130, 15, 4000015, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(131, 0, NULL, '/GETKV ILA BGHITI  T3MR DIR3 O DAM', 1239, 0, 3, 1700.69, -1665.11, 20.219, -89.054, 0, 0, 0, 0, 0, 4000131, 18, 4000016, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(132, 0, NULL, 'GOTO LV', 1232, 0, 3, 1480.6, -1673.61, 14.047, -176.863, 1670.69, 1423.52, 10.785, 270, 0, 4000132, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(133, 0, NULL, 'test', 1239, 0, 3, -1430.36, -289.622, 14.148, -116.538, 0, 0, 0, 0, 0, 4000133, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(134, 2492, '_BRAZELI_BRZ_', 'FAVELAS HOUSE', 1242, 0, 3, 2288.2, -1104.65, 38.597, 165.332, 1260.72, -785.892, 1091.91, 275.277, 5, 4000134, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(136, 0, NULL, 'Surface', 1239, 0, 3, -2447.71, 523.174, 30.367, 111.746, -2456.19, 521.787, 51.064, 91.319, 0, 4000136, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(137, 0, NULL, 'GOLDEN HAWAYAAAA', 1509, 0, 3, -1427.59, -296.924, 14, 17.442, -1427.94, -296.203, 14, 345.388, 0, 199, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(138, 0, NULL, 'HQ VENOM', 1318, 0, 3, 854.419, -605.071, 18.422, 168.752, 2214.46, -1150.6, 1025.8, 272.08, 15, 4000138, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 59, -256),
(139, 0, NULL, '/GETKV BACH T3AMA ARMOR O HEALTH', 1239, 0, 3, 2228.43, -1148.8, 1025.8, 100.897, 0, 0, 0, 0, 0, 4000139, 15, 4000138, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(140, 0, NULL, 'HQ MAFIA ', 1254, 0, 3, -2521.19, -624.952, 132.782, 3.468, 1298.87, -796.205, 1084.01, 0, 5, 4000140, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(141, 0, NULL, 'HELECO', 1239, 0, 3, -2506.04, -677.499, 139.32, 270.642, -2515.53, -679.831, 147.906, 86.735, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(142, 0, NULL, 'HABS BICKERS', 1543, 0, 3, 952.088, -892.021, 46.251, -93.776, 322.004, 302.701, 999.148, 356.12, 5, 4000142, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(143, 0, NULL, 'GLD4LIFE', 1239, 0, 3, 2105.49, -1806.5, 13.555, 77.954, 2105.49, -1806.5, 13.555, 257.954, 0, 4000143, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(144, 0, NULL, 'Desco Sense', 1241, 0, 3, 167.68, -1308.28, 70.351, 279.124, 1204.97, -13.153, 1000.92, 170.306, 2, 4000144, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(145, 0, NULL, 'FAVELAS NAFA9', 1242, 0, 3, 1217.22, -1692.54, 19.734, -94.674, 774.298, -50.47, 1000.59, 349.549, 6, 4000145, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, -256),
(146, 620, 'Lorenzo_Mp3', 'PARK MP3 FOR CARS - HOUSE - BIZ', 1274, 0, 3, 333.51, -1796.87, 4.741, -1.525, 0, 0, 0, 0, 0, 100000, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 11184895),
(147, 0, NULL, 'LSPD', 1239, 0, 3, 1555.5, -1675.46, 16.195, 5.156, 1513.56, -2882.98, 1586.5, 359.528, 0, 4000147, 0, 0, 0, 0, 0, 0, 1, 'None', 1, -1, -256);

-- --------------------------------------------------------

--
-- Structure de la table `factionlockers`
--

CREATE TABLE `factionlockers` (
  `id` int NOT NULL,
  `factionid` int NOT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL,
  `interior` int NOT NULL,
  `world` int NOT NULL,
  `iconid` int NOT NULL DEFAULT '1239',
  `label` int NOT NULL DEFAULT '1',
  `weapon_kevlar` int NOT NULL DEFAULT '1',
  `weapon_medkit` int NOT NULL DEFAULT '1',
  `weapon_nitestick` int NOT NULL DEFAULT '0',
  `weapon_mace` int NOT NULL DEFAULT '0',
  `weapon_deagle` int NOT NULL DEFAULT '1',
  `weapon_shotgun` int NOT NULL DEFAULT '1',
  `weapon_mp5` int NOT NULL DEFAULT '1',
  `weapon_m4` int NOT NULL DEFAULT '1',
  `weapon_spas12` int NOT NULL DEFAULT '1',
  `weapon_sniper` int NOT NULL DEFAULT '1',
  `weapon_camera` int NOT NULL DEFAULT '0',
  `weapon_fire_extinguisher` int NOT NULL DEFAULT '0',
  `weapon_painkillers` int NOT NULL DEFAULT '0',
  `price_kevlar` int NOT NULL DEFAULT '100',
  `price_medkit` int NOT NULL DEFAULT '50',
  `price_nitestick` int NOT NULL DEFAULT '0',
  `price_mace` int NOT NULL DEFAULT '0',
  `price_deagle` int NOT NULL DEFAULT '850',
  `price_shotgun` int NOT NULL DEFAULT '1000',
  `price_mp5` int NOT NULL DEFAULT '1500',
  `price_m4` int NOT NULL DEFAULT '2500',
  `price_spas12` int NOT NULL DEFAULT '3500',
  `price_sniper` int NOT NULL DEFAULT '5000',
  `price_camera` int NOT NULL DEFAULT '0',
  `price_fire_extinguisher` int NOT NULL DEFAULT '0',
  `price_painkillers` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `factionlockers`
--

INSERT INTO `factionlockers` (`id`, `factionid`, `pos_x`, `pos_y`, `pos_z`, `interior`, `world`, `iconid`, `label`, `weapon_kevlar`, `weapon_medkit`, `weapon_nitestick`, `weapon_mace`, `weapon_deagle`, `weapon_shotgun`, `weapon_mp5`, `weapon_m4`, `weapon_spas12`, `weapon_sniper`, `weapon_camera`, `weapon_fire_extinguisher`, `weapon_painkillers`, `price_kevlar`, `price_medkit`, `price_nitestick`, `price_mace`, `price_deagle`, `price_shotgun`, `price_mp5`, `price_m4`, `price_spas12`, `price_sniper`, `price_camera`, `price_fire_extinguisher`, `price_painkillers`) VALUES
(2, 1, 672.493, 2537.88, -89.451, 0, 4000005, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(4, 5, 919.424, -1266.02, 15.172, 0, 0, 1247, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(5, 2, -1092.77, -943.511, 689.419, 1, 0, 11738, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(6, 6, -2029, 1000.31, 1419.5, 0, 4000025, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(10, 7, 293.357, 187.558, 1007.17, 3, 4000004, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(13, 1, 300.721, 187.481, 1007.17, 3, 4000034, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(17, 3, 1287.89, -772.745, 1082.18, 5, 1000370, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(19, 6, 1260.49, -795.666, 1084.23, 5, 4000104, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(21, 2, 2266.26, -1666.32, 3001.09, 1, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(23, 2, 616.944, -124.281, 997.992, 3, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(24, 6, 300.704, 187.589, 1007.17, 3, 4000121, 1242, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(25, 7, 256.982, 65.639, 1003.64, 6, 4000004, 1242, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(28, 1, 1600.72, -1669.44, 14.504, 0, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(29, 5, 300.97, 187.892, 1007.17, 3, 4000043, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(30, 5, 65.812, -1533.99, 5.197, 0, 0, 1247, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(31, 4, 1122.7, -1341.01, 13.857, 0, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(32, 4, 1115.87, -1341.28, 13.857, 0, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(36, 3, 2135.06, -1786.39, 13.519, 0, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(37, 6, -557.53, -504.215, 24.701, 0, 0, 1313, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `factionpay`
--

CREATE TABLE `factionpay` (
  `id` tinyint DEFAULT NULL,
  `rank` tinyint DEFAULT NULL,
  `amount` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `factionranks`
--

CREATE TABLE `factionranks` (
  `id` tinyint DEFAULT NULL,
  `rank` tinyint DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `factionranks`
--

INSERT INTO `factionranks` (`id`, `rank`, `name`) VALUES
(1, 5, 'OFFICER 3'),
(2, 0, 'STAGER'),
(2, 1, 'normal medic'),
(2, 2, 'Profesional Medic'),
(2, 3, 'Docteur'),
(2, 4, 'DEPUTY CHEF'),
(2, 5, 'CHEF MEDIC'),
(5, 5, 'GENERAL CHEF ARMY'),
(5, 4, 'UNDER CHEF ARMY'),
(5, 3, 'Colonel'),
(5, 2, 'Sergeant Chef'),
(5, 1, 'Sergeant'),
(5, 0, 'Cadet'),
(4, 0, 'STAGER'),
(4, 1, 'NEW MEMBRE'),
(4, 3, '7RAYEFI'),
(4, 4, 'AUTOUMOUBILISTE'),
(4, 5, 'FIXEUR MOTEUR'),
(1, 4, 'OFFICER 2'),
(3, 0, 'Team Terrorist'),
(3, 1, 'Team Terrorist'),
(3, 2, 'Team Terrorist'),
(3, 4, 'CO Chef Terrorist'),
(3, 5, 'Chef Terrorist'),
(3, 3, 'Team Terrorist'),
(1, 3, 'OFFICER 1'),
(7, 0, '_STAGER_'),
(7, 5, 'LEADER AND FBI'),
(7, 4, 'AGENT SPECIALE'),
(7, 3, 'AGENT DE MISSION'),
(7, 2, 'FBI MASQUER'),
(7, 1, 'DEBUTEUR'),
(4, 2, 'DEBUTEUR MECANO'),
(1, 0, 'NEW MEMBER'),
(1, 1, 'POLICE '),
(1, 2, 'CADET 2'),
(4, 6, 'MECANO PREPARATION'),
(4, 7, 'SPECIALE MECANO'),
(4, 8, 'CARRENAGEUR'),
(1, 6, 'LIUETEMENT 1'),
(1, 7, 'LIEUTEMENT 2'),
(1, 8, 'LIEUTEMENT 3'),
(1, 9, 'DIRECTEUR 1'),
(1, 10, 'DIRECTEUR 2'),
(1, 11, 'DIRECTEUR 3'),
(1, 12, 'COMISER'),
(1, 13, 'DEPUTY CHEF 1'),
(1, 14, 'CO CHEF [LSPD]'),
(1, 15, 'CHEF LSPD'),
(6, 0, 'Team Terrorist'),
(6, 1, 'Team Terrorist'),
(6, 2, 'Team Terrorist'),
(6, 3, 'Team Terrorist'),
(6, 4, 'Team Terrorist'),
(6, 5, 'Co Chef Terrorist'),
(6, 6, 'Chef Terrorist'),
(6, 7, 'BodyGuard'),
(6, 8, 'DABIT MOMTAZ'),
(6, 9, '3A9ID'),
(6, 10, '3A9ID AWAL'),
(6, 11, '3A9ID MOMTAZ'),
(6, 12, 'NA2IB 7AKIM '),
(6, 13, 'NA2IB 7AKIM NADI'),
(6, 14, 'AL7AKIM'),
(4, 9, 'MECANO DE OMPAN'),
(4, 10, 'ANCIEN MEMBRE'),
(4, 11, 'DERICTEUR BUREAU (A)'),
(4, 12, 'DERICTUEUR BUREAUE (B)'),
(4, 13, 'MECANO DE TOUT'),
(4, 14, 'COMINUTY LEADER'),
(4, 15, 'CO CHEF'),
(4, 16, 'CHEF MECANO ');

-- --------------------------------------------------------

--
-- Structure de la table `factions`
--

CREATE TABLE `factions` (
  `id` tinyint DEFAULT NULL,
  `name` varchar(48) DEFAULT NULL,
  `shortname` tinytext,
  `leader` varchar(24) DEFAULT 'No-one',
  `type` tinyint DEFAULT '0',
  `color` int DEFAULT '-1',
  `rankcount` tinyint DEFAULT '6',
  `lockerx` float DEFAULT '0',
  `lockery` float DEFAULT '0',
  `lockerz` float DEFAULT '0',
  `lockerinterior` tinyint DEFAULT '0',
  `lockerworld` int DEFAULT '0',
  `turftokens` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `factions`
--

INSERT INTO `factions` (`id`, `name`, `shortname`, `leader`, `type`, `color`, `rankcount`, `lockerx`, `lockery`, `lockerz`, `lockerinterior`, `lockerworld`, `turftokens`) VALUES
(1, 'Los Santos Police', NULL, '__JO9LI_UX__', 1, 65280, 16, -544.596, 1803.65, 1393.28, 0, 4000034, 48),
(2, 'Los Santos Medical', NULL, 'Za3ima_Aya', 2, -8224256, 6, 1422.52, 1502.38, 1010.91, 1, 0, 0),
(3, 'hitman', NULL, 'Ruok_Sense', 0, -1728053248, 6, 301.008, 187.019, 1007.17, 3, 4000004, 1),
(4, 'Los Santos Mechanic', NULL, 'PECASO_F8', 7, 16711680, 17, 2017.83, -1783.34, 14.047, 0, 0, 0),
(5, 'los santos army', 'Black_Mara', 'YASSIN_RESTOVA', 1, -1718082816, 6, 300.806, 187.749, 1007.17, 3, 4000043, 3),
(7, 'Los Santos Federal', 'FEDERALE', 'NONE', 6, 1145337600, 6, 300.951, 187.942, 1007.17, 3, 4000004, 3),
(6, 'Los santos Terrorist', NULL, 'Mussahi_Lucas', 8, -2030043136, 7, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `factionskins`
--

CREATE TABLE `factionskins` (
  `id` tinyint DEFAULT NULL,
  `slot` tinyint DEFAULT NULL,
  `skinid` smallint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `factionskins`
--

INSERT INTO `factionskins` (`id`, `slot`, `skinid`) VALUES
(4, 0, 8),
(4, 1, 42),
(4, 2, 50),
(4, 3, 50),
(2, 0, 70),
(1, 0, 281),
(1, 1, 288),
(1, 2, 283),
(1, 3, 284),
(1, 4, 285),
(1, 5, 300),
(1, 6, 71),
(1, 7, 311),
(1, 14, 165),
(5, 0, 179),
(5, 1, 300),
(3, 0, 162),
(3, 1, 162),
(3, 2, 230),
(3, 3, 196),
(3, 4, 264),
(5, 2, 300),
(5, 3, 287),
(5, 4, 288),
(5, 5, 310),
(2, 1, 274),
(2, 2, 275),
(2, 3, 276),
(7, 0, 294),
(7, 1, 286),
(7, 2, 285),
(4, 4, 119),
(4, 5, 120),
(4, 6, 124),
(4, 7, 186),
(4, 8, 294),
(7, 3, 303),
(7, 4, 304),
(7, 5, 305),
(4, 9, 19),
(6, 0, 162),
(2, 4, 148),
(4, 10, 268),
(5, 14, 163),
(5, 13, 164),
(4, 11, 220),
(4, 12, 221),
(3, 5, 239),
(3, 6, 263),
(3, 7, 58),
(6, 1, 132),
(6, 2, 209),
(6, 3, 230),
(5, 6, 73),
(1, 8, 305);

-- --------------------------------------------------------

--
-- Structure de la table `flags`
--

CREATE TABLE `flags` (
  `id` int NOT NULL,
  `uid` int DEFAULT NULL,
  `flaggedby` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `furniture`
--

CREATE TABLE `furniture` (
  `id` int NOT NULL,
  `houseid` int DEFAULT NULL,
  `modelid` smallint DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `price` int DEFAULT NULL,
  `pos_x` float DEFAULT NULL,
  `pos_y` float DEFAULT NULL,
  `pos_z` float DEFAULT NULL,
  `rot_x` float DEFAULT NULL,
  `rot_y` float DEFAULT NULL,
  `rot_z` float DEFAULT NULL,
  `interior` tinyint DEFAULT NULL,
  `world` int DEFAULT NULL,
  `door_opened` tinyint(1) DEFAULT '0',
  `door_locked` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `gangranks`
--

CREATE TABLE `gangranks` (
  `id` tinyint DEFAULT NULL,
  `rank` tinyint DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `gangranks`
--

INSERT INTO `gangranks` (`id`, `rank`, `name`) VALUES
(4, 6, 'OG VAGOS !!'),
(4, 5, 'UNDER BOSS'),
(4, 0, 'Under Membere [tst]'),
(5, 6, 'God Father'),
(5, 0, 'New Son'),
(5, 5, 'Father'),
(5, 1, 'Littel Son'),
(5, 2, 'Son'),
(5, 3, 'Young Son'),
(5, 4, 'Big Son'),
(3, 6, 'Thee bige boss'),
(3, 5, 'Co og ballas'),
(3, 4, 'King capo'),
(3, 3, 'Co king capo'),
(3, 2, 'Videuur'),
(3, 1, 'The membre'),
(3, 0, 'TEST'),
(4, 1, 'New Vagosi'),
(4, 2, 'Old Vagosi'),
(4, 3, 'General Membere'),
(4, 4, 'Senior Membere'),
(6, 6, 'Leader'),
(6, 5, 'Right-hand'),
(6, 4, 'Senior Membere'),
(6, 3, 'General Member'),
(6, 1, 'New Yakuza'),
(6, 2, 'Old Yakuza'),
(2, 0, 'The membre'),
(2, 1, 'Eazy grove'),
(2, 2, 'M9wed'),
(2, 3, 'Co capo'),
(2, 4, 'King-Capo'),
(2, 5, 'Co boss'),
(2, 6, 'The big boss'),
(6, 0, 'For-Test'),
(1, 1, 'Weapon Seller +'),
(1, 2, 'Weapon Seller ++'),
(1, 3, 'Under Capo'),
(1, 4, 'Capo'),
(1, 5, 'Co Boss'),
(1, 6, 'Boss'),
(1, 0, 'New Member'),
(10, 0, 'For-Test (BRZ)'),
(10, 1, 'New Brazilian'),
(10, 2, 'Old Brazilian'),
(10, 3, 'General Brazilian'),
(10, 4, 'Senior Membere'),
(10, 5, 'Right-Hand'),
(10, 6, 'OG BRAZILANS !');

-- --------------------------------------------------------

--
-- Structure de la table `gangs`
--

CREATE TABLE `gangs` (
  `id` int NOT NULL,
  `name` varchar(32) DEFAULT 'None',
  `motd` varchar(128) DEFAULT 'None',
  `leader` varchar(24) DEFAULT 'No-one',
  `color` int DEFAULT '-256',
  `strikes` tinyint(1) DEFAULT '0',
  `level` tinyint DEFAULT '1',
  `points` int DEFAULT '0',
  `turftokens` int DEFAULT '0',
  `stash_x` float DEFAULT '0',
  `stash_y` float DEFAULT '0',
  `stash_z` float DEFAULT '0',
  `stashinterior` tinyint DEFAULT '0',
  `stashworld` int DEFAULT '0',
  `cash` int DEFAULT '0',
  `materials` int DEFAULT '0',
  `pot` int DEFAULT '0',
  `crack` int DEFAULT '0',
  `meth` int DEFAULT '0',
  `painkillers` int DEFAULT '0',
  `pistolammo` int DEFAULT '0',
  `shotgunammo` int DEFAULT '0',
  `smgammo` int DEFAULT '0',
  `arammo` int DEFAULT '0',
  `rifleammo` int DEFAULT '0',
  `hpammo` int DEFAULT '0',
  `poisonammo` int DEFAULT '0',
  `fmjammo` int DEFAULT '0',
  `weapon_9mm` int DEFAULT '0',
  `weapon_sdpistol` int DEFAULT '0',
  `weapon_deagle` int DEFAULT '0',
  `weapon_shotgun` int DEFAULT '0',
  `weapon_spas12` int DEFAULT '0',
  `weapon_sawnoff` int DEFAULT '0',
  `weapon_tec9` int DEFAULT '0',
  `weapon_uzi` int DEFAULT '0',
  `weapon_mp5` int DEFAULT '0',
  `weapon_ak47` int DEFAULT '0',
  `weapon_m4` int DEFAULT '0',
  `weapon_rifle` int DEFAULT '0',
  `weapon_sniper` int DEFAULT '0',
  `weapon_molotov` int DEFAULT '0',
  `armsdealer` tinyint(1) DEFAULT '0',
  `drugdealer` tinyint(1) DEFAULT '0',
  `arms_x` float DEFAULT '0',
  `arms_y` float DEFAULT '0',
  `arms_z` float DEFAULT '0',
  `arms_a` float DEFAULT '0',
  `drug_x` float DEFAULT '0',
  `drug_y` float DEFAULT '0',
  `drug_z` float DEFAULT '0',
  `drug_a` float DEFAULT '0',
  `armsworld` int DEFAULT '0',
  `drugworld` int DEFAULT '0',
  `drugpot` int DEFAULT '0',
  `drugcrack` int DEFAULT '0',
  `drugmeth` int DEFAULT '0',
  `armsmaterials` int DEFAULT '0',
  `armsprice_1` int DEFAULT '0',
  `armsprice_2` int DEFAULT '0',
  `armsprice_3` int DEFAULT '0',
  `armsprice_4` int DEFAULT '0',
  `armsprice_5` int DEFAULT '0',
  `armsprice_6` int DEFAULT '0',
  `armsprice_7` int DEFAULT '0',
  `armsprice_8` int DEFAULT '0',
  `armsprice_9` int NOT NULL DEFAULT '0',
  `armsprice_10` int NOT NULL DEFAULT '0',
  `armsprice_11` int NOT NULL DEFAULT '0',
  `armsprice_12` tinyint NOT NULL DEFAULT '0',
  `pot_price` int DEFAULT '0',
  `crack_price` int DEFAULT '0',
  `meth_price` int DEFAULT '0',
  `armshpammo` int DEFAULT '0',
  `armspoisonammo` int DEFAULT '0',
  `armsfmjammo` int DEFAULT '0',
  `alliance` int NOT NULL DEFAULT '-1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `gangs`
--

INSERT INTO `gangs` (`id`, `name`, `motd`, `leader`, `color`, `strikes`, `level`, `points`, `turftokens`, `stash_x`, `stash_y`, `stash_z`, `stashinterior`, `stashworld`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `weapon_9mm`, `weapon_sdpistol`, `weapon_deagle`, `weapon_shotgun`, `weapon_spas12`, `weapon_sawnoff`, `weapon_tec9`, `weapon_uzi`, `weapon_mp5`, `weapon_ak47`, `weapon_m4`, `weapon_rifle`, `weapon_sniper`, `weapon_molotov`, `armsdealer`, `drugdealer`, `arms_x`, `arms_y`, `arms_z`, `arms_a`, `drug_x`, `drug_y`, `drug_z`, `drug_a`, `armsworld`, `drugworld`, `drugpot`, `drugcrack`, `drugmeth`, `armsmaterials`, `armsprice_1`, `armsprice_2`, `armsprice_3`, `armsprice_4`, `armsprice_5`, `armsprice_6`, `armsprice_7`, `armsprice_8`, `armsprice_9`, `armsprice_10`, `armsprice_11`, `armsprice_12`, `pot_price`, `crack_price`, `meth_price`, `armshpammo`, `armspoisonammo`, `armsfmjammo`, `alliance`) VALUES
(1, 'Black Mafia', 'None', 'Removed', 33686016, 0, 1, 355, 1000000, 1226.46, -808.018, 1084.01, 5, 4000140, 910000, 2000000, 99980, 99980, 99980, 99980, 0, 0, 0, 0, 0, 0, 0, 0, 100, 100, 98, 100, 100, 100, 100, 100, 99, 100, 98, 100, 98, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1),
(2, 'GROVE STREET GROVE', 'Mrhba Bik A Baqcha', 'Cleared', 10027008, 2, 3, 2742, 410065383, 2337.91, -1141.69, 1054.31, 12, 4000013, 277520, 80, 0, 200, 0, 0, 0, 0, 0, 0, 0, 80, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 1000, 1500, 0, 0, 0, 7),
(3, 'Los Santos Ballas', 'BALASEE', 'no one ', -721356544, 2, 3, 1404, 446, 2226.68, -1150.67, 1025.8, 15, 4000015, 0, 0, 0, 125, 0, 180, 0, 0, 0, 0, 0, 0, 0, 0, 2, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 1000, 1500, 0, 0, 0, -1),
(4, 'Los Santos Vagos', 'None', 'pedro', -65536, 2, 1, 3182, 10, 1700.53, -1667.47, 20.219, 18, 4000016, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1),
(5, 'Los Santos CRIPS', 'Hna li kaynin', 'Cleared', 16776960, 0, 3, 101998, 382, 305.371, -141.852, 1004.06, 7, 4000031, 200000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 160, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 1000, 1500, 0, 0, 0, -1),
(6, 'Los Santos yakuza', 'KNTE M9WED OG AYZEDK RANK', 'STRANGER', -16777216, 0, 3, 482175, 921, 2454.55, -1705.45, 1013.51, 2, 4000125, 135161, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 40, 4, 8, 0, 0, 0, 0, 6, 0, 4, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500, 1000, 1500, 0, 0, 0, 9),
(10, 'FAVELAS VIP', 'HNA LI KAYNIN', 'GOSTAVE_X', 2021160704, 0, 3, 2646, 99999935, 2224.52, -1152.12, 1025.8, 15, 4000124, 16791, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1);

-- --------------------------------------------------------

--
-- Structure de la table `gangskins`
--

CREATE TABLE `gangskins` (
  `id` tinyint DEFAULT NULL,
  `slot` tinyint DEFAULT NULL,
  `skinid` smallint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `gangskins`
--

INSERT INTO `gangskins` (`id`, `slot`, `skinid`) VALUES
(5, 0, 114),
(5, 1, 115),
(5, 2, 116),
(2, 0, 119),
(2, 1, 234),
(2, 2, 105),
(2, 3, 106),
(2, 4, 270),
(4, 0, 108),
(4, 1, 109),
(4, 2, 110),
(3, 0, 296),
(3, 1, 3),
(3, 2, 16),
(6, 0, 49),
(6, 1, 1),
(6, 2, 97),
(6, 3, 189),
(6, 4, 68),
(3, 9, 0),
(3, 8, 154),
(3, 7, 66),
(3, 6, 43),
(3, 5, 25),
(3, 4, 24),
(3, 3, 103),
(2, 5, 271),
(2, 8, 220),
(4, 3, 248),
(4, 4, 249),
(2, 9, 86),
(6, 5, 123),
(6, 6, 2),
(6, 7, 19),
(5, 3, 175),
(5, 4, 2),
(10, 0, 23),
(10, 1, 18),
(10, 2, 33),
(10, 3, 181),
(10, 4, 212),
(10, 5, 292),
(10, 6, 293),
(10, 7, 45),
(10, 8, 0),
(2, 6, 269),
(2, 7, 2),
(10, 9, 0);

-- --------------------------------------------------------

--
-- Structure de la table `garages`
--

CREATE TABLE `garages` (
  `id` int NOT NULL,
  `ownerid` int DEFAULT '0',
  `owner` varchar(24) DEFAULT NULL,
  `type` tinyint(1) DEFAULT '0',
  `price` int DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `timestamp` int DEFAULT '0',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `exit_x` float DEFAULT '0',
  `exit_y` float DEFAULT '0',
  `exit_z` float DEFAULT '0',
  `exit_a` float DEFAULT '0',
  `world` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `garages`
--

INSERT INTO `garages` (`id`, `ownerid`, `owner`, `type`, `price`, `locked`, `timestamp`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `exit_x`, `exit_y`, `exit_z`, `exit_a`, `world`) VALUES
(3, 793, 'Khalil_Escobar', 0, 0, 1, 1690980754, 904.234, -1454.98, 13.09, 267.55, 901.237, -1454.85, 13.09, 87.55, 2000003),
(5, 1709, 'SUPRA_MK4', 2, 0, 0, 1690898014, 1094.24, -347.567, 73.987, 180.082, 1102.67, -1023.88, 32.16, -1.537, 2000005),
(12, 472, 'IMAD_LUCIANO', 2, 250000, 0, 1691724547, 166.187, -1338.88, 69.804, 179.585, 166.208, -1335.88, 69.804, -0.415, 2000012),
(26, 1519, '44_', 2, 250000, 1, 1691799907, 1539.92, -841.368, 64.336, 261.572, 1536.95, -840.928, 64.336, 81.572, 2000026),
(27, 1192, 'I_NAMOSE', 2, 5000000, 1, 1691261742, 248.459, -1360.05, 53.109, 124.783, 250.923, -1358.33, 53.109, -55.217, 2000027),
(28, 597, 'MOULL_SLAWI', 2, 250000, 0, 1689348462, 407.366, -1267.09, 50.02, 201.593, 406.262, -1264.3, 50.02, 21.593, 2000028),
(31, 1453, 'davos_cb4', 1, 125000, 0, 1689725927, 1320.19, -1754.01, 13.547, 93.95, 1323.18, -1753.8, 13.547, -86.05, 2000031),
(32, 1434, 'LHOPRO_RN', 1, 125000, 1, 1689732689, 1319.53, -1759.18, 13.547, 74.393, 1322.42, -1759.98, 13.547, -105.607, 2000032),
(44, 534, 'AYM4N_WINS', 2, 250000, 0, 1688691402, 1101.53, -1101.12, 25.872, 260.021, 1098.57, -1100.6, 25.872, 80.021, 2000044),
(47, 1171, 'ZWITA_', 2, 250000, 1, 1691548915, 225.823, -1244.6, 78.305, 36.419, 227.604, -1247.01, 78.305, -143.581, 2000047),
(48, 588, 'Hex_404', 0, 100000, 1, 1689522901, 229.52, -1242.5, 78.285, 42.611, 231.551, -1244.7, 78.285, -137.389, 2000048),
(49, 1709, 'SUPRA_MK4', 0, 100000, 0, 1690898036, 1517.34, -764.122, 79.911, 189.579, 1516.84, -761.164, 79.911, 9.579, 2000049),
(52, 3342, 'HERO_ZERO', 2, 250000, 0, 1691502447, 2113.28, -1743.21, 13.563, 357.468, 2113.15, -1746.21, 13.563, 177.468, 2000052),
(53, 535, 'Ilyas_Newton', 2, 250000, 0, 1690062685, 2327.16, -1677.56, 14.422, 88.796, 2330.16, -1677.62, 14.422, -91.204, 2000053),
(54, 1887, 'FATAL_MIAL', 2, 250000, 1, 1690980024, 1533.1, -813.039, 72.124, 252.793, 1530.23, -812.151, 72.124, 72.793, 2000054),
(55, 1519, 'Boonina_Millions', 2, 250000, 0, 1691879820, 286.133, -1154.89, 80.914, 19.346, 287.127, -1157.72, 80.914, -160.654, 2000055),
(56, 1709, 'SUPRA_MK4', 2, 250000, 0, 1691073027, 480.022, -1089.56, 82.45, 355.175, 479.769, -1092.55, 82.45, 175.175, 2000056),
(60, 2789, 'SI_ALI', 2, 250000, 0, 1691679740, 751.18, -551.235, 17.203, 354.423, 750.889, -554.221, 17.203, 174.423, 2000060),
(61, 1830, 'Eilina_Aya', 2, 250000, 1, 1691551026, 771.446, -555.596, 17.336, 201.928, 770.325, -552.813, 17.336, 21.928, 2000061),
(62, 1534, 'vergas__', 2, 250000, 1, 1690215241, 786.411, -495.868, 17.336, 357.336, 786.271, -498.864, 17.336, 177.336, 2000062),
(65, 2129, 'ilyass_smp', 2, 250000, 0, 1691300865, 1351.31, -621.386, 109.133, 19.175, 1352.29, -624.219, 109.133, -160.825, 2000065),
(66, 535, 'Ilyas_Newton', 2, 250000, 0, 1691294606, 1249.03, -800.891, 84.141, 358.426, 1248.95, -803.89, 84.141, 178.426, 2000066),
(67, 535, 'Ilyas_Newton', 2, 250000, 0, 1691294597, 1254.68, -800.886, 84.141, 340.73, 1253.69, -803.718, 84.141, 160.73, 2000067),
(68, 535, 'Ilyas_Newton', 2, 250000, 0, 1691294615, 1242.86, -800.886, 84.141, 9.731, 1243.37, -803.843, 84.141, -170.269, 2000068),
(69, 1291, 'Shark_Bernard', 1, 125000, 0, 1690377556, 1088.06, -640.924, 113.154, 87.515, 1091.06, -641.054, 113.154, -92.485, 2000069),
(70, 1285, 'WALD_FAVELAS', 2, 250000, 1, 1691503319, 1010.86, -660.169, 121.141, 220.684, 1008.9, -657.894, 121.141, 40.684, 2000070),
(71, 1308, 'Musashi_Lucas', 2, 250000, 0, 1691711643, 172.044, -1339.97, 69.815, 359.217, 172.003, -1342.97, 69.815, 179.217, 2000071),
(72, 2375, 'NINJA_NETWORK', 2, 125000, 1, 1691764258, 1177.83, -1108.09, 25.236, 267.88, 1174.84, -1107.98, 25.236, 87.88, 2000072),
(73, 3643, 'MITO_', 0, 125000, 1, 1691791672, 230.617, -1409.94, 51.609, 142.844, 232.429, -1407.55, 51.609, -37.156, 2000073),
(74, 765, '3A_BO9A', 2, 250000, 1, 1691188730, 1558.48, -2180.8, 13.547, 21.934, 1559.6, -2183.58, 13.547, -158.066, 2000074),
(75, 498, 'mo_rad', 2, 250000, 0, 1691870626, 850.547, -1527.67, 12.693, 257.769, 847.615, -1527.03, 12.693, 77.769, 2000075),
(76, 862, 'ZOU_HIR', 2, 250000, 0, 1691690765, 1518.79, -694.534, 94.75, 92.767, 1521.78, -694.389, 94.75, -87.233, 2000076);

-- --------------------------------------------------------

--
-- Structure de la table `gates`
--

CREATE TABLE `gates` (
  `gateID` int NOT NULL,
  `gateModel` int DEFAULT '980',
  `gateSpeed` float DEFAULT '0',
  `gateTime` int DEFAULT '0',
  `gateX` float DEFAULT '0',
  `gateY` float DEFAULT '0',
  `gateZ` float DEFAULT '0',
  `gateRX` float DEFAULT '0',
  `gateRY` float DEFAULT '0',
  `gateRZ` float DEFAULT '0',
  `gateInterior` int DEFAULT '0',
  `gateWorld` int DEFAULT '0',
  `gateMoveX` float DEFAULT '0',
  `gateMoveY` float DEFAULT '0',
  `gateMoveZ` float DEFAULT '0',
  `gateMoveRX` float DEFAULT '0',
  `gateMoveRY` float DEFAULT '0',
  `gateMoveRZ` float DEFAULT '0',
  `gateLinkID` int DEFAULT '0',
  `gateFaction` int DEFAULT '0',
  `gatePass` varchar(32) DEFAULT NULL,
  `gateRadius` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `gates`
--

INSERT INTO `gates` (`gateID`, `gateModel`, `gateSpeed`, `gateTime`, `gateX`, `gateY`, `gateZ`, `gateRX`, `gateRY`, `gateRZ`, `gateInterior`, `gateWorld`, `gateMoveX`, `gateMoveY`, `gateMoveZ`, `gateMoveRX`, `gateMoveRY`, `gateMoveRZ`, `gateLinkID`, `gateFaction`, `gatePass`, `gateRadius`) VALUES
(4, 980, 7, 0, 1090.73, -1371.83, 14.6568, 0, 0, 0, 0, 0, 1099.73, -1371.83, 14.1568, 0, 0, 0, -1, 7, '', 5),
(5, 980, 7, 0, 1124.45, -1372.05, 14.7567, 0, 0, 0, 0, 0, 1113.75, -1372.05, 14.7567, 0, 0, 0, -1, 7, '', 5),
(6, 3749, 3, 0, 2426.79, -2010.51, 17.7832, 0, 0, 268.021, 0, 0, 959.944, -1430.79, 3.5467, -1000, -1000, -1000, -1, -1, 'YAKUZA', 0),
(8, 980, 3, 0, 2426.03, -2010.28, 14.8204, 0, 0, -92.799, 0, 0, 2426.03, -2010.28, 9.6203, 0, 0, -92.799, -1, -1, 'YKZ', 5),
(9, 2, 3, 0, 2496.95, -2031.73, 13.5467, 0, 0, 172.607, 0, 0, 1036.04, -1459.97, 3.5657, -1000, -1000, -1000, -1, -1, 'YAKUZA', 0),
(10, 980, 3, 0, 452.539, 512.83, 1001.42, 0, 0, 280.435, 12, 0, 452.539, 512.83, 991.419, -1000, -1000, -1000, -1, -1, 'EVENTSOON', 4),
(13, 19913, 3, 0, 2769.14, -1979.32, 13.3963, 0, 0, 179.568, 7, 0, -1395.73, -239.671, 1033.4, -1000, -1000, -1000, -1, -1, 'GOLDEN', 5),
(15, 980, 3, 0, 2241.44, -1169.77, 1029.8, 0, 0, 180.648, 15, 0, 2241.44, -1169.77, 1019.8, -1000, -1000, -1000, -1, -1, '', 5),
(20, 980, 3, 0, 1414.29, -9.1925, 1000.92, 0, 0, 252.171, 1, 0, 1409.95, -6.4355, 990.916, -1000, -1000, -1000, -1, -1, '', 5),
(21, 980, 3, 0, 1370.46, -10.5644, 1000.92, 0, 0, 180.077, 1, 0, 1370.46, -10.5644, 990.922, -1000, -1000, -1000, -1, -1, '', 5),
(22, 980, 3, 0, 1403.95, -37.5792, 1000.91, 0, 0, 4.0004, 1, 0, 1403.95, -37.5792, 990.912, -1000, -1000, -1000, -1, -1, '', 5),
(23, 980, 3, 0, 1369.4, -37.257, 1000.92, 0, 0, 351.152, 1, 0, 1369.4, -37.257, 990.922, -1000, -1000, -1000, -1, -1, '', 5),
(31, 19913, 3, 0, 924.978, -1220.87, 16.9764, 0, 0, 266.954, 0, 0, 924.978, -1220.87, 6.9765, -1000, -1000, -1000, -1, 1, 'ARMYGLD', 5),
(33, 980, 3, 0, 215.41, 146.588, 1003.02, 0, 0, 6.4886, 3, 4000004, 215.41, 146.588, 993.023, -1000, -1000, -1000, -1, -1, 'FBR', 5),
(37, 980, 3, 0, 1401.5, -21.4104, 1000.91, 0, 0, 182.034, 1, 0, 1401.5, -21.4104, 990.909, -1000, -1000, -1000, -1, -1, '92929292', 5),
(38, 980, 3, 0, 1396.53, -16.5205, 1000.91, 0, 0, 90.6711, 1, 0, 1396.53, -16.5205, 990.907, -1000, -1000, -1000, -1, -1, '38228', 5),
(39, 980, 3, 0, 1401.46, -11.1431, 1000.91, 0, 0, 356.662, 1, 0, 1401.46, -11.1431, 990.909, -1000, -1000, -1000, -1, -1, '9292929292', 5),
(40, 980, 3, 0, 1407.1, -16.2392, 1000.91, 0, 0, 267.797, 1, 0, 1407.1, -16.2392, 990.912, -1000, -1000, -1000, -1, -1, '9292929', 5),
(42, 980, 3, 0, 263.647, -1332.72, 53.2714, 0, 0, 35.4757, 0, 0, 263.647, -1332.72, 43.2714, -1000, -1000, -1000, -1, -1, 'PRO', 5),
(43, 980, 3, 0, 2564.67, -1281.57, 1048.29, 0, 0, 267.939, 2, 4000022, 2564.67, -1281.57, 1038.29, -1000, -1000, -1000, -1, -1, '2929292', 5),
(47, 16775, 1, 0, 833.731, -865.521, 69.6867, 0, 0, 200.095, 0, 0, 1477.44, -670.711, 84.75, -1000, -1000, -1000, -1, -1, 'TITANIC', 5),
(57, 980, 3, 0, 321.381, -1188.19, 76.3552, 0, 0, 36.6164, 0, 0, 321.381, -1188.19, 66.3552, -1000, -1000, -1000, -1, -1, 'BB', 5),
(63, 980, 3, 0, 262.034, -1231.49, 73.8967, 0, 0, 212.03, 0, 0, 262.034, -1231.49, 63.8969, -1000, -1000, -1000, -1, -1, 'aya', 5),
(67, 19913, 3, 0, 1797.15, -1135.14, 24.0781, 0, 0, 84.5009, 0, 0, 1797.15, -1135.14, 14.0781, -1000, -1000, -1000, -1, -1, 'CMR', 5),
(72, 19913, 3, 0, 1805.27, -1101.66, 24.0781, 0, 0, 92.1918, 0, 0, 1805.27, -1101.66, 14.0781, -1000, -1000, -1000, -1, -1, 'CMR', 5),
(96, 3749, 3, 0, 2769.28, -1906.13, 15.2307, 0, 0, 180.523, 0, 0, 2219.92, -1142.88, 15.744, -1000, -1000, -1000, -1, -1, 'BLS', 0),
(109, 980, 3, 0, 1019.31, -316.134, 73.9921, 0, 0, 357.582, 0, 0, 1019.31, -316.134, 63.9921, -1000, -1000, -1000, -1, -1, '', 5),
(112, 980, 3, 0, 200.144, 179.442, 1003.03, 0, 0, 92.2278, 3, 4000004, 200.144, 179.442, 993.028, -1000, -1000, -1000, -1, -1, 'FBI123', 5),
(113, 980, 3, 0, 2797.21, -1594.85, 10.9254, 0, 0, 341.288, 0, 0, 2795.85, -1595.99, 0.9248, -1000, -1000, -1000, -1, -1, 'VGS', 5),
(114, 19913, 3, 0, 2461.65, -1659, 13.2889, 0, 0, 87.3508, 0, 0, 2461.65, -1659, 3.289, -1000, -1000, -1000, -1, -1, 'GROVE', 5),
(116, 980, 3, 0, 2239.42, -1170.75, 1029.8, 0, 0, 269.219, 15, 4000086, 2238.98, -1170.61, 1019.8, -1000, -1000, -1000, -1, -1, '2222', 5),
(117, 980, 3, 0, 454.384, 513.171, 1001.42, 0, 0, 272.443, 12, 4000098, 454.384, 513.171, 991.419, -1000, -1000, -1000, -1, -1, 'GRV', 5),
(118, 980, 3, 0, 441.649, 511.771, 1001.42, 0, 0, 80.9614, 12, 4000098, 441.649, 511.771, 991.419, -1000, -1000, -1000, -1, -1, 'GRV', 5),
(120, 980, 3, 0, 1302.4, -783.753, 1084.01, 0, 0, 357.411, 5, 1000370, 1302.4, -783.753, 1074.01, -1000, -1000, -1000, -1, -1, 'ali', 5),
(121, 980, 3, 0, 961.411, -941.844, 41.005, 0, 0, 183.981, 0, 0, 963.412, -941.295, 31.1625, -1000, -1000, -1000, -1, -1, 'BIC', 5),
(122, 980, 3, 0, 287.732, 2540.05, 16.8168, 0, 0, 4.6411, 0, 4000105, 287.732, 2540.05, 6.8168, -1000, -1000, -1000, -1, -1, '', 5),
(127, 980, 3, 0, 1302.65, -2052.47, 58.3348, 0, 0, 268.927, 0, 0, 1302.65, -2052.47, 48.3348, -1000, -1000, -1000, -1, -1, 'CC', 5),
(128, 980, 3, 0, 1302.93, -2060.72, 58.3245, 0, 0, 267.788, 0, 0, 1302.93, -2060.72, 48.3245, -1000, -1000, -1000, -1, -1, 'CC', 5),
(134, 980, 3, 0, 2185.66, -1764.2, 13.3739, 0, 0, 357.166, 0, 0, 2185.66, -1764.2, 3.3738, -1000, -1000, -1000, -1, -1, 'VAR', 5),
(136, 980, 3, 0, 282.538, -1321.15, 53.7374, 0, 0, 33.3713, 0, 0, 282.538, -1321.15, 43.7374, -1000, -1000, -1000, -1, -1, 'hQ', 5),
(139, 19913, 3, 0, 1018.84, -1133.55, 23.8623, 0, 0, 180.04, 0, 0, 1018.84, -1133.55, 13.8623, -1000, -1000, -1000, -1, -1, '7OKOMA', 5),
(141, 980, 3, 0, 169.424, -1351.46, 69.3565, 0, 0, 182.385, 0, 0, 169.424, -1351.46, 59.3568, -1000, -1000, -1000, -1, -1, 'MUSASHI', 5),
(143, 980, 3, 0, 1003.11, -643.882, 121.252, 0, 0, 26.0761, 0, 0, 1003.11, -643.882, 111.252, -1000, -1000, -1000, -1, -1, 'MODOX', 5),
(144, 980, 3, 0, 2737.03, -1944.69, 13.5467, 0, 0, 92.3359, 0, 0, 2737.03, -1944.69, 3.5467, -1000, -1000, -1000, -1, -1, 'VRS', 0),
(145, 980, 3, 0, 1777.17, -1553.56, 22.9383, 0, 0, 35.9736, 0, 4000123, 1777.17, -1553.56, 12.9383, -1000, -1000, -1000, -1, -1, '99999s9ss', 5),
(146, 19913, 3, 0, 1795.93, -1576.51, 22.9312, 0, 0, 220.781, 0, 4000123, 1795.93, -1576.51, 12.9312, -1000, -1000, -1000, -1, -1, 'eksksksks', 5),
(147, 980, 3, 0, 1809.17, -1561.5, 22.9251, 0, 0, 268.266, 0, 4000123, 1809.17, -1561.5, 12.9251, -1000, -1000, -1000, -1, -1, 'eksksksks', 5),
(148, 980, 3, 0, 1777.32, -1588.2, 22.9451, 0, 0, 171.446, 0, 4000123, 1777.32, -1588.2, 12.9451, -1000, -1000, -1000, -1, -1, '282sksks8s8sksksisi', 5),
(155, 19913, 3, 0, 2229.81, -1046.92, 56.257, 0, 0, 136.227, 0, 0, 2229.81, -1046.92, 46.257, -1000, -1000, -1000, -1, -1, 'BRL', 5),
(156, 19913, 3, 0, 2251.42, -1067.39, 49.979, 0, 0, 136.883, 0, 0, 2251.42, -1067.39, 39.979, -1000, -1000, -1000, -1, -1, 'BRL', 5),
(157, 980, 3, 0, 2280.76, -1083.33, 47.7075, 0, 0, 151.06, 0, 0, 2280.76, -1083.33, 37.7075, -1000, -1000, -1000, -1, -1, 'zetsu', 5),
(158, 980, 3, 0, 527.511, -1872.99, 3.7344, 0, 0, 1.0237, 0, 0, 527.511, -1872.99, -6.2655, -1000, -1000, -1000, -1, -1, 'XVILO', 5),
(159, 19913, 3, 0, 603.352, -1972.85, 2.873, 0, 0, 178.284, 0, 0, 603.352, -1972.85, -7.1269, -1000, -1000, -1000, -1, -1, '', 5),
(164, 980, 3, 0, 2831.77, -1580.12, 11.0937, 0, 0, 58.5346, 0, 0, 2831.77, -1580.12, 1.0937, -1000, -1000, -1000, -1, -1, 'VGS', 5),
(166, 980, 3, 0, 1588.05, -1637.42, 13.1611, 0, 0, 353.994, 0, 2, 1588.05, -1637.42, 3.1611, -1000, -1000, -1000, -1, -1, '99292', 5),
(167, 980, 3, 0, 1588.58, -1638.75, 13.3828, 0, 0, 196.231, 0, 0, 1588.58, -1638.75, 3.3828, -1000, -1000, -1000, -1, -1, '92929292', 5),
(172, 980, 3, 0, 1808.74, -1562.85, 22.9254, 0, 0, 247.243, 0, 0, 1808.74, -1562.85, 12.9254, -1000, -1000, -1000, -1, -1, 'dkdkdkdjd', 5),
(173, 980, 3, 0, 1803.23, -1570.39, 22.9289, 0, 0, 220.695, 0, 0, 1803.23, -1570.39, 12.9289, -1000, -1000, -1000, -1, -1, 'djdkdkdkd', 5),
(174, 980, 3, 0, 1795.46, -1577.65, 22.9319, 0, 0, 223.761, 0, 0, 1795.46, -1577.65, 12.9319, -1000, -1000, -1000, -1, -1, 'dkfkfkfk', 5),
(175, 980, 3, 0, 1786.83, -1585.16, 22.9364, 0, 0, 212.545, 0, 0, 1786.83, -1585.16, 12.9364, -1000, -1000, -1000, -1, -1, 'dkdkdkdkdk', 5),
(177, 980, 3, 0, 1777.92, -1588.16, 22.9452, 0, 0, 185.437, 0, 0, 1777.92, -1588.16, 12.9452, -1000, -1000, -1000, -1, -1, 'sksksks', 5),
(178, 980, 3, 0, 2292.76, -1110.9, 37.9765, 0, 0, 279.451, 0, 0, 2292.76, -1110.9, 27.9765, -1000, -1000, -1000, -1, -1, '', 0),
(179, 980, 3, 0, 2292.29, -1116.87, 37.9765, 0, 0, 257.894, 0, 0, 2292.29, -1116.87, 27.9765, -1000, -1000, -1000, -1, -1, '', 0),
(180, 980, 3, 0, 2287.53, -1119.75, 37.9765, 0, 0, 165.752, 0, 0, 2287.53, -1119.75, 27.9765, -1000, -1000, -1000, -1, -1, '', 0),
(181, 980, 3, 0, 2280.13, -1118.49, 37.9765, 0, 0, 172.608, 0, 0, 2280.13, -1118.49, 27.9765, -1000, -1000, -1000, -1, -1, '', 5),
(183, 980, 3, 0, 2291.2, -1104.19, 37.9765, 0, 0, 304.768, 0, 0, 2291.2, -1104.19, 27.9765, -1000, -1000, -1000, -1, -1, '', 0),
(187, 19913, 3, 0, 2228.8, -1084.96, 31.7346, 0, 0, 316.35, 0, 0, 2228.8, -1084.96, 21.7346, -1000, -1000, -1000, -1, -1, 'BRL', 5),
(189, 980, 3, 0, 2264.06, -1134.34, 29.3143, 0, 0, 165.808, 0, 0, 2264.06, -1134.34, 19.3143, -1000, -1000, -1000, -1, -1, 'BRL', 5),
(190, 980, 3, 0, 2270.27, -1133.03, 29.128, 0, 0, 253.081, 0, 0, 2270.27, -1133.03, 19.128, -1000, -1000, -1000, -1, -1, 'BRL', 5),
(191, 980, 3, 0, 2271.52, -1127.37, 32.3699, 0, 0, 250.831, 0, 0, 2271.52, -1127.37, 22.3699, -1000, -1000, -1000, -1, -1, 'BRL', 5),
(192, 980, 3, 0, 2272.81, -1120.36, 36.3502, 0, 0, 248.165, 0, 0, 2272.81, -1120.36, 26.3502, -1000, -1000, -1000, -1, -1, 'BRL', 5),
(195, 980, 3, 0, 2270.96, -1128.42, 31.9285, 0, 0, 244.565, 0, 0, 2270.96, -1128.42, 21.9285, -1000, -1000, -1000, -1, -1, 'hhhhheh', 5),
(196, 980, 3, 0, 2271.02, -1125.98, 32.7722, 0, 0, 261.704, 0, 0, 2271.02, -1125.98, 22.7722, -1000, -1000, -1000, -1, -1, 'hhhhhh', 5),
(198, 980, 3, 0, 2211.27, -1066.15, 41.8944, 0, 0, 127.887, 0, 0, 2211.27, -1066.15, 31.8944, -1000, -1000, -1000, -1, -1, 'hhbhe', 5),
(209, 980, 3, 0, 1571.41, -1637.76, 15.3472, 0, 0, 0, 0, 0, 1546.01, -1639.36, 3.5471, -1000, -1000, -1000, -1, -1, '', 0),
(210, 980, 3, 0, 1560.01, -1637.7, 15.3828, 0, 0, 0, 0, 0, 1567.61, -1635, 3.3828, -1000, -1000, -1000, -1, -1, '', 0),
(211, 980, 3, 0, 1548.43, -1637.61, 15.3484, 0, 0, 0, 0, 0, 1558.22, -1636.21, 3.5484, -1000, -1000, -1000, -1, -1, '', 0),
(212, 3749, 3, 0, 1545.1, -1627.81, 18.0828, 0, 0, -90, 0, 0, 1545.1, -1633.71, 3.3828, -1000, -1000, -1000, -1, -1, '', 0),
(213, 980, 3, 0, 1544.7, -1627.91, 15.1828, 0, 0, -90, 0, 0, 1544.7, -1616.21, 15.1828, 0, 0, -90, -1, 1, '', 5),
(214, 19913, 5, 0, -2486.36, -619.333, 137.063, 0, 0, 90, 0, 0, -2486.36, -619.333, 126.262, 0, 0, 90, -1, -1, 'LDN', 10),
(215, 19913, 3, 0, -2511.29, -594.379, 137.154, 0, 0, 0, 0, 0, -2501.18, -591.68, 122.454, -1000, -1000, -1000, -1, -1, '', 0),
(216, 19913, 3, 0, -2517.38, -594.393, 137.14, 0, 0, 0, 0, 0, -2537.6, -592.694, 121.54, -1000, -1000, -1000, -1, -1, '', 5),
(217, 19913, 3, 0, -2542.41, -619.271, 137.13, 0, 0, 90, 0, 0, -2540.61, -594.677, 122.03, -1000, -1000, -1000, -1, -1, '', 0),
(220, 19913, 3, 0, 1820.8, -1094.42, 24.0781, 0, 0, 0, 0, 0, 1820.8, -1094.42, 14.0781, -1000, -1000, -1000, -1, -1, '2023', 5),
(225, 980, 3, 0, 2219.95, -1141.29, 27.625, 0, 0, -20, 0, 0, 2219.85, -1141.29, 22.0249, 0, 0, -20, -1, -1, 'BLS', 10),
(226, 980, 3, 0, 1601.05, -1684.99, 14.4938, 0, 0, 0, 0, 0, 1601.05, -1684.99, 4.4938, -1000, -1000, -1000, -1, -1, 'LSPD', 5),
(227, 980, 3, 0, 1536.05, -2184.68, 12.3468, 0, 0, 0, 0, 0, 1543.15, -2184.68, 12.3468, 0, 0, 0, -1, -1, 'NIZAR', 5),
(228, 980, 3, 0, 1557.59, -2184.61, 12.3468, 0, 0, 0, 0, 0, 1549.29, -2184.61, 12.3468, 0, 0, 0, -1, -1, 'NIZAR', 5),
(229, 19302, 3, 0, 2243.01, -1159.77, 1030, 0, 0, -90, 15, 4000015, 2243.01, -1158.07, 1030, 0, 0, -90, -1, -1, 'IDER', 5),
(230, 19302, 3, 0, 322.169, 310.077, 999.448, 0, 0, 0, 5, 4000142, 320.669, 310.077, 999.448, 0, 0, 0, -1, -1, 'MUSASHI', 5),
(231, 980, 3, 0, 214.698, 1876.25, 13.1406, 0, 0, 0, 0, 0, 214.698, 1876.25, 3.1406, -1000, -1000, -1000, -1, -1, 'GLDSSOOONSISI', 5),
(239, 19913, 3, 0, 214.928, 1871.23, 13.1406, 0, 0, 0, 0, 0, 214.928, 1869.03, 3.1406, -1000, -1000, -1000, -1, -1, 'sjsjskss', 0),
(240, 980, 3, 0, 226.565, 1871.98, 13.7343, 0, 0, -90, 0, 0, 224.865, 1871.98, 3.7343, -1000, -1000, -1000, -1, -1, '', 0),
(241, 980, 3, 0, 2428.03, -1999.33, 16.8468, 0, 89.9999, 90, 0, 0, 2428.43, -1999.63, 3.5468, -1000, -1000, -1000, -1, -1, '', 0),
(242, 19913, 3, 0, 2589.15, -2139.51, 3.7812, 0, 0, 0, 0, 0, 2572.63, -2140.31, -10.2187, -1000, -1000, -1000, -1, -1, '', 0),
(243, 980, 3, 0, 2558.36, -2139.48, 1.5812, 0, 0, 0, 0, 0, 2569.07, -2139.48, 1.5812, 0, 0, 0, -1, -1, 'MF', 5),
(244, 19913, 3, 0, 2589.11, -2207.92, 4.2812, 0, 0, 0, 0, 0, 2581.61, -2202.41, -10.2187, -1000, -1000, -1000, -1, -1, '', 0),
(245, 19913, 3, 0, 2578.45, -2207.93, 3.3812, 0, 0, 0, 0, 0, 2568.44, -2205.43, -10.2187, -1000, -1000, -1000, -1, -1, 'MF', 0),
(246, 14781, 3, 0, 2581.6, -2173.39, -0.2187, 0, 0, 0, 0, 0, 2579.2, -2177.09, -10.2187, -1000, -1000, -1000, -1, -1, '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `graffiti`
--

CREATE TABLE `graffiti` (
  `graffitiID` int DEFAULT NULL,
  `graffitiX` float DEFAULT '0',
  `graffitiY` float DEFAULT '0',
  `graffitiZ` float DEFAULT '0',
  `graffitiAngle` float DEFAULT '0',
  `graffitiColor` int DEFAULT '0',
  `graffitiText` varchar(64) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Structure de la table `houses`
--

CREATE TABLE `houses` (
  `id` int NOT NULL,
  `ownerid` int DEFAULT '0',
  `owner` varchar(24) DEFAULT 'Nobody',
  `type` tinyint DEFAULT '0',
  `price` int DEFAULT '0',
  `rentprice` int DEFAULT '0',
  `level` tinyint DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `timestamp` int DEFAULT '0',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `int_x` float DEFAULT '0',
  `int_y` float DEFAULT '0',
  `int_z` float DEFAULT '0',
  `int_a` float DEFAULT '0',
  `interior` tinyint DEFAULT '0',
  `world` int DEFAULT '0',
  `outsideint` int DEFAULT '0',
  `outsidevw` int DEFAULT '0',
  `cash` int DEFAULT '0',
  `materials` int DEFAULT '0',
  `pot` int DEFAULT '0',
  `crack` int DEFAULT '0',
  `meth` int DEFAULT '0',
  `painkillers` int DEFAULT '0',
  `weapon_1` tinyint DEFAULT '0',
  `weapon_2` tinyint DEFAULT '0',
  `weapon_3` tinyint DEFAULT '0',
  `weapon_4` tinyint DEFAULT '0',
  `weapon_5` tinyint DEFAULT '0',
  `weapon_6` tinyint DEFAULT '0',
  `weapon_7` tinyint DEFAULT '0',
  `weapon_8` tinyint DEFAULT '0',
  `weapon_9` tinyint DEFAULT '0',
  `weapon_10` tinyint DEFAULT '0',
  `ammo_1` smallint DEFAULT '0',
  `ammo_2` smallint DEFAULT '0',
  `ammo_3` smallint DEFAULT '0',
  `ammo_4` smallint DEFAULT '0',
  `ammo_5` smallint DEFAULT '0',
  `ammo_6` tinyint DEFAULT '0',
  `ammo_7` tinyint DEFAULT '0',
  `ammo_8` tinyint DEFAULT '0',
  `ammo_9` tinyint DEFAULT '0',
  `ammo_10` tinyint DEFAULT '0',
  `pistolammo` smallint DEFAULT '0',
  `shotgunammo` smallint DEFAULT '0',
  `smgammo` smallint DEFAULT '0',
  `arammo` smallint DEFAULT '0',
  `rifleammo` smallint DEFAULT '0',
  `hpammo` smallint DEFAULT '0',
  `poisonammo` smallint DEFAULT '0',
  `fmjammo` smallint DEFAULT '0',
  `robbed` smallint NOT NULL DEFAULT '3',
  `robbing` smallint NOT NULL DEFAULT '3'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `houses`
--

INSERT INTO `houses` (`id`, `ownerid`, `owner`, `type`, `price`, `rentprice`, `level`, `locked`, `timestamp`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `int_x`, `int_y`, `int_z`, `int_a`, `interior`, `world`, `outsideint`, `outsidevw`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `weapon_4`, `weapon_5`, `weapon_6`, `weapon_7`, `weapon_8`, `weapon_9`, `weapon_10`, `ammo_1`, `ammo_2`, `ammo_3`, `ammo_4`, `ammo_5`, `ammo_6`, `ammo_7`, `ammo_8`, `ammo_9`, `ammo_10`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `robbed`, `robbing`) VALUES
(301, 1308, 'Musashi_Lucas', 12, 2100000, 0, 5, 0, 1689833302, 2242.22, -1171.25, 1029.8, 88.235, 2269.91, -1210.5, 1047.56, 90, 10, 1000301, 15, 4000015, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(303, 1191, 'ZIZEWAR_X', 12, 2100000, 0, 5, 0, 1691121542, 1545.49, -1582.96, 13.547, -144.38, 2269.91, -1210.5, 1047.56, 90, 10, 1000303, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 0, 0, 27, 27, 27, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(304, 772, 'mbli_blhxix', 12, 2100000, 0, 5, 1, 1691708920, 1536.17, -1582.83, 13.547, -134.971, 2269.91, -1210.5, 1047.56, 90, 10, 1000304, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(305, 1584, 'Jack_XviLo', 12, 2100000, 0, 5, 1, 1691324817, 1527.03, -1582.54, 13.547, -133.718, 2269.91, -1210.5, 1047.56, 90, 10, 1000305, 0, 0, 0, 0, 0, 197, 0, 13, 27, 30, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(306, 1191, 'ZIZEWAR_X', 12, 2100000, 0, 2, 1, 1689787593, 1517.02, -1582.49, 13.547, -107.628, 2269.91, -1210.5, 1047.56, 90, 10, 1000306, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(307, 513, 'YASSINE_CASSTILANO', 12, 2100000, 0, 0, 1, 1691390997, 1507.78, -1582.45, 13.547, -108.089, 2269.91, -1210.5, 1047.56, 90, 10, 1000307, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(308, 1191, 'ZIZEWAR_X', 12, 2100000, 0, 0, 0, 1689280743, 1488.44, -1582.44, 13.547, -127.303, 2269.91, -1210.5, 1047.56, 90, 10, 1000308, 0, 0, -1821, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(309, 611, '$LOKER_JOKER$$8', 12, 2100000, 0, 5, 0, 1691628903, 1471.25, -1582.44, 13.547, 117.298, 2269.91, -1210.5, 1047.56, 90, 10, 1000309, 0, 0, -2325, 0, 0, 188, 0, 0, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(310, 862, 'ZOU_HIR', 12, 2100000, 10000, 0, 1, 1691536542, 1451.74, -1582.44, 13.547, -127.354, 2269.91, -1210.5, 1047.56, 90, 10, 1000310, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(311, 3545, 'WLD_ZA3IMA', 12, 2100000, 10000, 0, 0, 1691707246, 1179.9, -1261.22, 15.18, -98.9, 2269.91, -1210.5, 1047.56, 90, 10, 1000311, 0, 0, -902, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(312, 1307, 'salah_kanita', 12, 2100000, 0, 0, 1, 1689710656, 1187.45, -1261.19, 15.18, 116.657, 2269.91, -1210.5, 1047.56, 90, 10, 1000312, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(314, 635, 'AZGHAR__LHAJ', 12, 2100000, 0, 0, 1, 1689033871, 1187.35, -1254.99, 18.898, 70.393, 2269.91, -1210.5, 1047.56, 90, 10, 1000314, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(315, 1148, 'Abde_ssamad', 12, 2100000, 0, 0, 1, 1689544888, 1179.82, -1254.44, 18.898, -102.641, 2269.91, -1210.5, 1047.56, 90, 10, 1000315, 0, 0, -1276, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(316, 646, '_BRITILLE_', 12, 2100000, 0, 5, 0, 1690482913, 1179.9, -1260.73, 18.898, -89.776, 2269.91, -1210.5, 1047.56, 90, 10, 1000316, 0, 0, -502, 0, 0, 200, 0, 0, 24, 31, 31, 24, 24, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(317, 1061, 'OSLO_MARLY', 12, 2100000, 0, 2, 0, 1689521588, 1187.45, -1261.14, 18.898, 90.536, 2269.91, -1210.5, 1047.56, 90, 10, 1000317, 0, 0, 0, 0, 0, 0, 0, 0, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(320, 522, 'Lhaj_Lmernisi', 12, 2100000, 0, 1, 1, 1689767919, 1187.36, -1227.14, 18.555, 144.515, 2269.91, -1210.5, 1047.56, 90, 10, 1000320, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(321, 427, 'BO9AL_V2', 12, 2100000, 10000, 1, 1, 1691600158, 1179.82, -1227.58, 18.555, -46.096, 2269.91, -1210.5, 1047.56, 90, 10, 1000321, 0, 0, 5001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(323, 1, 'AHMED_FF', 12, 2100000, 0, 0, 0, 1688585795, 1179.81, -1226.98, 22.141, -100.099, 2269.91, -1210.5, 1047.56, 90, 10, 1000323, 0, 0, -1769, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(324, 1045, 'achraf_miko', 12, 2100000, 0, 2, 1, 1689111640, 1179.89, -1233.09, 22.141, -107.819, 2269.91, -1210.5, 1047.56, 90, 10, 1000324, 0, 0, 0, 0, 0, 50, 0, 0, 34, 0, 0, 34, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(325, 1859, 'Younsse_Allamy', 12, 2100000, 0, 5, 0, 1691700386, 1187.44, -1233.49, 22.141, 84.971, 2269.91, -1210.5, 1047.56, 90, 10, 1000325, 0, 0, -677, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(327, 1192, 'I_NAMOSE', 14, 2500000, 0, 5, 0, 1691510868, 254.438, -1367.21, 53.109, -52.576, 2324.39, -1148.88, 1050.71, 0, 12, 1000327, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(328, 1519, 'Boonina_Millions', 14, 0, 0, 0, 1, 1691792127, 298.941, -1338.43, 53.44, 41.649, 2324.39, -1148.88, 1050.71, 0, 12, 1000328, 0, 0, -2606, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(330, 597, 'MOULL_SLAWI', 12, 2100000, 0, 0, 0, 1689573361, 398.382, -1271.28, 50.02, 33.481, 2269.91, -1210.5, 1047.56, 90, 10, 1000330, 0, 0, -887, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(331, 2492, '_BRAZELI_BRZ_', 12, 2100000, 0, 5, 0, 1691537226, 432.228, -1253.89, 51.581, 20.253, 2269.91, -1210.5, 1047.56, 90, 10, 1000331, 0, 0, -812, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(332, 555, 'LVASTO_Alvaro', 12, 2100000, 0, 0, 1, 1691375350, 252.833, -1270.26, 74.437, 17.045, 2269.91, -1210.5, 1047.56, 90, 10, 1000332, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(333, 633, 'Za3ima_Aya', 12, 2100000, 0, 0, 0, 1691618511, 251.378, -1220.25, 76.102, -151.915, 2269.91, -1210.5, 1047.56, 90, 10, 1000333, 0, 0, -1472, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(334, 1519, 'Boonina_Millions', -1, 2100000, 0, 5, 1, 1691792403, 300.561, -1154.77, 81.395, 153.074, 226.467, 1113.99, 1080.99, 100.63, 5, 1000334, 0, 0, 0, 100000, 0, 0, 0, 0, 24, 29, 30, 30, 30, 24, 24, 24, 29, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(335, 1819, 'LA_BANDA_16', 12, 2100000, 0, 0, 1, 1691885755, 352.316, -1197.85, 76.516, 45.124, 2269.91, -1210.5, 1047.56, 90, 10, 1000335, 0, 0, -2007, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(336, 0, 'Nobody', 12, 2100000, 0, 5, 0, 1689709604, 2242.38, -1170.83, 1029.8, 140.695, 2269.91, -1210.5, 1047.56, 90, 10, 1000336, 15, 4000024, 0, 0, 0, 0, 0, 0, 38, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(338, 442, 'DEV_BABLO', -1, 2800000, 0, 0, 0, 1690899087, 1534.5, -800.209, 72.849, 100.619, 1534.5, -800.209, 72.849, 280.619, 0, 1000338, 0, 0, -1058, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(339, 0, 'Nobody', 19, 21000000, 0, 0, 0, 0, 1534.43, -800.023, 72.849, 88.116, 0, 0, 0, 0, 0, 1000339, 0, 1000338, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(349, 524, 'monster_yt', 12, 2100000, 0, 3, 1, 1691601983, 305.514, -1770.45, 4.54, -140.272, 2269.91, -1210.5, 1047.56, 90, 10, 1000349, 0, 0, 0, 0, 0, 0, 0, 0, 29, 27, 34, 31, 25, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(350, 620, 'Lorenzo_Mp3', 12, 2100000, 0, 5, 0, 1691763724, 280.52, -1767.67, 4.537, -152.309, 2269.91, -1210.5, 1047.56, 90, 10, 1000350, 0, 0, -575, 0, 0, 200, 0, 0, 24, 31, 29, 27, 4, 31, 27, 4, 29, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(351, 1882, 'Wassim_RUSSI', 12, 2100000, 0, 4, 0, 1690575732, 263.621, -1765.49, 4.749, -160.076, 2269.91, -1210.5, 1047.56, 90, 10, 1000351, 0, 0, 0, 0, 0, 0, 0, 0, 29, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(354, 421, 'SENIOR___CASPER', 12, 2100000, 0, 5, 0, 1691083411, 169.582, -1769.32, 4.48, -95.935, 2269.91, -1210.5, 1047.56, 90, 10, 1000354, 0, 0, -2195, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(357, 576, 'ELPADRO_MADRIDI', 12, 2100000, 0, 5, 1, 1688741082, 2014.33, -1732.82, 14.21, 62.896, 2269.91, -1210.5, 1047.56, 90, 10, 1000357, 0, 0, 499180, 0, 0, 0, 0, 0, 3, 24, 25, 0, 0, 29, 24, 25, 31, 34, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(358, 472, 'IMAD_LUCIANO', 18, 14000000, 0, 5, 0, 1691721553, 497.333, -1094.71, 82.359, -10.583, 1298.87, -796.205, 1084.01, 0, 5, 1000358, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(361, 1308, 'Musashi_Lucas', 12, 2100000, 0, 5, 0, 1691388654, 189.639, -1308.24, 70.256, -111.542, 2269.91, -1210.5, 1047.56, 90, 10, 1000361, 0, 0, -615, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(367, 1171, 'ZWITA_', 18, 14000000, 0, 5, 1, 1691548945, 219.079, -1249.91, 78.338, -122.274, 1298.87, -796.205, 1084.01, 0, 5, 1000367, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(368, 1505, 'asta_adreson', 12, 2100000, 0, 4, 0, 1689861655, 2454.3, -965.176, 80.067, -91.326, 2269.91, -1210.5, 1047.56, 90, 10, 1000368, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(370, 877, 'L7AJ_ZIAD', 18, 14000000, 0, 0, 0, 1691598540, 1044.89, -642.618, 120.117, -137.06, 1298.87, -796.205, 1084.01, 0, 5, 1000370, 0, 0, -1457, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(371, 2789, 'SI_ALI', 12, 2100000, 0, 0, 0, 1691681756, 745.203, -556.78, 18.013, -1.59, 2269.91, -1210.5, 1047.56, 90, 10, 1000371, 0, 0, -521, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(372, 1585, 'be_znaz', 12, 2100000, 0, 5, 0, 1691787167, 766.252, -556.783, 18.013, 68.032, 2269.91, -1210.5, 1047.56, 90, 10, 1000372, 0, 0, -885, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(373, 1534, 'vergas__', 12, 2100000, 0, 0, 1, 1690215201, 795.071, -506.516, 18.013, -3.344, 2269.91, -1210.5, 1047.56, 90, 10, 1000373, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(374, 1192, 'I_NAMOSE', 12, 2100000, 0, 0, 0, 1689576034, 714.288, -568.56, 16.336, 95.873, 2269.91, -1210.5, 1047.56, 90, 10, 1000374, 0, 0, -1828, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(375, 1499, 'RWAYZA_SBK', 12, 2100000, 0, 0, 1, 1691723696, 701.718, -609.778, 16.336, 27.25, 2269.91, -1210.5, 1047.56, 90, 10, 1000375, 0, 0, -1301, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(376, 620, 'Lorenzo_Mp3', 12, 2100000, 0, 5, 0, 1691329669, 661.939, -651.148, 16.378, 127.172, 2269.91, -1210.5, 1047.56, 90, 10, 1000376, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(377, 1748, 'Marwa_Tiso', 12, 2100000, 0, 5, 0, 1691129685, 192.77, -1769.5, 4.315, -27.674, 2269.91, -1210.5, 1047.56, 90, 10, 1000377, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(378, 1589, 'Lil_Tetsuya', 12, 2100000, 0, 0, 1, 1691219047, 207.128, -1769.04, 4.371, 65.798, 2269.91, -1210.5, 1047.56, 90, 10, 1000378, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(379, 2375, 'NINJA_NETWORK', 12, 2100000, 0, 0, 1, 1690551601, 1183.36, -1099.01, 28.258, -78.827, 2269.91, -1210.5, 1047.56, 90, 10, 1000379, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(380, 1471, 'IRT_WLD_ALI', 18, 14000000, 0, 0, 1, 1691607105, 1332.22, -633.418, 109.135, -159.436, 1298.87, -796.205, 1084.01, 0, 5, 1000380, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(381, 1764, 'anas_psico', 18, 14000000, 0, 5, 0, 1691551223, 835.969, -894.864, 68.773, -27.317, 1298.87, -796.205, 1084.01, 0, 5, 1000381, 0, 0, -2730, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(382, 407, 'oussama_r', 2, 12000, 0, 0, 1, 1691716869, 2582.91, -952.934, 81.38, 178.635, 2259.76, -1135.88, 1050.63, 270, 10, 1000382, 0, 0, -1300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(385, 535, 'Ilyas_Newton', 18, 14000000, 0, 0, 0, 1691294568, 1298.47, -797.982, 84.141, 159.435, 1298.87, -796.205, 1084.01, 0, 5, 1000385, 0, 0, -1082, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(386, 1589, 'Lil_Tetsuya', -1, 12000, 0, 0, 0, 1691312119, 827.747, -858.006, 70.331, -146.843, 226.674, 1114.15, 1080.99, 91.383, 5, 1000386, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(387, 633, 'Za3ima_Aya', -1, 850000, 0, 0, 0, 1691618611, 416.373, -1154.74, 76.688, 145.23, 226.296, 1114.38, 1080.98, 86.904, 5, 1000387, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(389, 1291, 'Shark_Bernard', -1, 850000, 0, 0, 0, 1690468542, 1095.17, -646.984, 113.648, -6.363, 226.296, 1114.1, 1080.98, 85.646, 5, 1000389, 0, 0, -795, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(390, 1285, 'WALD_FAVELAS', -1, 850000, 0, 0, 1, 1691503202, 980.187, -677.069, 121.976, 22.183, 234.333, 1063.77, 1084.21, 183.123, 6, 1000390, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(391, 3643, 'MITO_', -1, 850000, 0, 0, 1, 1691791373, 228.779, -1404.19, 51.607, -27.911, 23.221, 1407.06, 1084.43, 197.868, 5, 1000391, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(392, 765, '3A_BO9A', -1, 850000, 10000, 5, 0, 1691449250, 1535.39, -2173.93, 13.555, 172.188, 226.3, 1114.12, 1080.98, 86.659, 5, 1000392, 0, 0, -509, 0, 0, 0, 0, 0, 24, 27, 31, 24, 27, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(393, 472, 'IMAD_LUCIANO', 12, 2100000, 0, 0, 0, 1691327186, 315.647, -1769.43, 4.627, -179.691, 2269.91, -1210.5, 1047.56, 90, 10, 1000393, 0, 0, -2869, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(395, 2858, 'Saad_Eltchapo', 18, 14000000, 0, 0, 0, 1691033935, -2316.97, -1641.03, 483.703, -168.49, 1298.87, -796.205, 1084.01, 0, 5, 1000395, 0, 0, -797, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(402, 498, 'mo_rad', 14, 2500000, 0, 0, 1, 1691861935, 849.648, -1519.86, 14.348, -90.3, 2324.39, -1148.88, 1050.71, 0, 12, 1000402, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(403, 535, 'Ilyas_Newton', 12, 2100000, 0, 0, 0, 1691353206, 822.422, -1505.51, 14.395, 1.397, 2269.91, -1210.5, 1047.56, 90, 10, 1000403, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3),
(404, 862, 'ZOU_HIR', 18, 14000000, 10000, 0, 1, 1691711370, 1497.11, -687.891, 95.563, 176.344, 1298.87, -796.205, 1084.01, 0, 5, 1000404, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3);

-- --------------------------------------------------------

--
-- Structure de la table `kills`
--

CREATE TABLE `kills` (
  `id` int NOT NULL,
  `killer_uid` int DEFAULT NULL,
  `target_uid` int DEFAULT NULL,
  `killer` varchar(24) DEFAULT NULL,
  `target` varchar(24) DEFAULT NULL,
  `reason` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `landobjects`
--

CREATE TABLE `landobjects` (
  `id` int NOT NULL,
  `landid` int DEFAULT NULL,
  `modelid` smallint DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `price` int DEFAULT NULL,
  `pos_x` float DEFAULT NULL,
  `pos_y` float DEFAULT NULL,
  `pos_z` float DEFAULT NULL,
  `rot_x` float DEFAULT NULL,
  `rot_y` float DEFAULT NULL,
  `rot_z` float DEFAULT NULL,
  `door_opened` tinyint(1) DEFAULT '0',
  `door_locked` tinyint(1) DEFAULT '0',
  `move_x` float DEFAULT '0',
  `move_y` float DEFAULT '0',
  `move_z` float DEFAULT '0',
  `move_rx` float DEFAULT '0',
  `move_ry` float DEFAULT '0',
  `move_rz` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `lands`
--

CREATE TABLE `lands` (
  `id` int NOT NULL,
  `ownerid` int DEFAULT '0',
  `owner` varchar(24) DEFAULT 'Nobody',
  `price` int DEFAULT '0',
  `min_x` float DEFAULT '0',
  `min_y` float DEFAULT '0',
  `max_x` float DEFAULT '0',
  `max_y` float DEFAULT '0',
  `height` float DEFAULT '0',
  `lx` float NOT NULL,
  `ly` float NOT NULL,
  `lz` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_admin`
--

CREATE TABLE `log_admin` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_bans`
--

CREATE TABLE `log_bans` (
  `id` int NOT NULL,
  `uid` int DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_cheat`
--

CREATE TABLE `log_cheat` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_contracts`
--

CREATE TABLE `log_contracts` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_faction`
--

CREATE TABLE `log_faction` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_gang`
--

CREATE TABLE `log_gang` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_give`
--

CREATE TABLE `log_give` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_namechanges`
--

CREATE TABLE `log_namechanges` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_property`
--

CREATE TABLE `log_property` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_punishments`
--

CREATE TABLE `log_punishments` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_referrals`
--

CREATE TABLE `log_referrals` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_vip`
--

CREATE TABLE `log_vip` (
  `id` int NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `object`
--

CREATE TABLE `object` (
  `mobjID` int NOT NULL,
  `mobjModel` int NOT NULL DEFAULT '0',
  `mobjX` float NOT NULL DEFAULT '0',
  `mobjY` float NOT NULL DEFAULT '0',
  `mobjZ` float NOT NULL DEFAULT '0',
  `mobjRX` float NOT NULL DEFAULT '0',
  `mobjRY` float NOT NULL DEFAULT '0',
  `mobjRZ` float NOT NULL DEFAULT '0',
  `mobjInterior` int NOT NULL DEFAULT '0',
  `mobjWorld` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `phonebook`
--

CREATE TABLE `phonebook` (
  `name` varchar(24) DEFAULT NULL,
  `number` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `phone_contacts`
--

CREATE TABLE `phone_contacts` (
  `contact_id` int NOT NULL,
  `phone_number` int NOT NULL,
  `contact_name` varchar(24) NOT NULL,
  `contact_number` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `points`
--

CREATE TABLE `points` (
  `id` tinyint DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `capturedby` varchar(24) DEFAULT 'No-one',
  `capturedgang` tinyint DEFAULT '-1',
  `type` tinyint DEFAULT '0',
  `profits` int DEFAULT '0',
  `time` tinyint DEFAULT '10',
  `point_x` float DEFAULT '0',
  `point_y` float DEFAULT '0',
  `point_z` float DEFAULT '0',
  `pointinterior` tinyint DEFAULT '0',
  `pointworld` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `safezone`
--

CREATE TABLE `safezone` (
  `id` int NOT NULL DEFAULT '0',
  `x` int NOT NULL DEFAULT '0',
  `y` int NOT NULL DEFAULT '0',
  `z` int NOT NULL DEFAULT '0',
  `range` int NOT NULL DEFAULT '0',
  `reason` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `shots`
--

CREATE TABLE `shots` (
  `id` int NOT NULL,
  `playerid` smallint DEFAULT NULL,
  `weaponid` tinyint DEFAULT NULL,
  `hittype` tinyint DEFAULT NULL,
  `hitid` int DEFAULT NULL,
  `hitplayer` varchar(24) DEFAULT NULL,
  `pos_x` float DEFAULT NULL,
  `pos_y` float DEFAULT NULL,
  `pos_z` float DEFAULT NULL,
  `timestamp` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `speedcameras`
--

CREATE TABLE `speedcameras` (
  `speedID` int NOT NULL,
  `speedRange` float DEFAULT '0',
  `speedLimit` float DEFAULT '0',
  `speedX` float DEFAULT '0',
  `speedY` float DEFAULT '0',
  `speedZ` float DEFAULT '0',
  `speedAngle` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `texts`
--

CREATE TABLE `texts` (
  `id` int NOT NULL,
  `sender_number` int DEFAULT NULL,
  `recipient_number` int DEFAULT NULL,
  `sender` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `turfs`
--

CREATE TABLE `turfs` (
  `id` tinyint DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `capturedby` varchar(24) DEFAULT 'No-one',
  `capturedgang` tinyint DEFAULT '-1',
  `type` tinyint DEFAULT '0',
  `time` tinyint DEFAULT '12',
  `min_x` float DEFAULT '0',
  `min_y` float DEFAULT '0',
  `max_x` float DEFAULT '0',
  `max_y` float DEFAULT '0',
  `height` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `turfs`
--

INSERT INTO `turfs` (`id`, `name`, `capturedby`, `capturedgang`, `type`, `time`, `min_x`, `min_y`, `max_x`, `max_y`, `height`) VALUES
(3, 'Skate Park', 'NAMOSE_X', 3, 7, 11, 1860.79, -1452.6, 1979.1, -1349.33, 13.554),
(4, 'Glen Park', 'Nabil_Vinsmoke', 6, 7, 4, 1859.89, -1254.1, 2059, -1143.17, 23.898),
(5, 'Ocean Docks', 'Nabil_Vinsmoke', 6, 7, 0, 2167.89, -2690.58, 2255.18, -2525.45, 8.296),
(6, 'LS Stadium', 'NAMOSE_X', 3, 7, 4, 2650.34, -1869.07, 2816.95, -1660.8, 10.763),
(7, 'Business Park', 'WALD_FAVELAS', 10, 7, 3, 453.554, -1582.54, 522.652, -1434.68, 15.715),
(9, 'MontGomery', 'Nabil_Vinsmoke', 6, 7, 0, 1180.11, 149.762, 1411.73, 395.403, 21.407),
(11, 'Nationwide International Airpor', 'Nabil_Vinsmoke', 6, 7, 0, 1354.61, -2370.24, 1566.32, -2201.98, 13.547),
(10, 'Light House', 'Nabil_Vinsmoke', 6, 7, 0, 127.316, -1969.6, 168.727, -1778.69, -0.589),
(1, 'sf turf', 'Tokyo_Drag', 5, 7, 0, -2144.95, 96.688, -2040.17, 283.073, 52.023),
(2, 'sf turfs', '9TALE_TALIANI', 6, 7, 0, -2185.09, -496.025, -1986.39, -103.615, 59.452),
(8, 'sf turfs', 'Nabil_Vinsmoke', 6, 7, 0, -2085.1, -966.902, -1937.01, -740.306, 39.556),
(12, 'sf turfs', 'No-one', -1, 7, 0, -1877.8, 1268.73, -1752.93, 1306.67, 62.484),
(13, 'turf cracl', 'Tokyo_Drag', 5, 7, 0, -2125.23, 824.999, -2019.39, 1114.38, 82.373),
(14, 'turf sf', 'Nabil_Vinsmoke', 6, 7, 0, -2670.49, 329.69, -2623.49, 457.743, 25.899),
(15, 'turf sf', 'Musashi_Sense', -1, 7, 0, -2802.63, 281.105, -2615.28, 451.217, 12.085),
(16, 'turf', 'Musashi_Sense', -1, 7, 0, -2693.45, -221.285, -2590.03, -80.954, 4.328);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `uid` int NOT NULL,
  `username` varchar(24) DEFAULT NULL,
  `password` varchar(129) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `ip` varchar(16) DEFAULT NULL,
  `setup` tinyint(1) DEFAULT '1',
  `gender` tinyint(1) DEFAULT '1',
  `age` tinyint DEFAULT '18',
  `skin` smallint DEFAULT '299',
  `camera_x` float DEFAULT '0',
  `camera_y` float DEFAULT '0',
  `camera_z` float DEFAULT '0',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `interior` tinyint DEFAULT '0',
  `world` int DEFAULT '0',
  `cash` int DEFAULT '50000',
  `bank` int DEFAULT '50000',
  `paycheck` int DEFAULT '0',
  `level` int DEFAULT '1',
  `exp` int DEFAULT '0',
  `minutes` smallint DEFAULT '0',
  `hours` int DEFAULT '2',
  `adminlevel` int DEFAULT '0',
  `adminname` varchar(24) DEFAULT 'None',
  `helperlevel` tinyint DEFAULT '0',
  `health` float DEFAULT '100',
  `armor` float DEFAULT '0',
  `upgradepoints` int DEFAULT '0',
  `warnings` tinyint DEFAULT '0',
  `injured` tinyint(1) DEFAULT '0',
  `hospital` tinyint(1) DEFAULT '0',
  `spawnhealth` float DEFAULT '50',
  `spawnarmor` float DEFAULT '0',
  `jailtype` tinyint(1) DEFAULT '0',
  `jailtime` int DEFAULT '0',
  `newbiemuted` tinyint(1) DEFAULT '0',
  `helpmuted` tinyint(1) DEFAULT '0',
  `admuted` tinyint(1) DEFAULT '0',
  `livemuted` tinyint(1) DEFAULT '0',
  `globalmuted` tinyint(1) DEFAULT '0',
  `reportmuted` tinyint DEFAULT '0',
  `reportwarns` tinyint DEFAULT '0',
  `fightstyle` tinyint DEFAULT '4',
  `locked` tinyint(1) DEFAULT '0',
  `accent` varchar(16) DEFAULT 'None',
  `cookies` int DEFAULT '0',
  `phone` int DEFAULT '0',
  `job` int DEFAULT '-1',
  `secondjob` tinyint DEFAULT '-1',
  `crimes` int DEFAULT '0',
  `arrested` int DEFAULT '0',
  `wantedlevel` tinyint DEFAULT '0',
  `materials` int DEFAULT '0',
  `pot` int DEFAULT '0',
  `crack` int DEFAULT '0',
  `meth` int DEFAULT '0',
  `painkillers` int DEFAULT '0',
  `seeds` int DEFAULT '0',
  `ephedrine` int DEFAULT '0',
  `muriaticacid` int DEFAULT '0',
  `bakingsoda` int DEFAULT '0',
  `cigars` int DEFAULT '0',
  `weaponclip` int DEFAULT '0',
  `walkietalkie` tinyint(1) DEFAULT '0',
  `channel` int DEFAULT '0',
  `rentinghouse` int DEFAULT '0',
  `spraycans` int DEFAULT '0',
  `boombox` tinyint(1) DEFAULT '0',
  `mp3player` tinyint(1) DEFAULT '0',
  `phonebook` tinyint(1) DEFAULT '0',
  `fishingrod` tinyint(1) DEFAULT '0',
  `fishingbait` int DEFAULT '0',
  `fishweight` int DEFAULT '0',
  `components` int DEFAULT '0',
  `courierskill` int DEFAULT '0',
  `fishingskill` int DEFAULT '0',
  `guardskill` int DEFAULT '0',
  `weaponskill` int DEFAULT '0',
  `mechanicskill` int DEFAULT '0',
  `lawyerskill` int DEFAULT '0',
  `smugglerskill` int DEFAULT '0',
  `toggletextdraws` tinyint(1) DEFAULT '0',
  `toggleooc` tinyint(1) DEFAULT '0',
  `togglephone` tinyint(1) DEFAULT '0',
  `toggleadmin` tinyint(1) DEFAULT '0',
  `togglehelper` tinyint(1) DEFAULT '0',
  `togglenewbie` tinyint(1) DEFAULT '0',
  `togglewt` tinyint(1) DEFAULT '0',
  `toggleradio` tinyint(1) DEFAULT '0',
  `togglevip` tinyint(1) DEFAULT '0',
  `togglemusic` tinyint(1) DEFAULT '0',
  `togglefaction` tinyint(1) DEFAULT '0',
  `togglegang` tinyint(1) DEFAULT '0',
  `togglenews` tinyint(1) DEFAULT '0',
  `toggleglobal` tinyint(1) DEFAULT '0',
  `togglecam` tinyint(1) DEFAULT '0',
  `carlicense` tinyint(1) DEFAULT '0',
  `vippackage` tinyint NOT NULL DEFAULT '2',
  `viptime` int DEFAULT '1290000',
  `vipcooldown` int DEFAULT '0',
  `weapon_0` tinyint DEFAULT '0',
  `weapon_1` tinyint DEFAULT '0',
  `weapon_2` tinyint DEFAULT '0',
  `weapon_3` tinyint DEFAULT '0',
  `weapon_4` tinyint DEFAULT '0',
  `weapon_5` tinyint DEFAULT '0',
  `weapon_6` tinyint DEFAULT '0',
  `weapon_7` tinyint DEFAULT '0',
  `weapon_8` tinyint DEFAULT '0',
  `weapon_9` tinyint DEFAULT '0',
  `weapon_10` tinyint DEFAULT '0',
  `weapon_11` tinyint DEFAULT '0',
  `weapon_12` tinyint DEFAULT '0',
  `ammo_0` smallint DEFAULT '0',
  `ammo_1` smallint DEFAULT '0',
  `ammo_2` smallint DEFAULT '0',
  `ammo_3` smallint DEFAULT '0',
  `ammo_4` smallint DEFAULT '0',
  `ammo_5` smallint DEFAULT '0',
  `ammo_6` smallint DEFAULT '0',
  `ammo_7` smallint DEFAULT '0',
  `ammo_8` smallint DEFAULT '0',
  `ammo_9` smallint DEFAULT '0',
  `ammo_10` smallint DEFAULT '0',
  `ammo_11` smallint DEFAULT '0',
  `ammo_12` smallint DEFAULT '0',
  `faction` tinyint DEFAULT '-1',
  `gang` tinyint DEFAULT '-1',
  `factionrank` tinyint DEFAULT '0',
  `gangrank` tinyint DEFAULT '0',
  `division` tinyint DEFAULT '-1',
  `contracted` int DEFAULT '0',
  `contractby` varchar(24) DEFAULT 'Nobody',
  `bombs` int DEFAULT '0',
  `completedhits` int DEFAULT '0',
  `failedhits` int DEFAULT '0',
  `reports` int DEFAULT '0',
  `helprequests` int DEFAULT '0',
  `speedometer` tinyint(1) DEFAULT '1',
  `factionmod` tinyint(1) DEFAULT '0',
  `gangmod` tinyint(1) DEFAULT '0',
  `banappealer` tinyint(1) DEFAULT '0',
  `potplanted` tinyint(1) DEFAULT '0',
  `pottime` int DEFAULT '0',
  `potgrams` int DEFAULT '0',
  `pot_x` float DEFAULT '0',
  `pot_y` float DEFAULT '0',
  `pot_z` float DEFAULT '0',
  `pot_a` float DEFAULT '0',
  `inventoryupgrade` int DEFAULT '0',
  `addictupgrade` int DEFAULT '0',
  `traderupgrade` int DEFAULT '0',
  `assetupgrade` int DEFAULT '0',
  `laborupgrade` int NOT NULL DEFAULT '0',
  `pistolammo` smallint DEFAULT '0',
  `shotgunammo` smallint DEFAULT '0',
  `smgammo` smallint DEFAULT '0',
  `arammo` smallint DEFAULT '0',
  `rifleammo` smallint DEFAULT '0',
  `hpammo` smallint DEFAULT '0',
  `poisonammo` smallint DEFAULT '0',
  `fmjammo` smallint DEFAULT '0',
  `ammotype` tinyint DEFAULT '0',
  `ammoweapon` tinyint DEFAULT '0',
  `dmwarnings` tinyint DEFAULT '0',
  `weaponrestricted` int DEFAULT '0',
  `referral_uid` int DEFAULT '0',
  `refercount` int DEFAULT '0',
  `watch` tinyint(1) DEFAULT '0',
  `gps` tinyint(1) DEFAULT '0',
  `prisonedby` varchar(24) DEFAULT 'No-one',
  `prisonreason` varchar(128) DEFAULT 'None',
  `togglehud` tinyint(1) DEFAULT '1',
  `clothes` smallint DEFAULT '-1',
  `showturfs` tinyint(1) DEFAULT '0',
  `showlands` tinyint(1) DEFAULT '0',
  `watchon` tinyint(1) DEFAULT '0',
  `gpson` tinyint(1) DEFAULT '0',
  `doublexp` int DEFAULT '0',
  `couriercooldown` int DEFAULT '0',
  `pizzacooldown` int DEFAULT '0',
  `detectivecooldown` int DEFAULT '0',
  `duty` int DEFAULT '0',
  `bandana` int NOT NULL DEFAULT '0',
  `detectiveskill` int DEFAULT '0',
  `gascan` int DEFAULT '0',
  `refunded` int DEFAULT '0',
  `backpack` int DEFAULT '0',
  `bpcash` int DEFAULT '0',
  `bpmaterials` int DEFAULT '0',
  `bppot` int DEFAULT '0',
  `bpcrack` int DEFAULT '0',
  `bpmeth` int DEFAULT '0',
  `bppainkillers` int DEFAULT '0',
  `bpweapon_0` int DEFAULT '0',
  `bpweapon_1` int DEFAULT '0',
  `bpweapon_2` int DEFAULT '0',
  `bpweapon_3` int DEFAULT '0',
  `bpweapon_4` int DEFAULT '0',
  `bpweapon_5` int DEFAULT '0',
  `bpweapon_6` int DEFAULT '0',
  `bpweapon_7` int DEFAULT '0',
  `bpweapon_8` int DEFAULT '0',
  `bpweapon_9` int DEFAULT '0',
  `bpweapon_10` int DEFAULT '0',
  `bpweapon_11` int DEFAULT '0',
  `bpweapon_12` int DEFAULT '0',
  `bpweapon_13` int DEFAULT '0',
  `bpweapon_14` int DEFAULT '0',
  `bphpammo` int DEFAULT '0',
  `bppoisonammo` int DEFAULT '0',
  `bpfmjammo` int DEFAULT '0',
  `formeradmin` int NOT NULL DEFAULT '0',
  `deathcooldown` int NOT NULL DEFAULT '0',
  `hunger` int NOT NULL DEFAULT '100',
  `hungertimer` int NOT NULL DEFAULT '0',
  `thirst` int NOT NULL DEFAULT '100',
  `thirsttimer` int NOT NULL DEFAULT '0',
  `covid` int NOT NULL DEFAULT '100',
  `covidtimer` int NOT NULL DEFAULT '0',
  `totalpatients` int NOT NULL DEFAULT '0',
  `totalfires` int NOT NULL DEFAULT '0',
  `rarecooldown` int NOT NULL DEFAULT '0',
  `vipdlcooldown` int NOT NULL DEFAULT '0',
  `customtitle` varchar(64) NOT NULL DEFAULT '0',
  `customcolor` varchar(16) NOT NULL DEFAULT '0',
  `mask` int NOT NULL DEFAULT '0',
  `diamonds` int NOT NULL DEFAULT '0',
  `ecoin` int NOT NULL DEFAULT '0',
  `blindfold` int NOT NULL DEFAULT '0',
  `rope` int NOT NULL DEFAULT '0',
  `lockpick` int NOT NULL DEFAULT '0',
  `repairkit` int NOT NULL DEFAULT '0',
  `goldrim` int NOT NULL DEFAULT '0',
  `food` int NOT NULL DEFAULT '0',
  `drink` int NOT NULL DEFAULT '0',
  `bandage` int NOT NULL DEFAULT '0',
  `medkit` int NOT NULL DEFAULT '0',
  `nationalid` int NOT NULL DEFAULT '0',
  `diploma` int NOT NULL DEFAULT '0',
  `insurance` int NOT NULL DEFAULT '0',
  `passport` int NOT NULL DEFAULT '0',
  `passportname` varchar(64) DEFAULT NULL,
  `passportlevel` int NOT NULL DEFAULT '0',
  `passportskin` int NOT NULL DEFAULT '0',
  `passportphone` int NOT NULL DEFAULT '0',
  `marriedto` int NOT NULL DEFAULT '-1',
  `newbies` int NOT NULL DEFAULT '0',
  `chatanim` tinyint NOT NULL DEFAULT '0',
  `Lottery` int NOT NULL DEFAULT '0',
  `LotteryB` int NOT NULL DEFAULT '0',
  `flashlight` tinyint NOT NULL DEFAULT '0',
  `candy` int NOT NULL DEFAULT '0',
  `gunlicense` tinyint NOT NULL DEFAULT '0',
  `gunlicensetime` int DEFAULT '1290000',
  `dirtycash` int NOT NULL DEFAULT '0',
  `comserv` int NOT NULL DEFAULT '0',
  `voicechat` int DEFAULT NULL,
  `discordtag` text,
  `discordname` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`uid`, `username`, `password`, `regdate`, `lastlogin`, `ip`, `setup`, `gender`, `age`, `skin`, `camera_x`, `camera_y`, `camera_z`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `interior`, `world`, `cash`, `bank`, `paycheck`, `level`, `exp`, `minutes`, `hours`, `adminlevel`, `adminname`, `helperlevel`, `health`, `armor`, `upgradepoints`, `warnings`, `injured`, `hospital`, `spawnhealth`, `spawnarmor`, `jailtype`, `jailtime`, `newbiemuted`, `helpmuted`, `admuted`, `livemuted`, `globalmuted`, `reportmuted`, `reportwarns`, `fightstyle`, `locked`, `accent`, `cookies`, `phone`, `job`, `secondjob`, `crimes`, `arrested`, `wantedlevel`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `seeds`, `ephedrine`, `muriaticacid`, `bakingsoda`, `cigars`, `weaponclip`, `walkietalkie`, `channel`, `rentinghouse`, `spraycans`, `boombox`, `mp3player`, `phonebook`, `fishingrod`, `fishingbait`, `fishweight`, `components`, `courierskill`, `fishingskill`, `guardskill`, `weaponskill`, `mechanicskill`, `lawyerskill`, `smugglerskill`, `toggletextdraws`, `toggleooc`, `togglephone`, `toggleadmin`, `togglehelper`, `togglenewbie`, `togglewt`, `toggleradio`, `togglevip`, `togglemusic`, `togglefaction`, `togglegang`, `togglenews`, `toggleglobal`, `togglecam`, `carlicense`, `vippackage`, `viptime`, `vipcooldown`, `weapon_0`, `weapon_1`, `weapon_2`, `weapon_3`, `weapon_4`, `weapon_5`, `weapon_6`, `weapon_7`, `weapon_8`, `weapon_9`, `weapon_10`, `weapon_11`, `weapon_12`, `ammo_0`, `ammo_1`, `ammo_2`, `ammo_3`, `ammo_4`, `ammo_5`, `ammo_6`, `ammo_7`, `ammo_8`, `ammo_9`, `ammo_10`, `ammo_11`, `ammo_12`, `faction`, `gang`, `factionrank`, `gangrank`, `division`, `contracted`, `contractby`, `bombs`, `completedhits`, `failedhits`, `reports`, `helprequests`, `speedometer`, `factionmod`, `gangmod`, `banappealer`, `potplanted`, `pottime`, `potgrams`, `pot_x`, `pot_y`, `pot_z`, `pot_a`, `inventoryupgrade`, `addictupgrade`, `traderupgrade`, `assetupgrade`, `laborupgrade`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `ammotype`, `ammoweapon`, `dmwarnings`, `weaponrestricted`, `referral_uid`, `refercount`, `watch`, `gps`, `prisonedby`, `prisonreason`, `togglehud`, `clothes`, `showturfs`, `showlands`, `watchon`, `gpson`, `doublexp`, `couriercooldown`, `pizzacooldown`, `detectivecooldown`, `duty`, `bandana`, `detectiveskill`, `gascan`, `refunded`, `backpack`, `bpcash`, `bpmaterials`, `bppot`, `bpcrack`, `bpmeth`, `bppainkillers`, `bpweapon_0`, `bpweapon_1`, `bpweapon_2`, `bpweapon_3`, `bpweapon_4`, `bpweapon_5`, `bpweapon_6`, `bpweapon_7`, `bpweapon_8`, `bpweapon_9`, `bpweapon_10`, `bpweapon_11`, `bpweapon_12`, `bpweapon_13`, `bpweapon_14`, `bphpammo`, `bppoisonammo`, `bpfmjammo`, `formeradmin`, `deathcooldown`, `hunger`, `hungertimer`, `thirst`, `thirsttimer`, `covid`, `covidtimer`, `totalpatients`, `totalfires`, `rarecooldown`, `vipdlcooldown`, `customtitle`, `customcolor`, `mask`, `diamonds`, `ecoin`, `blindfold`, `rope`, `lockpick`, `repairkit`, `goldrim`, `food`, `drink`, `bandage`, `medkit`, `nationalid`, `diploma`, `insurance`, `passport`, `passportname`, `passportlevel`, `passportskin`, `passportphone`, `marriedto`, `newbies`, `chatanim`, `Lottery`, `LotteryB`, `flashlight`, `candy`, `gunlicense`, `gunlicensetime`, `dirtycash`, `comserv`, `voicechat`, `discordtag`, `discordname`) VALUES
(1, 'RIDA_DHX', 'EAA18FA9CAA3AED6BD5784C8BF8F052035E0883BBDB3F0ACE470920D543AEDB61A016E1422D39D20584AEBDAD97C163756D1871A2CC715410B23F89C01C14ED9', '2026-05-19 16:47:29', '2026-05-19 17:00:43', '105.159.162.53', 0, 1, 18, 7, 475.822, -1499.63, 22.083, 477.411, -1499.52, 20.495, 273.862, 0, 0, 39415, 50000, 0, 1, 0, 11, 2, 1000, 'None', 0, 98.119, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 111111, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 100, 0, 100, 0, 0, 0, 0, 0, '0', '0', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int NOT NULL,
  `ownerid` int DEFAULT '0',
  `owner` varchar(24) DEFAULT 'Nobody',
  `modelid` smallint DEFAULT '0',
  `price` int DEFAULT '0',
  `tickets` int DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `plate` varchar(32) DEFAULT 'None',
  `fuel` tinyint DEFAULT '100',
  `health` float DEFAULT '1000',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `color1` smallint DEFAULT '0',
  `color2` smallint DEFAULT '0',
  `paintjob` smallint DEFAULT '-1',
  `registered` int DEFAULT NULL,
  `interior` tinyint DEFAULT '0',
  `world` int DEFAULT '0',
  `neon` smallint DEFAULT '0',
  `neonenabled` tinyint(1) DEFAULT '0',
  `trunk` tinyint(1) DEFAULT '0',
  `mod_1` smallint DEFAULT '0',
  `mod_2` smallint DEFAULT '0',
  `mod_3` smallint DEFAULT '0',
  `mod_4` smallint DEFAULT '0',
  `mod_5` smallint DEFAULT '0',
  `mod_6` smallint DEFAULT '0',
  `mod_7` smallint DEFAULT '0',
  `mod_8` smallint DEFAULT '0',
  `mod_9` smallint DEFAULT '0',
  `mod_10` smallint DEFAULT '0',
  `mod_11` smallint DEFAULT '0',
  `mod_12` smallint DEFAULT '0',
  `mod_13` smallint DEFAULT '0',
  `mod_14` smallint DEFAULT '0',
  `cash` int DEFAULT '0',
  `materials` int DEFAULT '0',
  `pot` int DEFAULT '0',
  `crack` int DEFAULT '0',
  `meth` int DEFAULT '0',
  `painkillers` int DEFAULT '0',
  `weapon_1` tinyint DEFAULT '0',
  `weapon_2` tinyint DEFAULT '0',
  `weapon_3` tinyint DEFAULT '0',
  `ammo_1` smallint DEFAULT '0',
  `ammo_2` smallint DEFAULT '0',
  `ammo_3` smallint DEFAULT '0',
  `gangid` tinyint DEFAULT '-1',
  `factiontype` tinyint DEFAULT '0',
  `job` tinyint DEFAULT '-1',
  `respawndelay` int DEFAULT '0',
  `pistolammo` smallint DEFAULT '0',
  `shotgunammo` smallint DEFAULT '0',
  `smgammo` smallint DEFAULT '0',
  `arammo` smallint DEFAULT '0',
  `rifleammo` smallint DEFAULT '0',
  `hpammo` smallint DEFAULT '0',
  `poisonammo` smallint DEFAULT '0',
  `fmjammo` smallint DEFAULT '0',
  `impounded` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `vehicles`
--

INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(698, 1987, 'KORSAN_DZ', 560, 2000000, 0, 1, 'None', 20, 1000, 1828.03, -1103.7, 23.593, 83.245, 0, 0, 1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 1030, 0, 1010, 1029, 1078, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(699, 466, 'IMAD_chinwi', 560, 2000000, 0, 1, 'None', 18, 998.361, 2769.64, -1610.82, 10.575, 271.792, 0, 0, 2, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 1030, 0, 1010, 1029, 1098, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(700, 777, 'Adam_Xvilo', 580, 1400000, 0, 0, 'None', 20, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(701, 1500, 'ZORO__XVILO', 580, 1400000, 0, 0, 'None', 98, 1000, 1123.45, -1411.7, 13.303, 270.837, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 1023, 0, 1006, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(702, 534, 'AYM4N_WINS', 477, 1100000, 0, 0, 'None', 20, 1000, 1453.79, -1447.61, 13.047, 114.211, 3, 3, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(703, 827, 'LMBAW9_ALAMI', 580, 1400000, 0, 1, 'None', 92, 976.638, 1239.56, -1320.72, 12.965, 2.438, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 31, 22, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(704, 817, '7OMIS_7', 468, 350000, 0, 1, 'None', 96, 756, 1668.01, -1698.98, 15.282, 164.782, 0, 0, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(705, 1043, '_DEV_MPX_', 477, 1100000, 0, 1, 'None', 20, 765.157, 347.028, -1810.16, 4.213, 359.157, 3, 1, 2, NULL, 0, 0, 18647, 1, 3, 1003, 0, 1006, 1017, 0, 1010, 1018, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(706, 506, 'BANKAI_GRV.', 560, 2000000, 0, 0, 'None', 20, 1000, 2820.84, -1074, 30.366, 86.399, 4, 4, 1, NULL, 0, 0, 18650, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1029, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(709, 492, 'ZOOL_XVILO', 561, 450000, 0, 0, 'None', 73, 755.672, 1223.15, -1327.45, 13.263, 93.653, 0, 0, 0, NULL, 0, 0, 18651, 1, 3, 1060, 0, 1061, 1063, 0, 1010, 1059, 1078, 0, 1087, 1155, 1154, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(711, 466, 'IMAD_chinwi', 477, 1100000, 0, 0, 'None', 0, 251, 1669.04, -1714, 15.312, 271.881, 7, 7, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(713, 447, 'X__GOLDIN', 540, 830000, 0, 1, 'None', 100, 300, 1864.97, -1766.01, 13.352, 356.56, 229, 229, 0, NULL, 0, 0, 18652, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(714, 652, 'Malek_', 505, 380000, 0, 0, 'None', 20, 868, 1880.1, -1766.77, 13.696, 358.821, 0, 0, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(715, 481, 'TO_BA', 560, 0, 0, 0, 'None', 100, 1000, 1626.82, -1680.11, 13.375, 77.262, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(716, 467, 'Ilyas_RPT', 541, 0, 0, 1, 'None', 10, 16876.5, 848.914, -1401.56, 12.855, 94.167, 1, 0, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(718, 765, '_SLOGANE_IZZY_4', 477, 1100000, 0, 1, 'None', 95, 963.596, 1540.24, -2177.65, 13.263, 268.945, 137, 2, 1, NULL, 0, 0, 18652, 1, 3, 1003, 0, 1006, 0, 0, 1010, 0, 1025, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(720, 724, 'Rodri_N', 477, 1100000, 0, 0, 'None', 92, 300, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(721, 524, 'monster_yt', 561, 450000, 0, 0, 'None', 15, 881.25, 1441.91, -1728.82, 13.197, 82.744, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(722, 626, 'Rayane_RBS23', 521, 310000, 0, 1, 'None', 88, 1000, 1670.7, -1701.47, 15.175, 272.097, 0, 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(723, 523, 'Zakaria_Xvilo', 477, 1100000, 0, 0, 'None', 99, 300, 1539.87, -1032.22, 23.843, 237.378, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 1001, 0, 1006, 0, 0, 1010, 1020, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(724, 106, 'ZETSU_XVILO', 535, 800000, 0, 1, 'None', 77, 965.857, 1563.88, -1605.04, 13.06, 271.278, 0, 0, 1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(725, 646, '_BRITILLE_', 560, 2000000, 0, 1, 'None', 20, 944.354, 1398.46, -2499.26, 13.218, 267.379, 12, 12, -1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1025, 0, 1087, 1169, 0, 0, 0, 100000, 0, 0, 75, 0, 0, 29, 31, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(726, 106, 'ZETSU_XVILO', 561, 450000, 0, 0, 'None', 55, 1000, 2796.52, -1567.04, 10.696, 266.956, 0, 0, 0, NULL, 0, 0, 18651, 1, 0, 1060, 0, 1055, 1062, 0, 1010, 1064, 1077, 0, 1087, 1155, 1154, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(727, 524, 'monster_yt', 505, 380000, 0, 0, 'None', 0, 955.535, 311.366, -1808.55, 4.616, 177.953, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(728, 652, 'Malek_', 535, 800000, 0, 0, 'None', 20, 885.523, 288.683, -1522.92, 24.357, 233.385, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(729, 535, 'Ilyas_Newton', 560, 2000000, 0, 1, 'None', 18, 968.883, 2780.8, -1603.79, 10.585, 180.3, 0, 0, 1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 2500, 100, 75, 0, 0, 24, 30, 25, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(730, 535, 'Ilyas_Newton', 580, 1400000, 0, 0, 'None', 20, 969.959, 1241.05, -1347.8, 12.92, 89.617, 2, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 100, 75, 50, 20, 24, 27, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(731, 535, 'Ilyas_Newton', 477, 1100000, 0, 0, 'None', 5, 830.465, 1241.19, -1344.54, 12.877, 93.897, 2, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(732, 523, 'Zakaria_Xvilo', 560, 2000000, 0, 0, 'None', 87, 676.623, 2807.86, -1064.69, 30.059, 178.671, 233, 233, -1, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(733, 441, 'R4NDEX_09', 560, 2000000, 0, 1, 'None', 8, 456.17, 1839.07, -1764.44, 13.258, 87.039, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(734, 581, 'TACH_TOCH', 560, 2000000, 0, 0, 'None', 11, 588.62, 1012.35, -1460.52, 13.205, 177.996, 2, 2, 0, NULL, 0, 0, 18648, 1, 3, 1138, 0, 0, 0, 0, 1010, 1028, 1083, 0, 1087, 1169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(735, 742, 'Ilyasse_A7', 426, 340000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(736, 1601, 'Ryad_Eltchapo', 560, 2000000, 0, 0, 'None', 88, 988, 1661.31, -2345.47, 1535.15, 268.863, 10, 1, 2, NULL, 3, 2000065, 18650, 1, 0, 1138, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(737, 555, 'LVASTO_Alvaro', 580, 1400000, 0, 1, 'None', 99, 958.607, 2041.18, -1780.57, 13.303, 89.061, 15, 1, 1, NULL, 0, 0, 18648, 1, 1, 1001, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(738, 555, 'LVASTO_Alvaro', 477, 1100000, 0, 1, 'None', 87, 906.553, 1086.51, -1338.23, 13.572, 269.225, 243, 2, -1, NULL, 0, 0, 18648, 1, 3, 1003, 0, 1006, 0, 0, 1010, 1020, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(748, 3300, 'M9YD__TANJIRO', 540, 830000, 0, 1, 'None', 100, 784.768, 1217.83, -1425.82, 13.178, 358.586, 3, 3, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(750, 741, 'jocker_sghiwr', 481, 25000, 0, 0, 'None', 100, 986.214, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(751, 445, '_rojola_', 560, 2000000, 0, 0, 'None', 0, 45113.3, 1239.09, -1311.37, 12.832, 352.512, 1, 1, 1, NULL, 0, 0, 18647, 1, 0, 1139, 0, 1032, 0, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(757, 535, 'Ilyas_Newton', 560, 2000000, 0, 0, 'RAJA', 20, 713.108, 2774.15, -1610.52, 10.628, 104.654, 0, 0, 0, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1029, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(758, 507, 'X__BA3IYA__0X', 560, 2000000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(759, 507, 'X__BA3IYA__0X', 477, 1100000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(760, 507, 'X__BA3IYA__0X', 521, 310000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(761, 507, 'X__BA3IYA__0X', 426, 340000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(762, 751, 'smoke_amine', 560, 2000000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(763, 751, 'smoke_amine', 510, 45000, 0, 0, 'None', 100, 981.652, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(764, 751, 'smoke_amine', 481, 25000, 0, 1, 'None', 100, 988.785, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(765, 639, 'JAXR_Hrz', 560, 2000000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(766, 534, 'AYM4N_WINS', 505, 380000, 0, 0, 'None', 0, 652.511, 47.358, -286.535, 1.963, 175.355, 2, 1, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 25, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(767, 975, 'supra_out', 535, 800000, 0, 0, 'None', 91, 47740.8, 1251.83, -1423.31, 13.273, 348.615, 0, 0, 2, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(768, 448, 'LHAJ_LMRYOL', 471, 235000, 0, 0, 'None', 18, 654.995, 1333.06, -1374.06, 13.178, 95.376, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(769, 777, 'Adam_Xvilo', 561, 450000, 0, 1, 'None', 90, 990, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(789, 3148, 'ALAA_VINSMOKE', 541, 900000, 0, 0, 'None', 89, 358.253, 1098.8, -1413.24, 13.215, 3.708, 0, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1098, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(790, 652, 'Malek_', 521, 120000, 0, 0, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(792, 106, 'ZETSU_XVILO', 429, 9000000, 0, 1, 'None', 0, 780, 2189.17, -1790.09, 12.987, 181.756, 6, 1, 0, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(793, 472, 'IMAD_LUCIANO', 560, 550000, 0, 0, 'None', 100, 971.529, 2786.49, -1603.13, 10.584, 176.798, 126, 126, 3, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1025, 0, 1087, 1169, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(794, 765, '_SLOGANE_IZZY_4', 560, 550000, 0, 1, 'None', 100, 1000, 1086.94, -1344.44, 13.52, 89.889, 137, 2, 2, NULL, 0, 0, 18649, 1, 3, 0, 0, 1033, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(796, 1279, '__JO9LI_UX__', 602, 650000, 5000, 1, 'None', 0, 777.238, 1574.11, -1605.57, 13.189, 180.112, 1, 3, 5, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(799, 676, 'DOCTOR_99', 541, 900000, 0, 1, 'None', 89, 897.738, 2206.22, -1172.63, 25.313, 91.314, 1, 200, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 95000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(800, 611, '$LOKER_JOKER$$8', 541, 900000, 0, 0, 'None', 100, 251, 1471.09, -1587.34, 13.048, 88.947, 3, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 62, 0, 0, 0, 28, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(802, 472, 'IMAD_LUCIANO', 522, 1000000, 0, 0, 'None', 100, 17157, 1570.03, -1608.33, 12.959, 182.801, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(803, 611, '$LOKER_JOKER$$8', 522, 1000000, 0, 0, 'None', 100, 911.088, 1474.79, -1587.85, 12.946, 262.84, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(804, 621, 'ADAM_KLLER', 541, 900000, 0, 0, 'RAJA', 76, 572, 689.686, -1176.45, 14.875, 60.605, 229, 127, 5, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 30, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(805, 781, 'rigat_rs', 421, 250000, 0, 1, 'None', 97, 903.762, 1235.59, -1370.2, 13.066, 359.071, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(806, 472, 'IMAD_LUCIANO', 560, 550000, 0, 0, 'None', 76, 1000, 2796.2, -1610.53, 10.683, 69.413, 1, 1, 3, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(807, 2631, 'Amine_tili', 521, 120000, 0, 1, 'None', 95, 300, 562.397, -1283.85, 17.0007, 0, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(808, 765, 'Nizar8', 541, 900000, 0, 1, 'None', 100, 855.004, 2038.12, -1706.76, 13.139, 358.768, 188, 0, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(809, 765, 'Nizar8', 603, 850000, 0, 1, 'None', 96, 933.646, 2480.73, -1650.48, 13.278, 89.194, 137, 0, 2, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 1019, 1079, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(810, 743, 'AMINE_FRANCO', 541, 900000, 0, 0, 'None', 98, 957.538, 1239.34, -1358.28, 12.788, 176.564, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(811, 743, 'AMINE_FRANCO', 560, 550000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(812, 743, 'AMINE_FRANCO', 603, 850000, 0, 0, 'None', 89, 1000, 2531.79, -2007.82, 13.385, 276.692, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(813, 702, 'ZODIAC_XVILO2', 554, 400000, 0, 0, 'None', 0, 832.97, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(814, 789, 'ni_ko', 462, 25000, 0, 0, 'None', 100, 930.526, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(816, 653, 'mada_xvilo', 461, 100000, 0, 1, 'None', 100, 876.616, 1244.02, -1313.06, 12.751, 96.045, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(817, 1356, 'hamza_sahrawi', 589, 270000, 0, 0, 'HY', 100, 626.808, 1359.69, -1279.35, 12.961, 148.388, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 1005, 0, 0, 1013, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(819, 475, '_FLIPO_', 522, 1000000, 0, 1, 'None', 100, 844.195, 1558.6, -1633.88, 13.086, 94.23, 79, 1, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(821, 475, '_FLIPO_', 541, 900000, 0, 0, 'None', 100, 1000, 1535.62, -1646.34, 13.113, 183.401, 6, 0, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(822, 798, 'BOSS_ZAKI', 581, 50000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(823, 407, 'oussama_r', 560, 550000, 0, 1, 'None', 100, 1000, 2586.71, -955.6, 81.029, 105.421, 2, 2, 0, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(824, 1191, 'ZIZEWAR_X', 541, 900000, 0, 1, 'None', 88, 971.854, 690.91, -1176.08, 14.941, 53.457, 6, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(825, 1285, 'WALD_FAVELAS', 522, 1000000, 0, 0, 'None', 98, 984, 2273.52, -1104.66, 37.549, 157.104, 6, 9, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1096, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(826, 522, 'Lhaj_Lmernisi', 560, 550000, 0, 0, 'None', 46, 804.797, 954.236, -1484.77, 13.113, 97.715, 86, 86, -1, NULL, 0, 0, 18651, 1, 1, 1139, 0, 1033, 0, 0, 1010, 1028, 1083, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(827, 1, 'AHMED_FF', 585, 300000, 0, 1, 'None', 14, 970, 1457.85, -1740.39, 13.132, 185.095, 1, 2, 1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1097, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(828, 676, 'DOCTOR_99', 560, 550000, 0, 1, 'None', 96, 968.975, 2206.09, -1168.81, 25.368, 89.526, 0, 0, 1, NULL, 0, 0, 18648, 1, 3, 1139, 0, 1032, 1030, 0, 1010, 1028, 1078, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(829, 676, 'DOCTOR_99', 603, 850000, 0, 1, 'None', 96, 889.78, 2206.38, -1164.84, 25.563, 88.741, 10, 0, 0, NULL, 0, 0, 18648, 1, 3, 1001, 0, 1006, 1017, 1024, 1010, 1018, 1075, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(830, 506, 'BANKAI_GRV.', 541, 900000, 0, 0, 'None', 19, 886.498, 823.737, -2015.13, 12.453, 268.75, 0, 3, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(831, 1899, '._MESSI_.', 541, 900000, 0, 0, 'None', 0, 317.474, 1991.49, -1755.8, 12.966, 90.284, 1, 7, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(832, 708, 'TITWANI_ke', 545, 350000, 0, 1, 'None', 100, 682.683, 2778.95, -1603.46, 10.733, 184.224, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(833, 805, 'gang_xvilo', 522, 1000000, 0, 0, 'None', 100, 989.095, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(834, 653, 'MADA_xvilo', 468, 100000, 0, 0, 'None', 46, 755.192, 1474.17, -1626.11, 13.716, 13.521, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(837, 708, 'TITWANI_ke', 560, 550000, 0, 0, 'None', 100, 857.857, 2780.35, -1602.98, 10.627, 175.465, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(838, 806, 'Aymen_M', 510, 10000, 0, 0, 'None', 100, 999, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(839, 804, 'Yasmine_A', 521, 120000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(841, 106, 'ZETSU_XVILO', 522, 1000000, 0, 0, 'None', 94, 899.991, 1553.31, -1607.35, 12.951, 268.411, 134, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(842, 2641, 'MOUAD_MESSI', 560, 550000, 0, 0, 'None', 100, 613.819, 854.561, -1520.25, 13.26, 266.884, 1, 1, 0, NULL, 0, 0, 18651, 1, 3, 1138, 0, 0, 1027, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(843, 1973, 'PECASO_XM8', 541, 900000, 0, 0, 'None', 100, 391.198, 1125.38, -1553.11, 13.716, 181.076, 208, 0, -1, NULL, 0, 0, 18651, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(844, 653, 'mada_xvilo', 560, 550000, 0, 1, 'None', 100, 707.553, 1468.75, -1626.77, 13.71, 325.419, 73, 73, 0, NULL, 0, 0, 18651, 1, 3, 1139, 0, 1033, 1027, 0, 1010, 1029, 1079, 0, 1087, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(845, 817, '7OMIS_7', 422, 450000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(846, 626, 'Rayane_RBS23', 541, 900000, 0, 1, 'ostora', 20, 937.1, 1979.28, -1764.09, 13.632, 273.003, 3, 3, 1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(854, 868, 'YASSIN_RESTOVA', 541, 900000, 5000, 0, 'None', 100, 251, 1628.84, -1102.87, 23.486, 268.044, 0, 0, 4, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 20, 34, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(859, 502, 'joker_x7', 541, 900000, 0, 0, 'None', 0, 967.262, 1670.88, -2347.55, 1535.1, 269.113, 6, 6, 1, NULL, 3, 2000013, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(860, 502, 'joker_x7', 560, 550000, 0, 0, 'None', 8, 1000, 557.867, -1283.98, 17.0007, 0, 1, 2, 1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(867, 37, 'Mohamed_miko', 541, 900000, 0, 1, 'None', 100, 992.797, 1219.1, -1369.44, 12.756, 266.24, 1, 7, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(868, 1688, 'TAYEB_LM3DA', 560, 550000, 0, 0, 'None', 11, 684.746, 232.351, -1205.75, 75.845, 37.654, 3, 3, -1, NULL, 0, 0, 18648, 1, 1, 1138, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(869, 555, 'LVASTO_Alvaro', 586, 50000, 0, 1, 'None', 20, 1000, 1926.47, -1575.33, 13.313, 266.519, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(870, 555, 'LVASTO_Alvaro', 468, 100000, 0, 1, 'None', 52, 906, 1926.22, -1578.5, 13.463, 269.255, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(871, 765, '_SLOGANE_IZZY_4', 439, 500000, 0, 1, 'None', 100, 848.056, 1662.17, -2345.66, 1535.33, 268.672, 3, 2, 1, NULL, 3, 2000052, 18650, 1, 0, 0, 0, 0, 0, 1013, 1010, 0, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(872, 831, 'MOUL_LBAN', 560, 550000, 0, 1, 'None', 20, 1000, 1220.62, -1342, 12.871, 86.903, 1, 1, 3, NULL, 0, 0, 18652, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(873, 765, '_SLOGANE_IZZY_4', 426, 300000, 0, 1, 'WAX', 20, 855, 2492.1, -1684.92, 13.179, 95.374, 137, 2, 0, NULL, 0, 0, 18651, 1, 3, 1003, 0, 1006, 0, 0, 1010, 1019, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(874, 407, 'oussama_r', 560, 550000, 0, 1, 'WAAAX', 100, 666.777, 2578.95, -957.145, 81.014, 101.404, 6, 1, 0, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1032, 1030, 0, 1010, 1028, 1078, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(875, 868, 'YASSIN_RESTOVA', 560, 550000, 0, 0, 'None', 100, 1000, 1629.47, -1098.66, 23.523, 267.441, 0, 0, 0, NULL, 0, 0, 18648, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 70, 0, 0, 31, 25, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(877, 765, '_SLOGANE_IZZY_4', 602, 650000, 0, 1, 'None', 20, 763.48, 827.798, -2063.89, 12.634, 0.349, 33, 2, 2, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(878, 765, '_SLOGANE_IZZY_4', 587, 700000, 0, 1, 'None', 20, 704.038, 825.118, -2063.66, 12.558, 0.052, 9, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(879, 765, '_SLOGANE_IZZY_4', 545, 350000, 0, 0, 'None', 98, 998.577, 2510.14, -1653.25, 13.54, 136.875, 128, 128, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(880, 472, 'IMAD_LUCIANO', 545, 350000, 0, 0, 'None', 19, 1000, 1043.45, -1119.22, 23.678, 86.673, 126, 126, 1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(889, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 1277.57, -2019.58, 58.592, 89.854, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(890, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 1277.27, -2023.51, 58.659, 88.758, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(892, 0, 'Nobody', 413, 0, 0, 0, 'None', 100, 1000, 1276.02, -2010.12, 59.041, 127.639, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(893, 1, 'AHMED_FF', 560, 550000, 0, 0, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(894, 534, 'AYM4N_WINS', 603, 850000, 0, 1, 'None', 10, 856.193, 986.852, -1452.85, 13.338, 1.191, 3, 3, -1, NULL, 0, 0, 18652, 0, 3, 1023, 0, 0, 0, 1024, 1010, 0, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(895, 810, 'Zyad_Xviilo', 560, 0, 0, 0, 'None', 0, 786.449, 1214.43, -746.327, 98.089, 268.173, 0, 0, -1, NULL, 0, 0, 18648, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(898, 827, 'LMBAW9_ALAMI', 555, 450000, 0, 1, 'None', 70, 679.828, 1242.87, -1325.82, 12.824, 359.095, 175, 175, -1, NULL, 0, 0, 18647, 1, 2, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 27, 25, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(900, 0, 'Nobody', 560, 550000, 0, 0, 'None', 100, 1000, 2489.84, -1643.68, 13.209, 91.922, 44, 1, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(901, 787, 'yassine__loco', 462, 25000, 0, 1, 'None', 20, 907, 1038.74, -1458.55, 13.201, 98.26, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(902, 818, 'OUSSAMA_U.h', 541, 900000, 0, 1, 'None', 92, 985.662, 1514.23, -1724.77, 13.159, 79.55, 3, 3, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(903, 829, 'Mohammed_Albaro', 603, 850000, 0, 0, 'None', 19, 460.072, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(904, 555, 'LVASTO_Alvaro', 541, 900000, 0, 1, 'None', 20, 863.51, 1085.97, -1344.35, 13.443, 271.64, 13, 1, -1, NULL, 0, 0, 18652, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(905, 1308, 'Musashi_Lucas', 602, 650000, 0, 0, 'None', 100, 986.348, 1659.32, -2356.96, 1535.25, 267.833, 179, 179, 1, NULL, 3, 2000071, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(906, 856, 'Hbira_Moran', 481, 2500, 0, 0, 'None', 100, 986.971, -991.787, -1623.06, 75.854, 270.921, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(907, 848, 'DIABLO_BONI', 481, 2500, 0, 0, 'None', 100, 984.49, -989.899, -1606.89, 75.841, 277.103, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(908, 1963, 'HAPPE__BIN', 439, 500000, 0, 1, 'None', 94, 951.544, 1810.93, -1109.71, 23.886, 271.896, 229, 229, 3, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 31, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(909, 502, 'joker_x7', 602, 650000, 0, 1, 'None', 20, 980.124, 1670.99, -2343.87, 1535.24, 275.975, 2, 2, -1, NULL, 3, 2000013, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(910, 1825, 'HICHAM_casawi', 603, 850000, 0, 0, 'None', 93, 869, 1233.65, -1377.55, 12.957, 335.707, 0, 0, -1, NULL, 0, 0, 18650, 1, 0, 1023, 0, 0, 1017, 0, 1010, 0, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(911, 502, 'joker_x7', 587, 700000, 0, 1, 'None', 20, 1000, 1671.13, -2351.62, 1535.21, 265.942, 3, 3, -1, NULL, 3, 2000013, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(912, 848, 'DIABLO_BONI', 555, 450000, 0, 1, 'None', 82, 704.42, 1116.21, -1387.44, 13.344, 97.291, 2, 2, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(914, 555, 'LVASTO_Alvaro', 526, 310000, 0, 0, 'None', 91, 660.859, 2039.32, -1775.22, 13.27, 90.01, 2, 2, 2, NULL, 0, 0, 18647, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(915, 872, '33_mostafa', 581, 50000, 0, 0, 'None', 94, 917.469, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(916, 853, 'DEV_HICHAM', 560, 550000, 3500, 0, 'None', 20, 789.882, 824.822, -1992.28, 12.572, 267.458, 6, 6, 1, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1033, 1030, 0, 1010, 1029, 1085, 0, 0, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(917, 880, 'LEO_3ABSII', 560, 550000, 0, 0, 'None', 93, 989.951, 552.818, -1284.13, 17.0007, 0, 6, 6, 2, NULL, 0, 0, 18650, 1, 0, 1138, 0, 1032, 0, 0, 1010, 0, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(918, 1179, 'ENZO_MOHAMED', 560, 550000, 0, 0, 'None', 19, 891.855, 1239.79, -1365.29, 12.872, 337.958, 182, 182, 1, NULL, 0, 0, 18648, 0, 0, 1138, 0, 1033, 0, 0, 1008, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(919, 555, 'LVASTO_Alvaro', 439, 500000, 0, 1, 'None', 100, 934.93, 2047.42, -1780.72, 13.385, 89.127, 11, 11, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(920, 831, 'MOUL_LBAN', 541, 900000, 0, 1, 'None', 95, 251, 1222.38, -1347.58, 13.079, 122.606, 0, 1, -1, NULL, 0, 0, 18648, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(921, 556, 'ninga_Xvilo', 560, 550000, 0, 1, 'None', 100, 913.351, 1491.9, -1613.99, 13.71, 91.908, 2, 2, 3, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(923, 576, 'ELPADRO_MADRIDI', 541, 900000, 0, 1, 'None', 99, 993, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(924, 1108, 'NAKATA_MAFIYA', 461, 100000, 0, 0, 'None', 100, 918.05, 2797.21, -1580.37, 10.504, 83.336, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(925, 765, 'NIZAR_XVILO', 560, 550000, 0, 1, 'None', 100, 985.597, 1086.72, -1341.32, 13.562, 89.42, 2, 2, 2, NULL, 0, 0, 18651, 1, 0, 0, 0, 1033, 1027, 0, 1010, 1028, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(927, 890, 'KINZOO_OK', 516, 300000, 0, 0, 'None', 61, 1000, 557.867, -1283.98, 17.0007, 0, 3, 3, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(928, 37, 'Mohamed_miko', 560, 550000, 0, 1, 'None', 0, 713.185, 1544.49, -1670.3, 13.263, 86.6, 0, 0, 0, NULL, 0, 0, 18651, 1, 3, 1138, 0, 0, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(929, 903, 'MOSTAFA_33', 560, 550000, 0, 1, 'None', 12, 848.487, 2496.17, -1656.01, 13.078, 268.787, 3, 3, 1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 0, 0, 0, 1028, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(930, 765, 'NIZAR_XVILO', 420, 400000, 0, 1, 'None', 13, 564.008, 1928.14, -1558.47, 13.537, 91.284, 1, 1, -1, NULL, 0, 0, 18647, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(932, 921, 'YKZ_MKAGOULI', 545, 350000, 0, 0, 'None', 15, 53541.8, 981.27, -1433.31, 13.359, 176.973, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 29, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(933, 879, 'Omar_kl', 551, 300000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(934, 1500, 'ZORO__XVILO', 560, 550000, 0, 1, 'None', 79, 844.898, 681.706, -644.004, 15.844, 332.889, 156, 156, -1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1032, 0, 0, 1010, 1028, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(935, 1899, '._MESSI_.', 560, 550000, 0, 1, 'None', 11, 997.486, 2001.79, -1757.77, 13.116, 88.607, 3, 3, 3, NULL, 0, 0, 18650, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(936, 829, 'Mohammed_Albaro', 560, 550000, 0, 0, 'None', 0, 1000, 2480.17, -1667.16, 13.04, 71.705, 4, 4, 3, NULL, 0, 0, 18652, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(937, 937, 'Killer_OK', 461, 100000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(938, 3025, 'MR___ZORO___X', 542, 300000, 0, 1, 'None', 13, 602.532, 2821.82, -1562.89, 10.765, 91.885, 1, 0, -1, NULL, 0, 0, 18651, 1, 3, 1014, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(939, 2968, 'ilyass_xx', 589, 270000, 0, 0, 'None', 100, 829.276, 1242.41, -1365.87, 12.781, 90.61, 79, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 1005, 0, 0, 0, 1010, 1020, 1081, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(940, 555, 'LVASTO_Alvaro', 603, 850000, 0, 1, 'None', 98, 764.584, 2045.5, -1775.17, 13.315, 89.411, 111, 112, 2, NULL, 0, 0, 18648, 1, 0, 1023, 0, 0, 0, 1024, 1010, 0, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(941, 555, 'LVASTO_Alvaro', 500, 450000, 0, 1, 'None', 6, 920.958, 2052.76, -1780.73, 13.593, 90.005, 60, 4, -1, NULL, 0, 0, 18652, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(942, 555, 'LVASTO_Alvaro', 549, 300000, 0, 1, 'None', 19, 634.503, 2051.33, -1775.19, 13.23, 85.791, 23, 22, 1, NULL, 0, 0, 18647, 1, 1, 1001, 1012, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(944, 765, 'V3MPX_999', 579, 310000, 0, 1, 'None', 20, 686.045, 1573.22, -1614.52, 13.267, 359.553, 56, 2, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(945, 765, 'V3MPX_999', 429, 9000000, 0, 1, 'None', 100, 44055, 1664.94, -2357.03, 1535.12, 359.503, 3, 1, -1, NULL, 3, 2000052, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(947, 588, 'Hex_404', 562, 0, 0, 1, 'None', 19, 850.616, 1217.94, -1426.1, 12.992, 359.325, 0, 1, 1, NULL, 0, 0, 18647, 1, 0, 1147, 0, 1038, 1041, 0, 1010, 0, 1083, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(948, 555, 'LVASTO_Alvaro', 429, 9000000, 0, 0, 'None', 95, 1000, 1086.12, -1341.23, 13.537, 270.711, 4, 3, 1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(949, 903, 'MOSTAFA_33', 602, 650000, 0, 1, 'None', 78, 577.918, 552.818, -1284.13, 17.0007, 0, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(950, 555, 'LVASTO_Alvaro', 579, 310000, 0, 1, 'None', 17, 740.094, 2027.58, -1780.47, 13.403, 90.344, 113, 2, 1, NULL, 0, 0, 18648, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(951, 633, 'Za3ima_Aya', 541, 900000, 0, 0, 'None', 90, 858, 1242.58, -1357.68, 12.784, 92.026, 126, 1, -1, NULL, 0, 0, 18652, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(952, 588, 'Hex_404', 562, 0, 0, 1, 'None', 92, 837.826, 1221.34, -1426.24, 12.986, 1.22, 1, 1, 2, NULL, 0, 0, 18647, 1, 0, 1147, 0, 1035, 0, 0, 1010, 0, 1083, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(953, 2690, 'PEDRO_VGS', 602, 650000, 0, 1, 'None', 85, 956.578, 2822.14, -1566.84, 10.728, 89.015, 6, 6, -1, NULL, 0, 0, 18649, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(954, 978, 'SPINOZA_OFFICE', 426, 300000, 0, 1, 'None', 80, 949.635, 1555.24, -1606.43, 13.126, 84.346, 6, 6, 2, NULL, 0, 0, 18652, 1, 0, 1003, 0, 1006, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(955, 848, 'DIABLO_BONI', 426, 300000, 0, 1, 'None', 80, 1000, 1172.97, -1413.64, 13.165, 269.853, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 1001, 1005, 1006, 0, 0, 1010, 1019, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(956, 965, 'D.G.S.T_achraf', 586, 50000, 0, 1, 'None', 100, 251, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(957, 891, 'pain_077', 555, 450000, 0, 0, 'None', 20, 891.538, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(960, 765, 'NIZAR_XVILO', 549, 300000, 0, 1, 'None', 20, 916.756, 2465.58, -1667.8, 13.156, 7.037, 137, 8, -1, NULL, 0, 0, 18648, 1, 3, 1003, 0, 0, 1017, 0, 1010, 1020, 1079, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(961, 890, 'KINZOO_OK', 522, 1000000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(962, 1060, '3bas_', 500, 450000, 0, 0, 'None', 11, 829.577, 2027.31, -1778.13, 13.649, 88.398, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(963, 988, 'RAYAN_A', 586, 50000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(964, 954, 'amine_12', 581, 50000, 0, 0, 'None', 100, 251, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(965, 965, 'D.G.S.T_achraf', 576, 330000, 0, 1, 'None', 20, 857.82, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(966, 990, 'JOMBO_JR', 560, 550000, 500, 1, 'None', 0, 798.252, 2771.4, -1623.18, 10.578, 271.747, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 1138, 0, 1032, 1027, 0, 1008, 1029, 1083, 0, 1087, 1169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(967, 986, 'Adam_EI', 500, 450000, 0, 1, 'None', 20, 783.871, 552.818, -1284.13, 17.0007, 0, 1, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(968, 909, 'Anas_Bringa', 461, 100000, 0, 0, 'None', 100, 868.819, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(969, 965, 'D.G.S.T_achraf', 541, 900000, 0, 1, 'None', 20, 568.291, 557.867, -1283.98, 17.0007, 0, 0, 1, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(970, 890, 'KINZOO_OK', 545, 350000, 0, 1, 'None', 20, 978.975, 336.882, -1808.85, 4.326, 357.663, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(971, 912, 'DV_rayan', 418, 450000, 0, 0, 'None', 93, 998, 340.657, -1809.47, 4.605, 358.915, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(972, 853, 'DEV_HICHAM', 445, 300000, 0, 0, 'None', 94, 964.591, 356.821, -1809.46, 4.373, 359.453, 2, 2, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(973, 853, 'DEV_HICHAM', 541, 900000, 0, 1, 'None', 20, 791.436, 347.304, -1809.38, 4.153, 359.573, 1, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(974, 912, 'DV_rayan', 439, 500000, 0, 1, 'None', 100, 1000, 324.099, -1809.61, 4.372, 0.037, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(975, 1013, 'VODKA_OK', 560, 550000, 0, 1, 'None', 20, 251, 1811.96, -1123.99, 23.783, 267.278, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 1138, 0, 1032, 0, 0, 0, 0, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(976, 596, 'WHY_ME7X', 510, 10000, 0, 1, 'None', 20, 912.448, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(977, 943, 'NKATA_MAFAIYA', 413, 500000, 0, 0, 'None', 100, 652.968, 1531.31, -1731.95, 13.468, 91.588, 0, 0, 0, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(978, 943, 'NKATA_MAFAIYA', 510, 10000, 0, 1, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(979, 445, '_rojola_', 422, 450000, 0, 0, 'None', 20, 996.979, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(980, 445, '_rojola_', 585, 300000, 0, 0, 'None', 19, 902.673, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(981, 1004, 'Vegas_Hernandez', 471, 70000, 0, 1, 'None', 19, 746.2, 1220.08, -1362.59, 12.65, 73.636, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(982, 666, 'XMAN_L3ALAWI', 602, 650000, 0, 0, 'None', 90, 310, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(983, 921, 'YKZ_MKAGOULI', 521, 120000, 0, 1, 'None', 100, 875.353, 980.312, -1437.9, 13.11, 87.965, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(984, 913, 'Marwane_Tohamieu', 521, 120000, 0, 0, 'None', 8, 844.563, 1587.76, -1616.71, 12.948, 313.992, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(985, 736, '__HITMAN__', 560, 550000, 0, 0, 'None', 18, 840.614, 961.975, -900.642, 45.472, 179.07, 6, 6, 0, NULL, 0, 0, 18647, 1, 3, 1139, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(988, 3447, 'Fang_Fighter', 468, 100000, 0, 1, 'None', 66, 864.043, 1224.46, -1414.64, 13.004, 0.039, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(989, 986, 'Adam_EI', 526, 310000, 0, 0, 'None', 20, 803.403, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(990, 1211, 'SRAH_N3AM', 500, 450000, 0, 0, 'None', 0, 1000, 756.292, -1277.71, 13.658, 0.809, 68, 32, -1, NULL, 0, 0, 18648, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(991, 736, '__HITMAN__', 541, 900000, 0, 1, 'None', 95, 984.814, 2515.41, -1669.25, 13.365, 79.142, 1, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(992, 1003, 'TAX_MAN', 600, 270000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(993, 1025, 'RE__SPECT', 560, 550000, 0, 0, 'None', 100, 644.343, 235.529, -1203.06, 75.846, 218.356, 6, 6, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(994, 1279, '__JO9LI_UX__', 418, 450000, 0, 1, 'None', 100, 808.381, 1912.51, -1635.45, 13.473, 271.071, 200, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1009, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(995, 498, 'mo_rad', 481, 2500, 0, 0, 'None', 100, 860, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(997, 906, 'SIMO_OK', 560, 550000, 0, 0, 'None', 20, 831.883, 557.87, -1283.98, 16.974, 0.071, 8, 5, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(998, 555, 'LVASTO_Alvaro', 560, 550000, 0, 1, 'None', 19, 790.079, 1086.19, -1347.17, 13.504, 275.644, 137, 2, 3, NULL, 0, 0, 18649, 1, 1, 1138, 0, 1032, 0, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(999, 1013, 'VODKA_OK', 560, 550000, 0, 0, 'None', 14, 1000, 557.867, -1283.98, 17.0007, 0, 1, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1000, 1043, '_DEV_MPX_', 424, 550000, 0, 0, 'None', 20, 693.799, 311.753, -1789.96, 4.351, 183.421, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1001, 635, 'AZGHAR__LHAJ', 603, 850000, 0, 0, 'None', 20, 251, 1241.58, -1340.84, 12.977, 88.948, 8, 8, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1019, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1002, 736, '__HITMAN__', 522, 1000000, 0, 0, 'None', 10, 858.669, 1810.19, -1139.5, 23.65, 317.054, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1003, 1037, 'yassine_sahrawi', 468, 100000, 0, 0, 'None', 17, 777.13, 2274.25, -1108.15, 37.645, 329.993, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1004, 1031, 'ilyasss_jaz', 462, 25000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1005, 1838, 'Figou_Deep', 580, 300000, 0, 0, 'None', 20, 925.297, 1242.29, -1344.64, 13.468, 269.829, 226, 1, -1, NULL, 0, 0, 18652, 1, 3, 1023, 0, 1006, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1006, 1031, 'ilyasss_jaz', 581, 50000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1008, 700, 'BLACK_VIP', 522, 1000000, 0, 1, 'None', 100, 1000, 1830.15, -1109.63, 23.407, 96.768, 125, 125, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1009, 702, 'ZODIAC_XVILO2', 587, 700000, 0, 1, 'None', 20, 916.565, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1010, 1026, '@_TNT_@', 560, 550000, 0, 0, 'None', 6, 600.558, 1821.44, -1124.75, 23.783, 182.356, 8, 8, -1, NULL, 0, 0, 0, 0, 0, 1139, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1011, 472, 'IMAD_LUCIANO', 424, 550000, 0, 1, 'None', 65, 979.079, 1247.04, -1430.78, 13.32, 27.147, 198, 1, -1, NULL, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1012, 401, 'SPY_DER', 560, 550000, 0, 0, 'None', 20, 832.392, 1242.77, -1371.09, 12.841, 89.578, 3, 3, 0, NULL, 0, 0, 18647, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1079, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1013, 1568, 'FRANK_So', 541, 900000, 0, 0, 'None', 16, 739.004, 1219.98, -1364.12, 12.853, 88.637, 3, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1014, 1043, '_DEV_MPX_', 560, 550000, 0, 1, 'None', 100, 658.978, 471.558, -1649.95, 24.54, 261.758, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1016, 653, 'mada_xvilo', 603, 850000, 0, 0, 'None', 98, 588.904, 1490.61, -1624.83, 13.885, 44.092, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 1023, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1018, 911, 'RII_M', 481, 2500, 0, 0, 'None', 20, 988.985, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1019, 1471, 'IRT_WLD_ALI', 576, 330000, 178, 1, 'None', 96, 733.193, 1322.84, -622.02, 108.689, 197.052, 6, 1, 2, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 1135, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1020, 1055, 'Adam_17', 496, 250000, 0, 0, 'None', 18, 251, 557.867, -1283.98, 17.0007, 0, 1, 1, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1022, 913, 'Marwane_Tohamieu', 492, 270000, 0, 0, 'None', 11, 972.594, 1570.21, -1626.54, 13.165, 270.854, 8, 8, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1023, 769, 'ycz_imad', 521, 120000, 0, 0, 'None', 98, 965.338, 2016.74, -1766.64, 13.619, 92.182, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1025, 2780, 'MAMADO_x', 587, 700000, 0, 1, 'WAX', 99, 864.523, 967.928, -1360.78, 13.034, 178.181, 3, 3, 2, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1009, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1026, 1062, 'Zakaria_TiiLoX', 461, 100000, 0, 1, 'None', 90, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1028, 1962, 'fouade_2023', 560, 550000, 0, 0, 'None', 100, 614.932, 1235.49, -1370.21, 12.834, 260.099, 6, 1, 0, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 0, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1030, 992, 'Lhaj_Omar', 596, 0, 0, 0, 'None', 100, 1000, 1537.19, -1674.34, 13.547, 60.725, 1, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1031, 1046, 'YASSIN_.SR', 418, 450000, 0, 0, 'None', 20, 682.322, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1032, 1046, 'YASSIN_.SR', 603, 850000, 0, 0, 'None', 20, 758.644, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1033, 1034, 'Daniel_Lorinzo', 586, 50000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1034, 1061, 'OSLO_MARLY', 560, 550000, 0, 1, 'OSLO-2409', 18, 1000, 2030.84, -1776.21, 13.21, 88.576, 2, 2, 0, NULL, 0, 0, 18648, 1, 3, 1139, 0, 1033, 1027, 0, 1010, 1029, 1081, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 25, 0, 0, 0, 34, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1036, 862, 'ZOU_HIR', 522, 1000000, 0, 1, 'None', 100, 631.978, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1037, 856, 'Hbira_Moran', 426, 300000, 0, 0, 'None', 88, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1038, 1179, 'ENZO_MOHAMED', 510, 10000, 0, 0, 'None', 20, 974.316, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1041, 1037, 'yassine_sahrawi', 602, 650000, 0, 0, 'None', 18, 1000, 2260.45, -1104.33, 37.983, 247.556, 6, 6, 1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1042, 1601, 'Ryad_Eltchapo', 461, 100000, 0, 0, 'None', 20, 1000, 1664.98, -2360.53, 1535.07, 93.687, 0, 0, -1, NULL, 3, 2000065, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1043, 1045, 'achraf_miko', 492, 270000, 0, 0, 'None', 0, 999.91, 2772.67, -1603.36, 10.703, 91.287, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1044, 765, 'NIZAR_XVILO', 522, 1000000, 0, 1, 'None', 100, 822.41, 1658.85, -2353.88, 1535.05, 270.951, 3, 3, -1, NULL, 3, 2000052, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1047, 1083, 'MAYK_VRS', 481, 2500, 0, 0, 'None', 100, 1000, 620.164, -1348.21, 13.048, 163.496, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1049, 1074, 'PABLO_WOLF', 468, 100000, 0, 1, 'None', 66, 746.71, 1943.65, -1815.75, 13.216, 272.094, 2, 2, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1050, 106, 'ZETSU_XVILO', 415, 0, 0, 0, 'None', 92, 1000, 2516.68, -1671.4, 13.687, 73.918, 137, 2, -1, NULL, 0, 0, 18649, 1, 3, 1003, 0, 0, 1017, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1052, 653, 'mada_xvilo', 522, 1000000, 0, 1, 'None', 100, 717.022, 1478.23, -1624.41, 13.619, 2.621, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1054, 1108, 'NAKATA_MAFIYA', 555, 450000, 0, 0, 'None', 95, 974.788, 1993.48, -1778.81, 13.898, 189.235, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1055, 765, 'NIZAR_XVILO', 560, 550000, 0, 0, 'None', 100, 968.7, 1670.35, -2354.37, 1535.19, 268.005, 3, 3, 0, NULL, 3, 2000052, 18647, 1, 0, 1138, 0, 1033, 0, 0, 1010, 1029, 1077, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1056, 2085, 'motez_sellami2', 560, 550000, 0, 0, 'None', 99, 3220.09, 1617.41, -1123.53, 23.559, 90.747, 4, 4, 0, NULL, 0, 0, 18649, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1029, 1083, 0, 1087, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1058, 906, 'SIMO_OK', 492, 270000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1060, 1128, 'AYA__0X', 560, 550000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1061, 1125, 'UTCHIHA_ITACHI', 500, 450000, 0, 0, 'None', 0, 746.877, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1062, 1471, 'IRT_WLD_ALI', 545, 0, 0, 1, 'None', 98, 1000, 1314.08, -625.906, 108.95, 197.291, 137, 2, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1063, 990, 'JOMBO_JR', 510, 10000, 0, 0, 'None', 20, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1064, 1125, 'UTCHIHA_ITACHI', 482, 450000, 0, 1, 'None', 98, 896, 1241.13, -1345.28, 13.274, 3.381, 6, 6, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1065, 906, 'SIMO_OK', 560, 550000, 0, 1, 'None', 9, 759.208, 1989.72, -1757.09, 13.169, 95.881, 50, 50, -1, NULL, 0, 0, 18647, 1, 0, 1138, 0, 1033, 0, 0, 1010, 1028, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1066, 1112, 'FOR__WINSTON', 560, 550000, 0, 1, 'None', 100, 251, 1331.68, -1512, 13.228, 240.672, 15, 15, -1, NULL, 0, 0, 0, 0, 0, 1139, 0, 1033, 1030, 0, 1010, 1029, 1074, 0, 0, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1069, 856, 'Hbira_Moran', 579, 310000, 0, 1, 'None', 96, 786.455, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1070, 472, 'IMAD_LUCIANO', 526, 310000, 0, 0, 'None', 19, 652, 2794.55, -1614.98, 10.711, 71.332, 126, 126, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1071, 1108, 'NAKATA_MAFIYA', 560, 550000, 0, 0, 'None', 19, 925, 981.825, -1445.75, 13.239, 183.766, 2, 4, 1, NULL, 0, 0, 18651, 1, 0, 1139, 0, 0, 1030, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1072, 401, 'SPY_DER', 541, 900000, 0, 1, 'None', 20, 912.297, 1219.06, -1422.17, 12.874, 356.911, 3, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 42, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1073, 1192, 'I_NAMOSE', 439, 500000, 0, 1, 'None', 100, 810.791, 1920.88, -1626.28, 13.442, 180.411, 241, 2, 1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1074, 2780, 'MAMADO_x', 541, 900000, 0, 1, 'None', 100, 1000, 962.946, -1366.12, 12.969, 179.753, 228, 0, 5, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1075, 1289, 'AYA_MARYOLA', 560, 550000, 0, 1, 'None', 20, 872.573, 2448.77, -1664.03, 13.045, 294.934, 0, 0, 1, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1033, 1030, 0, 1010, 1029, 1081, 0, 1087, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1076, 633, 'Za3ima_Aya', 560, 550000, 0, 1, 'None', 100, 701.42, 1242.76, -1361.34, 12.84, 91.226, 126, 2, 0, NULL, 0, 0, 18651, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 0, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1077, 1013, 'VODKA_OK', 541, 900000, 0, 1, 'None', 20, 251, 562.397, -1283.85, 17.0007, 0, 1, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1078, 990, 'JOMBO_JR', 541, 900000, 0, 1, 'None', 13, 808.62, 351.062, -1511.44, 32.609, 143.26, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1079, 1211, 'SRAH_N3AM', 560, 550000, 0, 0, 'None', 14, 871.629, 760.879, -1275.89, 13.223, 2.247, 126, 3, 0, NULL, 0, 0, 18651, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 0, 1081, 0, 1087, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1080, 1132, 'Mikey_mexico', 560, 550000, 0, 0, 'None', 18, 1000, 2205.87, -1165.49, 25.395, 88.764, 0, 0, 0, NULL, 0, 0, 18652, 1, 0, 1138, 0, 1032, 1030, 0, 1010, 0, 1083, 0, 1087, 0, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1081, 1062, 'Zakaria_TiiLoX', 560, 550000, 0, 0, 'None', 12, 468.76, 2490.88, -1657.93, 13.141, 177.845, 2, 1, 1, NULL, 0, 0, 18648, 1, 3, 1139, 0, 1032, 0, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1082, 840, 'FIP_DHX', 560, 550000, 0, 0, 'None', 0, 793.823, 1949.91, -1753.3, 13.088, 82.562, 0, 0, 1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1085, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1084, 1168, 'Simo_Hercolanos', 471, 70000, 0, 0, 'None', 19, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1085, 1062, 'Zakaria_TiiLoX', 560, 550000, 0, 0, 'None', 19, 931.091, 2012.1, -1777.13, 14.32, 180.195, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1086, 1519, 'Boonina_Millions', 593, 10000000, 0, 1, 'None', 100, 491.661, 1979.87, -2184.44, 14.004, 180.619, 241, 2, 2, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1087, 1176, 'brazeli_mezox', 560, 550000, 0, 0, 'None', 19, 552.705, 1670.7, 1423.53, 10.426, 270.136, 3, 3, 3, NULL, 0, 0, 18650, 1, 0, 1138, 0, 1032, 1030, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1088, 1577, 'SANJI_XVILO', 541, 900000, 0, 1, 'None', 99, 988.371, 1650.19, -1102.37, 23.5, 89.892, 127, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1089, 1211, 'SRAH_N3AM', 487, 15550000, 0, 1, 'None', 13, 872.046, 1929.02, -1717.14, 13.755, 181.261, 241, 2, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1090, 1670, 'X7__BRAZIL__X', 462, 25000, 0, 1, 'None', 0, 956, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1091, 1211, 'SRAH_N3AM', 560, 550000, 0, 1, 'None', 19, 944.22, 764.509, -1276.82, 13.267, 353.839, 194, 2, -1, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1075, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1092, 1150, 'DBAN_RS', 560, 550000, 0, 0, 'None', 20, 968, 693.852, -1170.15, 15.065, 147.715, 0, 0, 0, NULL, 0, 0, 18651, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1029, 1081, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1093, 1185, 'MOLDWA._mexico', 560, 550000, 0, 0, 'None', 20, 655.961, 552.818, -1284.13, 17.0007, 0, 0, 1, 0, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1094, 1153, 'PEDRO_Xv', 560, 550000, 0, 0, 'None', 20, 659.046, 1993.82, -1772.37, 13.812, 179.696, 0, 0, 1, NULL, 0, 0, 18650, 1, 0, 1138, 0, 0, 0, 0, 1010, 0, 1074, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1095, 793, 'Khalil_Escobar', 536, 350000, 0, 1, 'None', 100, 660.229, 1965.89, -2204.01, 13.108, 25.235, 0, 0, 2, NULL, 0, 0, 0, 0, 3, 0, 0, 1128, 1107, 0, 1010, 0, 1083, 0, 1087, 1182, 1184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1096, 1192, 'I_NAMOSE', 493, 20750000, 0, 0, 'None', 20, 914.307, 939.376, -1907.77, -0.561, 8.743, 212, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1098, 1211, 'SRAH_N3AM', 461, 100000, 0, 0, 'None', 43, 919, 1927.69, -1724.25, 13.134, 191.946, 1, 1, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1104, 1589, 'TiTaN_Hermano', 560, 550000, 0, 1, 'None', 20, 689.343, 247.184, -1227.56, 74.821, 218.263, 126, 1, 2, NULL, 0, 0, 18651, 0, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1105, 421, 'PABLO_MORO', 429, 0, 5000, 0, 'None', 83, 666.83, 1228.97, -1380.18, 13.17, 178.572, 0, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1108, 765, 'NIZAR_XVILO', 541, 900000, 0, 1, 'None', 97, 987.459, 2506.02, -1650.84, 13.312, 133.613, 137, 0, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1109, 2641, 'MOUAD_MESSI', 420, 400000, 0, 0, 'None', 100, 742.375, 1212.38, -1425.24, 13.162, 0.504, 7, 8, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1110, 1199, 'you_SY', 424, 550000, 0, 0, 'None', 76, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1113, 950, 'CHINWI_07', 587, 700000, 0, 1, 'None', 100, 251, 1188.4, -1331.36, 13.288, 359.097, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1114, 950, 'CHINWI_07', 522, 1000000, 0, 0, 'None', 88, 9086.98, 334.688, -1519.33, 35.432, 154.633, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1008, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1115, 0, 'Nobody', 522, 0, 0, 0, 'None', 100, 1000, 286.651, -1521.9, 24.177, 231.255, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1118, 1211, 'SRAH_N3AM', 560, 550000, 0, 1, 'None', 14, 972.494, 773.016, -1276.9, 13.269, 1.446, 126, 2, -1, NULL, 0, 0, 18651, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 0, 1078, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1119, 1534, 'vergas__', 560, 550000, 0, 0, 'None', 13, 1000, 1912.2, -1635.93, 13.077, 270.988, 197, 2, -1, NULL, 0, 0, 18650, 1, 2, 1138, 0, 1032, 1030, 0, 1010, 0, 1077, 0, 0, 1169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1120, 1714, 'lhaj_minato', 560, 550000, 0, 0, 'None', 10, 870.862, 2490.17, -1633.39, 13.154, 352.473, 226, 2, 2, NULL, 0, 0, 18652, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1121, 1279, '__JO9LI_UX__', 560, 550000, 0, 0, 'None', 100, 703.221, 1912.15, -1652.24, 13.076, 267.411, 93, 1, -1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 0, 1078, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1122, 1730, 'LF9IH__ADAM', 560, 550000, 0, 1, 'None', 87, 702.64, 1317.53, -2052.59, 57.61, 2.603, 6, 1, -1, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1123, 1211, 'SRAH_N3AM', 560, 550000, 0, 1, 'None', 19, 991.712, 769.144, -1277.09, 13.269, 2.63, 229, 0, -1, NULL, 0, 0, 18650, 1, 1, 1138, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1124, 1198, 'Hamza_Hercolano', 560, 550000, 0, 1, 'None', 15, 863.035, 1912.24, -1640.76, 13.083, 270.868, 1, 1, 1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1125, 894, 'TALIANI_WOLF', 560, 550000, 0, 0, 'None', 90, 6201, 690.551, -1170.06, 14.948, 100.783, 229, 1, -1, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1126, 1211, 'SRAH_N3AM', 560, 550000, 0, 1, 'None', 9, 841.987, 1913.94, -1730.07, 13.117, 270.301, 2, 135, -1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1033, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1127, 1589, 'TiTaN_Hermano', 560, 550000, 0, 1, 'TITAN', 17, 753.49, 830.505, -853.847, 69.624, 200.219, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1032, 0, 0, 0, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1128, 1534, 'vergas__', 560, 550000, 0, 1, 'None', 19, 687.336, 1912.21, -1638.68, 13.077, 270.471, 0, 0, 2, NULL, 0, 0, 18651, 1, 1, 1139, 0, 1032, 0, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1129, 1211, 'SRAH_N3AM', 560, 550000, 0, 1, 'None', 18, 1000, 1913.81, -1723.18, 13.118, 272.251, 211, 1, -1, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1130, 1434, 'LHOPRO_RN', 560, 550000, 0, 1, 'None', 92, 251, 2796, -1585.08, 10.636, 271.041, 222, 2, -1, NULL, 0, 0, 18647, 1, 1, 1138, 0, 1032, 0, 0, 1010, 0, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1131, 1471, 'IRT_WLD_ALI', 560, 550000, 0, 0, 'None', 61, 461.203, 513.787, -1253.78, 16.248, 323.245, 233, 233, 3, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 0, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1132, 3129, 'WLD_LHAJ_2', 560, 550000, 0, 0, 'None', 100, 1000, 1098.11, -1375.78, 13.562, 177.662, 8, 8, 0, NULL, 0, 0, 18648, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1133, 1534, 'vergas__', 560, 550000, 0, 1, 'None', 19, 626.142, 1912.2, -1648.41, 13.077, 261.681, 6, 1, 1, NULL, 0, 0, 18652, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1134, 2998, 'HETLER_LM3DAWI', 560, 550000, 0, 0, 'None', 10, 963, 384.288, -2075.19, 7.507, 187.661, 3, 3, 2, NULL, 0, 0, 18647, 0, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1135, 1192, 'I_NAMOSE', 560, 550000, 0, 0, 'None', 95, 1000, 378.591, -2033.87, 7.492, 265.916, 241, 2, -1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1136, 1211, 'SRAH_N3AM', 560, 550000, 0, 0, 'None', 15, 790.081, 1913.4, -1720.94, 13.108, 273.607, 0, 0, 2, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1078, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1137, 1279, '__JO9LI_UX__', 560, 550000, 0, 1, 'None', 20, 998.77, 1912.14, -1657.16, 13.044, 269.667, 126, 1, -1, NULL, 0, 0, 18651, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1138, 1218, 'Taha_JORDAN', 462, 25000, 0, 1, 'None', 100, 992, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1139, 1601, 'Ryad_Eltchapo', 560, 550000, 0, 1, 'None', 100, 651.136, 1659.92, -2339.97, 1536.52, 269.715, 240, 2, -1, NULL, 3, 2000065, 18652, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1078, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1140, 3508, 'Vortex_X', 560, 550000, 0, 0, 'car 3', 0, 1000, 1276.81, -1304.85, 12.996, 180.356, 3, 2, 4, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 0, 0, 1010, 0, 1081, 0, 1087, 1169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1141, 653, 'mada_xvilo', 556, 0, 0, 1, 'None', 100, 980.265, 1242.67, -1334.22, 13.544, 91.103, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1142, 2271, 'SENIORA_FULA', 541, 900000, 0, 1, 'None', 100, 650.459, 1051.46, -1399.31, 13.031, 7.007, 128, 0, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1143, 1022, 'LKAFE_OK', 560, 550000, 0, 1, 'None', 19, 300, 552.818, -1284.13, 17.0007, 0, 0, 1, -1, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1033, 1030, 0, 1008, 0, 1077, 0, 0, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1146, 1570, '_RONALDO_', 420, 400000, 0, 0, 'None', 100, 989.513, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1147, 1145, 'DraXx_Castellanoo', 560, 550000, 0, 1, 'None', 19, 684.081, 1904.52, -1783.15, 13.252, 179.956, 0, 0, 0, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1148, 1124, 'FOR_SERRINI', 541, 900000, 0, 0, 'None', 94, 616, 2002.88, -1765.34, 13.659, 181.462, 3, 6, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1149, 1124, 'FOR_SERRINI', 560, 550000, 0, 1, 'None', 17, 984.861, 2016.6, -1765.95, 13.715, 179.007, 0, 0, 1, NULL, 0, 0, 18648, 1, 0, 1139, 0, 1032, 1030, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1150, 1145, 'DraXx_Castellanoo', 521, 120000, 0, 0, 'None', 7, 929.573, 423.112, -1262.94, 51.13, 201.096, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1151, 903, 'MOSTAFA_33', 541, 900000, 0, 1, 'None', 12, 310.159, 2501.34, -1658.06, 12.975, 225.742, 6, 0, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1152, 535, 'Ilyas_Newton', 416, 0, 0, 0, 'None', 20, 1000, 2467.96, -1673.92, 13.493, 150.717, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1153, 1153, 'PEDRO_Xv', 560, 550000, 0, 1, 'None', 18, 1000, 1993.96, -1777.46, 14.15, 180.435, 0, 0, 2, NULL, 0, 0, 18652, 1, 0, 1138, 0, 1032, 1030, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1155, 1, 'AHMED_FF', 493, 20750000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1156, 1132, 'Mikey_mexico', 560, 550000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, 1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1157, 765, 'NIZAR_XVILO', 521, 120000, 0, 0, 'None', 99, 965.92, 1086.55, -1349.29, 13.424, 94.367, 33, 2, -1, NULL, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1158, 1175, 'NAKATA__MIXICO', 424, 550000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1159, 765, 'NIZAR_XVILO', 522, 1000000, 0, 1, 'None', 100, 756, 1086.75, -1350.7, 13.422, 89.397, 4, 4, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1160, 1616, 'MOHAMED_LEX', 541, 900000, 0, 0, 'None', 17, 887.398, 764.667, -1240.27, 13.145, 181.627, 1, 1, 2, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1161, 1192, 'I_NAMOSE', 603, 850000, 0, 0, 'None', 100, 793.62, 1923.43, -1626.56, 13.385, 178.432, 3, 6, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1162, 1714, 'lhaj_minato', 560, 550000, 0, 1, 'None', 12, 765.701, 2481.58, -1713.1, 13.242, 173.969, 2, 3, 2, NULL, 0, 0, 18651, 1, 0, 1139, 0, 0, 0, 0, 1010, 0, 1025, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1165, 2775, 'aya_nn', 587, 700000, 0, 1, 'None', 18, 1000, 296.154, -1540.62, 24.285, 55.978, 0, 0, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1166, 2085, 'motez_sellami2', 602, 650000, 0, 1, 'None', 85, 544.333, 1262.44, -2010.81, 59.118, 178.489, 0, 0, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1008, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1167, 1453, 'davos_cb4', 560, 550000, 0, 1, 'None', 20, 1000, 1228.19, -1423.09, 13.112, 356.963, 0, 0, 1, NULL, 0, 0, 18648, 1, 0, 1139, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1169, 793, 'Khalil_Escobar', 579, 310000, 0, 1, 'None', 8, 1000, 2451.39, -2023.43, 13.523, 358.346, 1, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1096, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1170, 535, 'Ilyas_Newton', 541, 0, 0, 0, 'None', 20, 1000, 1242.37, -1361.52, 12.784, 88.282, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1171, 765, 'NIZAR_XVILO', 562, 0, 0, 1, 'None', 96, 16466, 1551.76, -2177.75, 13.205, 270.823, 137, 2, 3, NULL, 0, 0, 18649, 1, 3, 1147, 0, 1035, 1040, 0, 1010, 1034, 1077, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1172, 1973, 'PECASO_XM8', 560, 550000, 0, 1, 'None', 100, 1000, 2104.94, -1779.4, 13.094, 176.439, 3, 3, 2, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 29, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1174, 481, 'TO_BA', 602, 650000, 0, 1, 'None', 95, 784.169, 1595.74, -1631.38, 13.292, 5.576, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1176, 481, 'TO_BA', 429, 9000000, 0, 0, 'None', 19, 894.061, 1592.28, -1631.25, 13.105, 2.194, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1177, 1218, 'Taha_JORDAN', 481, 2500, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1178, 770, 'LEOO_', 560, 550000, 0, 1, 'None', 80, 721.015, 2227.39, -1152.47, 25.535, 268.902, 0, 0, 0, NULL, 0, 0, 18651, 1, 0, 1139, 0, 0, 0, 0, 1010, 0, 1084, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1179, 1290, 'XXX_TENTATION', 462, 25000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1180, 1179, 'ENZO_MOHAMED', 509, 2500, 0, 0, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1181, 1564, '__MESSI__', 468, 100000, 0, 0, 'None', 20, 748.54, -1007.46, -2154.22, 34.572, 76.036, 76, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1182, 279, 'Senior_Eltchapo', 541, 900000, 0, 0, 'None', 20, 251, 1223.97, -1424.84, 12.953, 174.56, 0, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1183, 1279, '__JO9LI_UX__', 412, 250000, 0, 0, 'OSLO', 27, 47232.3, 954.8, -934.331, 42.534, 1.261, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 32, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1188, 1294, 'SD_REX', 481, 2500, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1189, 556, 'ninga_Xvilo', 541, 900000, 0, 1, 'None', 100, 12090.5, 1467.77, -1614.11, 13.633, 273.118, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1190, 877, 'L7AJ_ZIAD', 541, 900000, 0, 1, 'None', 100, 48200, 1060.17, -639.439, 119.71, 101.017, 3, 1, 2, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1191, 765, 'NIZAR_XVILO', 451, 0, 0, 1, 'None', 100, 885.146, 1558.9, -2180.27, 13.213, 0.02, 137, 2, 2, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1192, 597, 'MOULL_SLAWI', 587, 700000, 0, 0, 'None', 0, 616.088, 1929.16, -1577.11, 13.519, 270.738, 155, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1193, 765, 'NIZAR_XVILO', 422, 0, 0, 1, 'None', 20, 978.683, 2485.68, -1685.25, 13.446, 92.203, 137, 1, 2, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1194, 765, 'NIZAR_XVILO', 565, 0, 0, 1, 'None', 100, 721.382, 1546.28, -2177.7, 13.136, 268.768, 137, 2, 2, NULL, 0, 0, 18647, 1, 3, 1049, 0, 1053, 1051, 0, 1010, 1046, 1077, 0, 1087, 1153, 1150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1196, 950, 'CHINWI_07', 560, 550000, 0, 1, 'None', 100, 759.796, 635.246, -574.37, 16.041, 183.91, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 31, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1197, 1304, 'Big_Smoke', 471, 70000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1198, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2504.05, -2005.85, 12.942, 91.189, 3, -1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 90000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1199, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2511.1, -2005.6, 13.111, 90.758, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 90000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1200, 0, 'Nobody', 482, 0, 0, 0, 'None', 100, 1000, 2530.46, -2009.59, 13.67, 90.591, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 90000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1201, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2495.24, -1993.48, 13.552, 179.888, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 90000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1202, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2497.51, -2025.69, 13.591, 358.025, 3, -1, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 900, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1203, 1236, 'MORO_FA', 603, 850000, 0, 0, 'None', 20, 300.608, 1237.4, -1372.71, 13.007, 353.752, 3, 1, -1, NULL, 0, 0, 18647, 1, 3, 1023, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1204, 1236, 'MORO_FA', 541, 900000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1206, 770, 'LEOO_', 541, 900000, 0, 0, 'None', 58, 623.298, 1222.22, -1172.28, 22.237, 321.172, 0, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1208, 1125, 'UTCHIHA_ITACHI', 541, 900000, 0, 0, 'None', 20, 251, 1138.29, -1287.54, 13.172, 85.42, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1209, 1055, 'Adam_17', 560, 550000, 0, 1, 'None', 0, 883.351, 557.867, -1283.98, 17.0007, 0, 6, 6, 0, NULL, 0, 0, 18651, 1, 3, 1139, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1211, 1323, 'PABLO_GK', 463, 90000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1212, 1061, 'OSLO_MARLY', 587, 700000, 5000, 0, 'None', 20, 1000, 1226.34, -1359.99, 12.889, 85.025, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1213, 1324, 'Pablo_brown', 521, 120000, 0, 1, 'None', 96, 955.703, -1004.33, -2158.26, 34.495, 341.135, 0, 0, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1214, 1176, 'brazeli_mezox', 560, 550000, 0, 0, 'None', 14, 916, 1236.68, -1344.53, 12.872, 17.712, 241, 2, -1, NULL, 0, 0, 18649, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 0, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1215, 0, 'Nobody', 596, 0, 0, 0, 'None', 100, 1000, 291.705, -1518.05, 24.315, 238.268, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1217, 1294, 'SD_REX', 461, 100000, 0, 1, 'None', 100, 921, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(1218, 1294, 'SD_REX', 580, 300000, 0, 0, 'None', 20, 789.1, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1220, 2380, 'RIVALDO_XV', 506, 0, 0, 0, 'None', 84, 815.341, 1811.79, -1574.49, 13.225, 146.162, 1, 1, 1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1221, 1214, 'BANKAI_FIXA', 560, 550000, 0, 0, 'None', 0, 1000, 2193.21, -1810.8, 13.249, 357.794, 0, 0, 1, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 75, 0, 0, 24, 24, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1223, 1343, 'SPINOZA_RP_07', 560, 550000, 0, 1, 'None', 95, 800.266, 557.867, -1283.98, 17.0007, 0, 6, 1, -1, NULL, 0, 0, 18650, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 0, 1084, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1224, 1216, 'ZIZON_ZWITINA', 560, 550000, 0, 0, 'None', 5, 251, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1225, 1279, '__JO9LI_UX__', 560, 550000, 0, 1, 'None', 0, 843.957, 1309.43, -1461.21, 9.851, 245.113, 0, 0, 2, NULL, 0, 0, 18651, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 0, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1226, 1176, 'brazeli_mezox', 603, 850000, 0, 0, 'None', 18, 689, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1227, 556, 'ninga_Xvilo', 550, 300000, 0, 0, 'None', 100, 983.156, 1666.74, -2339.17, 1535.3, 358.899, 210, 210, -1, NULL, 3, 2000026, 18648, 1, 0, 1001, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1228, 663, 'WLD_NAMOSE', 482, 450000, 0, 1, 'None', 100, 910.017, 2161.67, -1172.98, 23.933, 88.766, 232, 2, 5, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1229, 1589, 'TiTaN_Hermano', 482, 450000, 0, 1, 'None', 19, 962.56, 833.647, -850.216, 70.031, 198.285, 0, 1, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1230, 2009, 'salma_vip', 482, 450000, 0, 0, 'None', 5, 514.461, 1283.66, -1302.85, 13.578, 87.457, 2, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1231, 1519, 'Boonina_Millions', 482, 450000, 0, 1, 'None', 99, 1000, 301.633, -1332.75, 53.53, 34.997, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1232, 1534, 'vergas__', 482, 450000, 0, 0, 'S', 19, 2139000000, 1218.46, -1355.21, 13.2, 182.064, 254, 2, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1233, 663, 'WLD_NAMOSE', 482, 450000, 0, 1, 'None', 99, 968.253, 2161.64, -1168.4, 23.928, 88.194, 111, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1234, 1529, 'Doomsday_demon', 482, 450000, 0, 0, 'None', 19, 919.437, 884.668, -1188.63, 17.09, 0.044, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 34, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1250, 1340, 'ilyass_chabab', 445, 300000, 0, 0, 'None', 19, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1251, 1324, 'Pablo_brown', 560, 550000, 0, 1, 'None', 17, 457.911, 2105.57, -1658.49, 15.065, 357.666, 86, 1, -1, NULL, 0, 0, 18649, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 0, 1074, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1252, 1366, 'SA_LMA', 586, 50000, 0, 0, 'None', 20, 825.407, 1183.77, -1322.7, 13.091, 166.437, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1253, 597, 'MOULL_SLAWI', 522, 1000000, 0, 1, 'None', 100, 652.705, 1189.05, -1324.65, 13.119, 1.806, 7, 8, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1254, 1370, 'pablo__gg', 560, 550000, 0, 0, 'None', 100, 300, 1825.1, -1146.55, 23.634, 171.5, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1255, 1471, 'IRT_WLD_ALI', 419, 250000, 0, 0, 'None', 85, 1000, 1311.23, -627.221, 108.935, 197.614, 1, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1256, 472, 'IMAD_LUCIANO', 426, 300000, 0, 0, 'None', 66, 976.045, 1629.77, -1098.31, 23.599, 87.622, 1, 2, -1, NULL, 0, 0, 18648, 1, 3, 1003, 1005, 1006, 0, 0, 1010, 1019, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1257, 1279, '__JO9LI_UX__', 541, 900000, 0, 1, 'None', 0, 520.89, 1222.42, -1425.7, 12.993, 321.51, 126, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1258, 1340, 'ilyass_chabab', 439, 500000, 0, 0, 'None', 100, 724.563, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1259, 1211, 'SRAH_N3AM', 436, 250000, 0, 1, 'None', 20, 975.536, 2016.19, -1767.79, 13.813, 90.647, 3, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1260, 1340, 'ilyass_chabab', 560, 550000, 0, 1, 'None', 100, 251, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1261, 2220, 'KRAY_TINAA', 541, 900000, 0, 0, 'None', 86, 882.435, 1949.19, -1812.8, 13.159, 267.824, 0, 0, 2, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1266, 535, 'Ilyas_Newton', 541, 900000, 0, 1, 'None', 0, 821.061, 691.857, -1171.27, 14.91, 45.277, 115, 243, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1267, 0, 'Nobody', 522, 0, 0, 1, 'None', 100, 1000, 1661.24, -1574.68, 12.954, 184.613, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1268, 2375, 'NINJA_NETWORK', 506, 0, 0, 0, 'None', 84, 671, 1671.41, -2346.48, 1535.16, 90.535, 1, 1, 1, NULL, 3, 2000072, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 8, 25, 28, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1269, 0, 'Nobody', 433, 0, 0, 0, 'None', 100, 1000, 868.094, -1207.29, 17.397, 179.848, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1270, 0, 'Nobody', 433, 0, 0, 0, 'None', 100, 1000, 898.148, -1207.3, 17.398, 180.273, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1272, 1315, 'adil_boktaf', 542, 300000, 0, 0, 'None', 99, 849, 1242.33, -1331.87, 12.913, 179.25, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1273, 502, 'joker_x7', 500, 450000, 5000, 0, 'None', 0, 732.793, 2016.21, -1760.91, 13.834, 188.297, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1274, 1211, 'SRAH_N3AM', 541, 900000, 0, 1, 'None', 19, 803.654, 748.272, -1276.57, 13.18, 1.96, 3, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1275, 513, 'YASSINE_CASSTILANO', 554, 400000, 0, 0, 'None', 91, 977.328, 1235.49, -1370.24, 13.266, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1276, 2933, 'X25_YASSINE', 418, 450000, 0, 1, 'None', 99, 904.35, 1256.32, -1435.03, 13.684, 1.383, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1277, 1416, 'Drogba_Anwar', 439, 500000, 0, 1, 'None', 19, 1000, 1209.47, -1885.45, 13.5, 92.995, 7, 7, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1280, 0, 'Nobody', 432, 0, 0, 0, 'None', 100, 1000, 829.848, -1215.05, 16.938, 268.682, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1283, 0, 'Nobody', 487, 0, 0, 0, 'None', 100, 1000, 662.075, -615.847, 16.513, 197.603, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1284, 0, 'Nobody', 495, 0, 0, 0, 'None', 100, 1000, 666.88, -579.019, 16.685, 90.381, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1285, 0, 'Nobody', 495, 0, 0, 0, 'None', 100, 1000, 667.243, -582.987, 16.687, 93.779, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1286, 0, 'Nobody', 495, 0, 0, 0, 'None', 100, 1000, 667.88, -586.857, 16.737, 96.264, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1287, 0, 'Nobody', 568, 0, 0, 0, 'None', 100, 1000, 667.429, -542.451, 16.203, 93.448, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1288, 0, 'Nobody', 568, 0, 0, 0, 'None', 100, 1000, 667.497, -546.247, 16.201, 94.125, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 4, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1289, 1452, 'Aguito_33_34', 422, 450000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1291, 1455, 'Aguito_Sossi', 418, 450000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1295, 910, 'Zakaria_Tiloxx', 489, 400000, 0, 1, 'None', 18, 800.614, 1253.6, -1245.8, 16.569, 83.214, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1297, 910, 'Zakaria_Tiloxx', 587, 700000, 0, 0, 'None', 14, 908.998, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1298, 765, 'NIZAR_XVILO', 415, 0, 0, 1, 'None', 98, 15706.5, 291.638, -1326.49, 53.049, 30.848, 177, 2, -1, NULL, 0, 0, 18648, 1, 3, 1023, 0, 0, 1017, 0, 1010, 1018, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1299, 910, 'Zakaria_Tiloxx', 468, 100000, 0, 0, 'None', 7, 999.528, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1300, 1425, '7AMOHI_YT', 475, 270000, 0, 0, 'None', 20, 1000, 1235.42, -1383.85, 13.123, 359.782, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1301, 828, 'mezo_loco', 560, 550000, 5000, 0, 'None', 16, 812, 2477.29, -1947.38, 13.482, 0, 128, 128, 3, NULL, 0, 0, 18649, 1, 3, 1139, 0, 1033, 1027, 0, 1009, 1029, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1302, 486, 'RIDA_DHX', 560, 550000, 0, 1, 'None', 100, 757.39, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1303, 975, 'supra_out', 589, 270000, 0, 1, 'None', 100, 982, 1241.75, -1355.02, 12.771, 85.711, 1, 1, 1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 1020, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1305, 1453, 'DAVOS_CB4', 603, 850000, 0, 0, 'None', 20, 1000, 1225.32, -1423.4, 13.208, 355.946, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1307, 407, 'oussama_r', 560, 550000, 0, 1, 'JAGUAR2000', 76, 944.878, 1212.33, -1419.8, 13.006, 1.339, 1, 1, 2, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1029, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 29, 0, 0, 25, 30, 25, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1308, 1473, 'Ninja_adreson', 541, 900000, 0, 0, 'None', 20, 1000, 1660.15, -2339.97, 1536.44, 89.376, 79, 79, -1, NULL, 3, 2000063, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 30, 25, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1309, 1962, 'fouade_2023', 560, 550000, 0, 1, 'None', 100, 54374, 1282.01, -1331.46, 13.029, 85.636, 1, 1, 2, NULL, 0, 0, 18648, 1, 3, 1139, 0, 1032, 1030, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 27, 27, 42, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1310, 279, 'Senior_Eltchapo', 536, 350000, 0, 0, 'None', 20, 699, 1223.47, -1362.71, 12.847, 31.086, 1, 1, 0, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 1182, 1183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1311, 1262, 'Izzy_Sbk', 560, 550000, 0, 1, 'None', 15, 251, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1312, 1511, 'itachi_adreson', 560, 550000, 0, 0, 'None', 17, 696.228, 1079.13, -1391.94, 13.325, 92.452, 0, 1, 1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 0, 0, 1010, 1029, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 75, 0, 0, 25, 30, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1314, 975, 'supra_out', 541, 900000, 0, 1, 'None', 100, 992.401, 1242.38, -1333.93, 12.755, 99.038, 6, 0, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1315, 1390, 'hk_henderson', 579, 310000, 0, 1, 'None', 90, 937.658, 1991.7, -1765.77, 13.93, 187.46, 1, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1317, 1471, 'IRT_WLD_ALI', 560, 550000, 0, 1, 'None', 92, 858.751, 1340.94, -627.928, 108.791, 200.179, 0, 0, 3, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1032, 1030, 0, 1010, 0, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1318, 1308, 'Musashi_Lucas', 560, 550000, 0, 0, 'None', 74, 460.203, 1315.19, -1373.03, 13.321, 176.013, 1, 2, 2, NULL, 0, 0, 18652, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1319, 3126, 'CHANI9A_LHAJ', 541, 900000, 0, 1, 'None', 100, 565.034, 858.368, -1412.2, 12.755, 179.493, 1, 0, 0, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1320, 3158, 'trock_bangala', 461, 100000, 0, 1, 'None', 40, 707, 1239.53, -1421.25, 13.398, 345.449, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1321, 0, 'Nobody', 429, 0, 0, 0, 'None', 100, 1000, 1240.7, -2011.27, 59.666, 207.301, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1322, 0, 'Nobody', 429, 0, 0, 0, 'None', 100, 1000, 1240.09, -2017.48, 59.63, 204.04, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1323, 0, 'Nobody', 429, 0, 0, 0, 'None', 100, 1000, 1240.51, -2023.98, 59.648, 213.382, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1324, 0, 'Nobody', 497, 0, 0, 0, 'None', 100, 1000, 590.619, -2322.96, 3.476, 1.611, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1325, 0, 'Nobody', 497, 0, 0, 0, 'None', 100, 1000, 1115.57, -2055.87, 74.605, 288.058, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1326, 1577, 'SANJI_XVILO', 576, 330000, 0, 1, 'None', 99, 1000, 1649.76, -1098.12, 23.459, 88.447, 0, 0, 1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 1137, 0, 1010, 1136, 1083, 0, 1087, 1190, 1193, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1328, 1279, '__JO9LI_UX__', 429, 9000000, 0, 0, 'None', 9, 929, 1912.7, -1631.77, 13.066, 267.413, 241, 4, 3, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1330, 1471, 'IRT_WLD_ALI', 579, 310000, 0, 1, 'None', 98, 856.692, 1361.31, -608.956, 109.061, 278.238, 126, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1331, 1279, '__JO9LI_UX__', 579, 310000, 0, 0, 'None', 52, 855.039, 1927.19, -1653.64, 13.478, 89.428, 194, 2, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1332, 1531, 'Anis_haway', 586, 50000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1333, 1962, 'fouade_2023', 579, 310000, 0, 1, 'None', 98, 860.177, 1281.14, -1339.43, 13.309, 85.383, 204, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1334, 1534, 'Vergas__', 579, 310000, 0, 1, 'None', 98, 750.487, 1926.95, -1650.81, 13.406, 91.225, 252, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1335, 818, 'OUSSAMA_U.h', 500, 450000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1336, 1534, 'Vergas__', 579, 310000, 0, 1, 'None', 84, 768.363, 1927.11, -1648.1, 13.426, 87.77, 241, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1337, 1534, 'Vergas__', 579, 310000, 0, 1, 'None', 0, 725.549, 1927.14, -1640.53, 13.484, 89.493, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1338, 1534, 'Vergas__', 579, 310000, 0, 1, 'None', 0, 927.727, 1927.07, -1643, 13.477, 89.852, 21, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1339, 1883, 'Marko_Locas', 579, 310000, 0, 1, 'None', 19, 800, 1234.35, -1376.85, 13.117, 333.954, 198, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1341, 663, 'WLD_NAMOSE', 579, 310000, 0, 1, 'None', 99, 811.244, 2161.74, -1158.04, 23.771, 91.3, 143, 2, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1342, 663, 'WLD_NAMOSE', 579, 310000, 0, 0, 'None', 98, 828.74, 2161.85, -1153.04, 23.86, 91.016, 132, 2, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1082, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1343, 2492, '_BRAZELI_BRZ_', 468, 100000, 0, 1, 'None', 95, 988.054, 2249.39, -1102.53, 41.271, 151.773, 251, 251, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1344, 1237, 'MOTCHA_LOTch', 521, 120000, 0, 0, 'None', 91, 439.418, 1241.75, -1336.83, 12.73, 83.647, 1, 1, -1, NULL, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 31, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1345, 1211, 'SRAH_N3AM', 541, 900000, 0, 1, 'None', 18, 1000, 751.756, -1276.81, 13.18, 359.076, 42, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1346, 2889, 'VEGAS_JNYN', 603, 850000, 0, 0, 'None', 62, 1000, 1968.6, -1791.86, 13.361, 87.407, 2, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1347, 1211, 'SRAH_N3AM', 602, 650000, 0, 0, 'None', 17, 1000, 751.349, -1262.68, 13.361, 359.807, 42, 2, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1084, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1348, 1589, 'TiTaN_Hermano', 461, 100000, 0, 1, 'None', 20, 1000, 827.592, -861.383, 69.473, 286.95, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1350, 1526, 'ACHRAF_IKCH', 560, 550000, 0, 0, 'None', 94, 985, 1535.42, -1670.26, 13.058, 175.014, 16, 16, -1, NULL, 0, 0, 18649, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1351, 401, 'SPY_DER', 522, 1000000, 0, 0, 'None', 20, 895.19, 1192.35, -1330.76, 12.938, 179.905, 3, 3, -1, NULL, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 0, 0, 31, 27, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1352, 1505, 'asta_adreson', 413, 500000, 0, 0, 'B2937', 96, 779.684, 1966.12, -1559.08, 13.829, 178.756, 0, 0, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1353, 1819, 'LA_BANDA_16', 560, 550000, 1000, 0, 'None', 99, 944.744, 1200.12, -1328.94, 13.104, 177.863, 113, 113, 2, NULL, 0, 0, 18652, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 0, 1073, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 29, 24, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1355, 1564, '__MESSI__', 521, 120000, 0, 1, 'None', 100, 820.945, 1978.63, -1769.26, 13.617, 176.56, 1, 1, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1356, 633, 'Za3ima_Aya', 521, 120000, 0, 1, 'None', 20, 750.533, 1244.06, -1367.09, 12.73, 81.174, 5, 5, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1357, 1308, 'Musashi_Lucas', 522, 1000000, 0, 1, 'None', 100, 894.173, 812.713, -1392.59, 12.974, 78.361, 1, 1, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1358, 2690, 'PEDRO_VGS', 560, 550000, 0, 1, 'None', 87, 773.532, 2822.36, -1557.83, 10.57, 90.006, 198, 0, 0, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1359, 1564, '__MESSI__', 581, 50000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1360, 472, 'IMAD_LUCIANO', 482, 450000, 0, 0, 'None', 99, 994.108, 2792.5, -1623.08, 11.049, 74.463, 1, 1, 1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1025, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 31, 34, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1361, 1279, '__JO9LI_UX__', 482, 450000, 0, 0, 'None', 20, 703.772, 974.184, -923.112, 45.888, 196.832, 0, 0, -1, NULL, 0, 4000107, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1362, 1580, 'Mehdi_Fransesco', 581, 50000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1363, 1882, 'Wassim_RUSSI', 603, 850000, 0, 0, 'None', 18, 998, 1221.33, -1332.9, 12.94, 270.443, 200, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 31, 34, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1364, 828, 'mezo_loco', 560, 0, 1000, 0, 'None', 97, 1000, 2477.29, -1947.38, 13.482, 0, 6, 6, 3, NULL, 0, 0, 18652, 1, 0, 1139, 0, 1033, 1030, 0, 1010, 1029, 1083, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1369, 1428, 'MARWAN_elTchapo', 560, 550000, 0, 1, 'None', 99, 780.16, 1535.92, -1666.73, 13.045, 180.871, 226, 226, 1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1371, 279, 'Senior_Eltchapo', 429, 9000000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1372, 279, 'Senior_Eltchapo', 560, 550000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1373, 1519, 'Oxe_404', 462, 25000, 0, 0, 'None', 98, 833, 1288.11, -1368.76, 13.172, 172.272, 158, 158, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1009, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1374, 1511, 'itachi_adreson', 522, 1000000, 0, 0, 'None', 76, 893.297, 2459.96, -2120.55, 13.121, 244.069, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1375, 1504, 'Jaguaar_adreson', 522, 1000000, 0, 0, 'None', 20, 1000, 1667.9, -2361.17, 1535.05, 273.894, 0, 0, -1, NULL, 3, 2000063, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1377, 1589, 'TiTaN_Hermano', 581, 50000, 0, 0, 'None', 0, 1000, 1235.51, -1370.31, 12.781, 77.455, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1378, 1211, 'SRAH_N3AM', 411, 1000000, 0, 0, 'None', 100, 952.466, 1651.43, -1903.68, 13.248, 12.802, 3, 3, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1379, 1055, 'Adam_17', 579, 310000, 0, 1, 'B2829', 0, 979.841, 1301.93, -1395.24, 13.191, 89.962, 1, 1, -1, NULL, 0, 0, 18648, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1380, 1308, 'WALTER', 481, 2500, 0, 0, 'None', 100, 2499, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1381, 1301, 'JEFFRY_VEGAS', 411, 1000000, 0, 1, 'None', 64, 1000, 1604.58, -1614.22, 13.242, 89.872, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1382, 1454, 'MOSTAFA_BONI', 545, 350000, 0, 1, 'None', 0, 795.095, 2794.56, -1613.3, 10.794, 63.419, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1384, 1973, 'PECASO_XM8', 560, 550000, 0, 0, 'None', 100, 932.406, 2109.08, -1778.87, 13.054, 174.417, 106, 106, 2, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1084, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1385, 1526, 'ACHRAF_IKCH', 560, 550000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1387, 894, 'TALIANI_WOLF', 560, 550000, 0, 0, 'None', 10, 1000, 1934.68, -1819.07, 13.252, 269.561, 0, 0, 0, NULL, 0, 0, 18650, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1388, 510, 'TOBA_DRDOKHI', 560, 550000, 0, 1, 'None', 96, 972.913, 2187.79, -1804.64, 13.034, 88.287, 2, 2, 0, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1029, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1389, 1570, '_RONALDO_', 560, 550000, 0, 1, 'None', 98, 1000, 2003.01, -1764.03, 13.71, 89.899, 200, 1, -1, NULL, 0, 0, 18650, 1, 3, 1138, 0, 0, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1390, 1061, 'OSLO_MARLY', 411, 1000000, 0, 0, 'None', 20, 930.052, 1985.13, -1777.65, 14.258, 179.093, 0, 0, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1391, 1429, 'Adil_Largou98', 461, 100000, 0, 0, 'None', 100, 251, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1392, 1429, 'Adil_Largou98', 509, 2500, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1393, 1074, 'PABLO_WOLF', 507, 300000, 0, 0, 'None', 12, 926.171, 1944.63, -1801.76, 13.32, 270.293, 200, 200, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1394, 534, 'AYM4N_WINS', 560, 550000, 0, 0, 'None', 92, 763.995, 990.111, -1453.19, 13.207, 357.952, 3, 3, 2, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1395, 831, 'MOUL_LBAN', 603, 850000, 0, 0, 'None', 91, 992.206, 1220.46, -1345.12, 12.977, 84.174, 0, 1, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1396, 770, 'LEOO_', 411, 1000000, 0, 1, 'None', 100, 537.3, 1954.3, -1752.73, 13.069, 80.369, 178, 178, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1398, 1308, 'Musashi_Lucas', 411, 1000000, 0, 0, 'None', 19, 942.801, 1670.69, -2344.87, 1535.18, 86.066, 0, 0, 1, NULL, 3, 2000071, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1399, 1308, 'Musashi_Lucas', 536, 350000, 0, 0, 'None', 20, 969.076, 169.098, -1366.89, 69, 214.932, 0, 0, 2, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1401, 1655, 'RESI_MGWAD', 560, 0, 0, 0, 'None', 100, 1000, 502.079, -1578.65, 16.248, 168.282, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1403, 1655, 'RESI_MGWAD', 441, 0, 0, 0, 'None', 100, 1000, 465.927, -1585.28, 25.22, 114.467, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1404, 1655, 'RESI_MGWAD', 541, 0, 0, 0, 'None', 100, 1000, 465.927, -1585.28, 25.22, 114.467, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1425, 1429, 'Adil_Largou98', 496, 300000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1428, 0, 'Nobody', 541, 0, 0, 0, 'None', 100, 1000, 291.979, -1544.94, 24.209, 57.158, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1430, 0, 'Nobody', 427, 0, 0, 0, 'None', 100, 1000, 307.425, -1482.43, 24.726, 231.753, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1431, 0, 'Nobody', 451, 0, 0, 0, 'None', 100, 1000, 300.398, -1504.43, 24.3, 235.465, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1432, 0, 'Nobody', 451, 0, 0, 0, 'None', 100, 1000, 303.553, -1500.18, 24.291, 237.682, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1433, 0, 'Nobody', 451, 0, 0, 0, 'None', 100, 1000, 297.743, -1508.61, 24.295, 236.88, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1434, 534, 'AYM4N_WINS', 522, 3000000, 0, 1, 'None', 25, 712.882, 51.479, -282.211, 1.275, 156.384, 3, 3, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1435, 1029, 'UTCHIHA_MADARA', 560, 935000, 0, 0, 'None', 20, 1000, 1970.91, -1587.35, 13.456, 93.46, 0, 0, 2, NULL, 0, 4000107, 18650, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1436, 2413, 'LKWAY__01', 510, 45000, 0, 0, 'None', 20, 733, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1437, 1308, 'WALTER', 579, 1300000, 0, 0, 'None', 99, 986.785, 1659.73, -2351.63, 1535.36, 269.148, 1, 1, -1, NULL, 3, 2000071, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1438, 1601, 'Ryad_Eltchapo', 560, 935000, 0, 0, 'None', 100, 910.299, 1659.25, -2342.86, 1535.15, 269.71, 6, 6, 3, NULL, 3, 2000065, 18652, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1439, 534, 'AYM4N_WINS', 426, 250000, 0, 0, 'None', 16, 960.217, 2767.82, -1961.07, 13.047, 173.368, 2, 2, 2, NULL, 0, 0, 18648, 1, 0, 1003, 1004, 0, 0, 0, 1010, 1019, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1440, 2385, 'Falcon_Millions', 560, 935000, 0, 0, 'None', 85, 2658.13, 1242.67, -1354.7, 12.865, 85.814, 6, 1, 1, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 23, 29, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1441, 663, 'WLD_NAMOSE', 579, 1300000, 0, 1, 'None', 99, 888.817, 2161.6, -1148.38, 24.254, 90.889, 1, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1442, 831, 'MOUL_LBAN', 550, 550000, 0, 1, 'None', 20, 994, 1222.31, -1371.76, 12.988, 219.723, 7, 7, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1443, 407, 'oussama_r', 560, 935000, 0, 1, 'None', 91, 1000, 2264.33, -1109.97, 37.64, 246.07, 13, 13, 3, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1444, 1601, 'Ryad_Eltchapo', 560, 935000, 0, 0, 'None', 100, 938.459, 1671.46, -2340.42, 1535.15, 89.386, 0, 0, 2, NULL, 3, 2000065, 18652, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1445, 2492, '_BRAZELI_BRZ_', 550, 550000, 0, 0, 'None', 86, 686.836, 1192.7, -1326.57, 13.217, 12.526, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1446, 1473, 'Ninja_adreson', 560, 935000, 0, 0, 'NINJA', 97, 846.51, 1671.21, -2339.6, 1535.15, 91.012, 1, 16, 0, NULL, 3, 2000063, 18651, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1028, 1078, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1447, 1069, 'mohmad_balhouss', 560, 935000, 0, 0, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1448, 1211, 'SRAH_N3AM', 496, 300000, 0, 0, 'None', 0, 1000, 562.397, -1283.85, 17.0007, 0, 241, 4, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1449, 1211, 'SRAH_N3AM', 496, 300000, 0, 0, 'None', 98, 766.995, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1450, 555, 'LVASTO_Alvaro', 496, 300000, 0, 1, 'None', 85, 784.626, 2057.19, -1780.79, 13.211, 269.474, 32, 3, 1, NULL, 0, 0, 18648, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1451, 555, 'LVASTO_Alvaro', 550, 550000, 0, 1, 'None', 97, 828.281, 2062.78, -1781.25, 13.334, 181.695, 1, 2, 0, NULL, 0, 0, 18647, 1, 1, 1023, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1452, 2641, 'MOUAD_MESSI', 522, 3000000, 0, 1, 'None', 100, 880.402, 2042.13, -1660.43, 13.109, 92.534, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1453, 1211, 'SRAH_N3AM', 496, 300000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 1, 4, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1454, 1211, 'SRAH_N3AM', 496, 300000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1455, 1211, 'SRAH_N3AM', 496, 300000, 0, 1, 'None', 95, 1000, 761.077, -1263.14, 13.28, 1.023, 3, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1456, 1953, 'oussama__lfrda', 550, 550000, 0, 0, 'None', 100, 666.874, 1242.35, -1352.38, 12.971, 272.401, 3, 3, -1, NULL, 0, 0, 18652, 1, 3, 1023, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1457, 1192, 'I_NAMOSE', 550, 550000, 0, 0, 'None', 100, 999.996, 1912.49, -1685.27, 13.166, 270.038, 126, 1, -1, NULL, 0, 0, 18651, 1, 3, 1003, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1458, 2093, '__SAYMON_UX__', 550, 550000, 0, 1, 'None', 0, 1000, 835.238, -877.277, 68.39, 68.457, 199, 2, -1, NULL, 0, 0, 18650, 1, 0, 1023, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1459, 2022, 'SI_MOR', 550, 550000, 0, 0, 'None', 8, 251, 2190.44, -1755.91, 13.277, 0.885, 201, 2, -1, NULL, 0, 0, 18652, 1, 3, 1003, 0, 0, 0, 0, 1010, 0, 1096, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1460, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 1820.67, -1567.6, 13.156, 165.757, 149, 149, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1461, 862, 'ZOU_HIR', 579, 1300000, 0, 1, 'None', 100, 972.514, 1223.7, -1424.71, 13.253, 358.843, 1, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1462, 1192, 'I_NAMOSE', 511, 14000000, 0, 1, 'None', 95, 1000, 1915.71, -2246.17, 14.928, 182.638, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1463, 772, 'mbli_blhxix', 510, 45000, 0, 1, 'None', 100, 829.121, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1464, 1644, 'zakariq__Xb00', 510, 45000, 0, 0, 'None', 100, 956.034, 986.55, -1432.91, 13.153, 349.217, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1465, 1584, 'Morgane_L3ZWA', 426, 250000, 0, 1, 'None', 99, 701.689, 1531.79, -1584.05, 13.292, 266.521, 1, 2, -1, NULL, 0, 0, 18652, 1, 3, 1003, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1466, 663, 'WLD_NAMOSE', 550, 550000, 0, 1, 'None', 99, 859.992, 2161.39, -1177.8, 23.599, 88.412, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 1023, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1467, 1962, 'fouade_2023', 445, 350000, 0, 1, 'None', 99, 53121.2, 1242.13, -1347.6, 13, 90.564, 128, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1468, 2789, 'SI_ALI', 579, 1300000, 0, 1, 'None', 100, 997.183, 1648.09, -1080.56, 23.842, 270.147, 1, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1469, 597, 'MOULL_SLAWI', 426, 250000, 0, 1, 'None', 100, 822.527, 1893.92, -1743.07, 13.272, 179.247, 3, 3, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1470, 975, 'supra_out', 496, 300000, 0, 1, 'None', 100, 705.499, 1242.48, -1337.07, 12.847, 98.046, 0, 0, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1471, 633, 'Za3ima_Aya', 579, 1300000, 0, 1, 'B2837', 100, 997.197, 2483.99, -2000.98, 13.452, 126.814, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1472, 2690, 'PEDRO_VGS', 496, 300000, 0, 1, 'None', 100, 845.178, 1281.68, -1352.8, 13.061, 89.616, 158, 158, 0, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1473, 1601, 'Ryad_Eltchapo', 560, 935000, 0, 0, 'None', 14, 975.027, 1671.44, -2342.71, 1535.15, 88.094, 1, 1, 1, NULL, 3, 2000065, 18648, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 0, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1474, 1709, 'SUPRA_MK4', 510, 45000, 0, 0, 'None', 20, 829, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1475, 498, 'mo_rad', 603, 870000, 0, 0, 'None', 100, 16051.9, 1671.06, -2339.03, 1535.32, 90.871, 0, 0, 3, NULL, 3, 2000055, 0, 0, 1, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1477, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2228.12, -1166.78, 25.364, 88.403, 233, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1478, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2205.47, -1153.11, 25.411, 272.068, 233, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1479, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2205.69, -1165.07, 25.784, 269.799, 233, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1480, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2205.73, -1173.06, 25.781, 269.931, 233, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1481, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2765.55, -1936.29, 13.134, 0.232, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 410065408, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1482, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 1219.1, -1361.53, 12.838, 77.209, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 410065408, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1483, 0, 'Nobody', 463, 0, 0, 0, 'None', 100, 1000, 2773.34, -1958.55, 12.846, 68.056, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(1484, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2781.25, -1944.37, 13.598, 89.656, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1485, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2756.1, -1944.51, 13.572, 269.41, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1486, 0, 'Nobody', 463, 0, 0, 1, 'None', 100, 1000, 2773.3, -1959.24, 12.847, 67.78, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1487, 0, 'Nobody', 463, 0, 0, 0, 'None', 100, 1000, 2773.45, -1957.89, 12.846, 68.147, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1488, 1228, 'ADAM__ROUSSI', 510, 45000, 0, 1, 'None', 100, 931.55, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1489, 1589, 'TiTaN_Hermano', 603, 870000, 0, 0, 'None', 12, 918.426, 1242.3, -1362.55, 12.969, 86.444, 1, 2, -1, NULL, 0, 0, 18648, 1, 0, 1023, 0, 1006, 0, 0, 0, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1490, 1973, 'PECASO_XM8', 560, 935000, 0, 0, 'None', 94, 987.16, 2114.25, -1781.3, 13.093, 173.113, 6, 6, 2, NULL, 0, 0, 0, 0, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1493, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 968.159, -913.145, 45.435, 183.854, 149, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1494, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 965.418, -913.358, 45.435, 180.647, 149, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1495, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 952.84, -933.311, 42.472, 180.303, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1496, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 960.53, -906.611, 45.82, 182.506, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1497, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 960.065, -896.876, 45.819, 182.635, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1498, 1819, 'LA_BANDA_16', 445, 350000, 0, 0, 'None', 100, 895.344, 1104.41, -1391.46, 13.37, 83.025, 0, 0, 1, NULL, 0, 0, 18647, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1502, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2769.04, -1615.75, 10.585, 268.471, 6, 255, -1, NULL, 0, 0, 18650, 1, 3, 1139, 0, 1033, 1026, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 1410065408, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1503, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2780.15, -1601.71, 10.592, 178.336, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 1410065408, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1504, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2782.35, -1601.72, 10.59, 189.653, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 1410065408, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1505, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2768.76, -1605.64, 10.971, 271.434, 6, -1, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 1410065408, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1506, 1601, 'Ryad_Eltchapo', 560, 935000, 0, 0, 'None', 10, 936.693, 1671.46, -2338.03, 1535.12, 88.978, 135, 135, -1, NULL, 3, 2000065, 18648, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1085, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1507, 1660, 'T_RexX', 481, 25000, 0, 0, 'None', 100, 914, 1236.03, -1382.49, 12.701, 324.958, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1508, 1660, 'T_RexX', 481, 25000, 0, 0, 'None', 100, 997.096, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1509, 992, 'Lhaj_Omar', 579, 1300000, 0, 0, 'None', 97, 17072.1, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1510, 1601, 'Ryad_Eltchapo', 504, 0, 0, 1, 'None', 15, 969.345, 1670.88, -2352.25, 1535.23, 93.555, 1, 1, -1, NULL, 3, 2000065, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1511, 1601, 'Ryad_Eltchapo', 559, 0, 0, 1, 'None', 100, 958.912, 1671.5, -2355.43, 1535.1, 91.412, 1, 1, 0, NULL, 3, 2000065, 18650, 1, 3, 1162, 0, 1067, 1071, 0, 1010, 0, 1081, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1512, 1601, 'Ryad_Eltchapo', 487, 0, 0, 1, 'None', 76, 892.357, 1355.9, -612.388, 109.311, 114.486, 155, 155, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1513, 1055, 'Adam_17', 445, 350000, 0, 0, 'None', 0, 856.33, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1514, 1198, 'Hamza_Hercolano', 560, 935000, 0, 1, 'RIDA', 19, 884.453, 1903.87, -1625.71, 13.082, 357.567, 2, 2, 2, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1029, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1515, 1456, 'DEV_MARTINE', 426, 250000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1516, 1191, 'ZIZEWAR_X', 496, 300000, 0, 1, 'None', 100, 759.475, 1011.93, -1915.23, 12.442, 118.626, 1, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1517, 1191, 'ZIZEWAR_X', 579, 1300000, 0, 1, 'None', 100, 997.424, 1926.74, -1737.84, 13.477, 355.476, 1, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1518, 1211, 'SRAH_N3AM', 560, 935000, 0, 0, 'None', 12, 982.447, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1519, 1191, 'ZIZEWAR_X', 560, 935000, 0, 0, 'None', 13, 967.503, 1971.69, -1764.4, 13.656, 283.778, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1520, 1211, 'SRAH_N3AM', 560, 935000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 1, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1521, 1211, 'SRAH_N3AM', 560, 935000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1523, 1670, 'X7__BRAZIL__X', 439, 500000, 0, 1, 'None', 9, 971.38, 961.22, -925.262, 45.661, 359.837, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1525, 2129, 'ilyass_smp', 560, 550000, 0, 0, 'None', 20, 577.627, 1671.45, -2340.24, 1535.15, 89.315, 0, 0, 2, NULL, 3, 2000027, 18647, 1, 0, 1139, 0, 1033, 1030, 0, 1010, 1029, 1085, 0, 1087, 1170, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1526, 2641, 'MOUAD_MESSI', 541, 900000, 0, 1, 'None', 100, 995.86, 1513.41, -838.034, 66.768, 80.759, 1, 7, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1527, 2641, 'MOUAD_MESSI', 412, 250000, 0, 0, 'None', 100, 863.334, 1517.25, -835.262, 67.458, 47.238, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1528, 1471, 'IRT_WLD_ALI', 482, 450000, 0, 1, 'None', 98, 980.812, 1304.74, -640.374, 108.675, 191.973, 2, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1529, 1785, 'carlos_bertone', 600, 270000, 0, 0, 'None', 100, 965.003, 1248.58, -1258.61, 12.883, 180, 2, 2, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1531, 597, 'MOULL_SLAWI', 541, 900000, 0, 1, 'None', 100, 1000, 1901.04, -1742.69, 13.149, 176, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1533, 1069, 'mohmad_balhouss', 560, 0, 0, 0, 'None', 20, 251, 1673.57, 1426.25, 10.78, 338.672, 3, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1534, 1505, 'asta_adreson', 603, 850000, 0, 1, 'None', 20, 708.593, 1979.55, -1766.96, 13.855, 189.716, 6, 0, -1, NULL, 0, 0, 18650, 1, 3, 1023, 0, 1006, 1017, 1024, 1010, 1018, 1096, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1535, 0, 'Nobody', 560, 0, 0, 1, 'None', 100, 1000, 1604.7, -1631.18, 13.236, 85.503, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1536, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 1605.28, -1627.64, 13.228, 90.366, 2, 2, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1537, 0, 'Nobody', 541, 0, 0, 1, 'None', 100, 1000, 1605.66, -1622.49, 13.182, 70.981, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1538, 0, 'Nobody', 541, 0, 0, 0, 'None', 100, 1000, 1605.7, -1617.05, 13.149, 79.332, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1539, 0, 'Nobody', 522, 0, 0, 1, 'None', 100, 1000, 1605.6, -1612.19, 13.108, 83.16, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1540, 0, 'Nobody', 522, 0, 0, 0, 'None', 100, 1000, 1605.49, -1613.08, 13.124, 83.161, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1541, 983, 'LODING_LUCIANO', 510, 10000, 0, 0, 'None', 100, 902.106, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1542, 0, 'Nobody', 596, 0, 0, 1, 'None', 100, 1000, 1587.44, -1605.65, 13.122, 162.68, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1543, 0, 'Nobody', 596, 0, 0, 0, 'None', 100, 1000, 1581.78, -1606.67, 13.139, 161.562, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1544, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 1147.44, -1357.15, 13.382, 93.493, 119, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1546, 2789, 'SI_ALI', 560, 550000, 0, 1, 'None', 100, 989.341, 1647.81, -1107.75, 23.576, 268.392, 1, 1, -1, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1033, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1547, 0, 'Nobody', 416, 0, 0, 1, 'None', 100, 1000, 1123.84, -1329.05, 13.412, 353.356, -1, -1, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1548, 0, 'Nobody', 416, 0, 0, 1, 'None', 100, 1000, 1111.36, -1330.05, 13.315, 6.454, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1549, 106, 'ZETSU_XVILO', 562, 0, 0, 1, 'None', 100, 15836.8, 528.058, -1917.57, 4.562, 177.965, 33, 2, 1, NULL, 0, 0, 18650, 1, 3, 1147, 0, 1038, 1040, 0, 1010, 1034, 1077, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1550, 10, 'LHAJ_LBATAL', 541, 900000, 0, 0, 'None', 71, 986.608, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1551, 10, 'LHAJ_LBATAL', 560, 550000, 0, 1, 'None', 14, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1553, 646, '_BRITILLE_', 468, 100000, 0, 1, 'AMINE', 20, 865.015, 2038.59, -1741.43, 13.214, 178.233, 1, 1, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1556, 646, '_BRITILLE_', 521, 120000, 0, 1, 'None', 20, 957.814, 2037.56, -1741.39, 13.118, 179.252, 50, 50, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 25, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1557, 1399, 'achraf_nh', 562, 0, 0, 0, 'None', 88, 679.271, 959.67, -1354.91, 13.002, 182.438, 175, 175, 3, NULL, 0, 0, 18647, 1, 0, 1146, 0, 1038, 1040, 0, 1010, 1037, 1073, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1558, 1399, 'achraf_nh', 559, 0, 0, 0, 'None', 91, 982.262, 955.594, -1355.05, 12.965, 179.599, 3, 3, 1, NULL, 0, 0, 18651, 1, 0, 1158, 0, 1067, 1072, 0, 1010, 1066, 1079, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1559, 983, 'LODING_LUCIANO', 560, 550000, 0, 1, 'None', 98, 990.935, 1101.61, -1352.64, 13.964, 186.005, 0, 0, 3, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 0, 0, 1010, 0, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 25, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1561, 106, 'ZETSU_XVILO', 558, 0, 0, 1, 'None', 19, 948.799, 2498.73, -1684.76, 13.045, 108.312, 1, 1, 2, NULL, 0, 0, 18648, 1, 3, 1164, 0, 1088, 0, 0, 1010, 1092, 1077, 0, 0, 1166, 1168, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1562, 1453, 'davos_cb4', 481, 2500, 0, 1, 'None', 20, 977, 1217.33, -1424.34, 12.86, 13.9, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1563, 524, 'monster_yt', 411, 1000000, 0, 0, 'None', 89, 832.728, 2037.26, -1522.66, 3.15, 236.524, 166, 2, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1564, 1500, 'ZORO__XVILO', 522, 1000000, 0, 1, 'dd', 87, 824.708, 2227.93, -1152.57, 25.406, 85.772, 1, 1, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1565, 1973, 'PECASO_XM8', 550, 300000, 0, 0, 'None', 19, 1000, 2116.67, -1782.82, 13.209, 174.855, 213, 213, -1, NULL, 0, 0, 18651, 1, 3, 1001, 1004, 1006, 0, 0, 1010, 1020, 1074, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1566, 765, 'NIZAR_XVILO', 535, 0, 0, 1, 'None', 100, 985.66, 2466.49, -1673.51, 13.173, 17.121, 3, 2, 0, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 1114, 1025, 0, 1087, 1115, 1109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1567, 1538, '7LIWA_L7A9ED', 541, 900000, 0, 0, 'None', 91, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1568, 1538, '7LIWA_L7A9ED', 579, 310000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1569, 1538, '7LIWA_L7A9ED', 545, 350000, 0, 1, 'None', 96, 878.814, 2796.96, -1562.65, 10.734, 270.085, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1570, 1500, 'ZORO__XVILO', 429, 9000000, 0, 1, 'JAGUARE', 100, 760.04, 393.294, -2044.34, 7.516, 91.018, 226, 0, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1571, 1501, 'LUFFY_XVILO', 522, 1000000, 0, 1, 'None', 96, 991.569, 1208.21, -1424.86, 12.944, 152.956, 3, 0, -1, NULL, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1572, 3175, 'Mr_J4CK', 586, 50000, 0, 0, 'None', 91, 251, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1573, 646, '_BRITILLE_', 522, 1000000, 0, 1, 'None', 20, 686.716, 2039.78, -1741.39, 13.11, 178.236, 6, 6, 5, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1008, 0, 1082, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1574, 1453, 'davos_cb4', 411, 1000000, 0, 1, 'None', 20, 873.164, 1222.52, -1423.91, 13.063, 350.729, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1575, 2330, 'StreexX_S4', 541, 900000, 0, 0, 'YASSIN', 100, 1000, 2502.74, -1681.85, 13.05, 298.991, 0, 228, 3, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1576, 1192, 'I_NAMOSE', 602, 650000, 0, 0, 'None', 99, 991.909, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1577, 1211, 'SRAH_N3AM', 602, 650000, 0, 1, 'None', 94, 818.916, 741.985, -1263.83, 13.361, 1.163, 2, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1578, 1192, 'I_NAMOSE', 602, 650000, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1579, 1192, 'I_NAMOSE', 602, 650000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1580, 1192, 'I_NAMOSE', 602, 650000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1581, 1589, 'TiTaN_Hermano', 541, 900000, 0, 1, 'None', 19, 700.629, 835.613, -855.126, 69.542, 196.669, 6, 1, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1582, 1589, 'TiTaN_Hermano', 541, 900000, 0, 0, 'None', 96, 838.572, 836.705, -861.636, 69.361, 161.336, 1, 4, -1, NULL, 0, 0, 18652, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1583, 1198, 'Hamza_Hercolano', 541, 900000, 0, 1, 'None', 91, 796.013, 1927.54, -1636.35, 13.172, 96.166, 0, 3, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1584, 1804, 'CaTaNa_Ta', 541, 900000, 0, 0, 'None', 20, 670.86, 1669.38, -2339.73, 1535.11, 270.329, 0, 1, -1, NULL, 3, 2000012, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1585, 1584, 'Morgane_L3ZWA', 541, 900000, 0, 1, 'None', 90, 996.72, 1103.59, -1406.28, 13.056, 228.579, 233, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 31, 29, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1586, 1601, 'Ryad_Eltchapo', 522, 1000000, 0, 1, 'None', 20, 954.678, 1664.95, -2361.22, 1535.05, 92.837, 229, 229, -1, NULL, 3, 2000065, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1587, 2174, 'Vergas__', 560, 550000, 0, 1, 'None', 91, 765.395, -1004.05, -2154.64, 34.817, 83.896, 3, 3, 2, NULL, 0, 0, 18648, 0, 3, 1139, 0, 1032, 0, 0, 1010, 0, 1084, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1588, 1171, 'ZWITA_', 468, 100000, 0, 0, 'None', 18, 492.132, 1325.57, -1277.55, 13.045, 96.439, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1589, 2986, 'ZWITA_XVILO', 458, 280000, 0, 1, 'None', 84, 968.998, 1230.86, -1425.68, 13.321, 1.82, 198, 0, 1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1591, 1471, 'IRT_WLD_ALI', 418, 450000, 0, 0, 'None', 96, 840.574, 1622.22, -1107.99, 23.999, 267.637, 2, 1, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1592, 1838, 'Figou_Deep', 496, 250000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1593, 1838, 'Figou_Deep', 475, 270000, 0, 0, 'None', 100, 753.721, 1921, -1660.17, 13.35, 19.246, 233, 2, -1, NULL, 0, 0, 18650, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 34, 34, 34, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1594, 1838, 'Figou_Deep', 468, 100000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1595, 1843, 'Anis_Chahedd', 521, 120000, 0, 1, 'None', 71, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1596, 496, 'KATANA_HQ', 587, 700000, 0, 0, 'None', 82, 920, 2117.29, -1784.1, 13.078, 359.643, 1, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1597, 597, 'MOULL_SLAWI', 541, 900000, 0, 1, 'None', 100, 1000, 1886.16, -1739.27, 13.046, 181.885, 3, 2, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1598, 3158, 'trock_bangala', 587, 700000, 0, 1, 'None', 100, 960.561, 951.145, -1354.86, 13.036, 179.626, 158, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1599, 1494, 'AZIZ_LFERDA', 560, 550000, 0, 0, 'None', 93, 251, 1473.07, -1646.93, 13.853, 239.863, 4, 4, 0, NULL, 0, 0, 18652, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1600, 2544, 'DARK__SGHIR', 461, 100000, 0, 1, 'None', 80, 669.704, 1275.77, -1259.11, 13.478, 359.191, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1601, 2627, 'Simo_KB', 521, 120000, 0, 0, 'None', 100, 562.215, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1602, 1192, 'I_NAMOSE', 545, 350000, 0, 0, 'None', 18, 1000, 1944.94, -1791.26, 13.159, 269.196, 128, 1, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1603, 1534, 'Vergas__', 402, 850000, 0, 0, 'None', 89, 887.274, 1917.56, -1626.78, 13.335, 179.508, 6, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1604, 1973, 'PECASO_XM8', 587, 700000, 0, 1, 'None', 100, 923.068, 2120.58, -1783.59, 13.086, 170.491, 1, 1, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1605, 1973, 'PECASO_XM8', 541, 900000, 0, 0, 'None', 9, 1000, 2115.25, -1776.07, 13.017, 83.365, 200, 200, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1606, 975, 'supra_out', 541, 900000, 0, 0, 'None', 100, 1000, 2011.52, -1773.32, 13.865, 188.949, 0, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1607, 1198, 'Hamza_Hercolano', 560, 550000, 0, 0, 'None', 17, 950, 2002.88, -1777.55, 14.221, 181.059, 126, 126, 1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1608, 1198, 'Hamza_Hercolano', 560, 550000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1609, 2521, 'Dinar_Sara', 510, 10000, 0, 1, 'None', 20, 785, 986.328, -1432.25, 13.153, 344.232, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1610, 0, 'Nobody', 463, 0, 0, 1, 'None', 100, 1000, 2508.63, -2013.58, 12.821, 34.86, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1611, 2298, 'mohamd_lferda', 468, 100000, 0, 0, 'None', 100, 737.099, 2784.23, -1601.72, 10.591, 181.042, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1612, 2118, 'Edgar_Carlos', 560, 550000, 0, 1, 'None', 100, 1000, 533.346, -1290.01, 16.953, 202.57, 1, 0, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1613, 2715, 'L9ATAL__ZRZOOR', 555, 450000, 0, 0, 'None', 90, 12253.6, 996.948, -927.922, 41.856, 98.355, 1, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1614, 2174, 'Vergas__', 541, 900000, 0, 1, 'None', 15, 1000, 1911.99, -1676.28, 12.952, 269.933, 8, 0, -1, NULL, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1615, 1505, 'asta_adreson', 560, 550000, 0, 0, 'None', 94, 1000, 660.514, -1236.16, 14.63, 148.337, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1616, 0, 'Nobody', 463, 0, 0, 0, 'None', 100, 1000, 2507.57, -2013.58, 12.822, 34.112, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1617, 0, 'Nobody', 463, 0, 0, 0, 'None', 100, 1000, 2506.61, -2013.56, 12.822, 40.268, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1618, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2516.82, -2013.81, 12.95, 43.645, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1619, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2517.85, -2013.84, 12.95, 40.373, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1620, 0, 'Nobody', 468, 0, 0, 1, 'None', 100, 1000, 2516.11, -2013.84, 13.036, 33.928, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1621, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2469.64, -1679.62, 13.525, 34.848, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1622, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2489.88, -1646.14, 13.564, 89.227, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1623, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2488.33, -1634.19, 13.16, 178.525, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1624, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2473.83, -1645.35, 13.18, 188.068, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1625, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2472.42, -1645.34, 13.18, 181.925, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1626, 0, 'Nobody', 468, 0, 0, 1, 'None', 100, 1000, 2475.24, -1645.09, 13.179, 187.284, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1627, 0, 'Nobody', 481, 0, 0, 0, 'None', 100, 1000, 2469.18, -1636.54, 12.981, 91.855, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1628, 0, 'Nobody', 481, 0, 0, 0, 'None', 100, 1000, 2468.86, -1640.39, 12.998, 90.766, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1629, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2490.82, -1634.18, 13.16, 177.039, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1630, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 1790.31, -2422.35, 13.223, 122.051, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1631, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2781.3, -1601.8, 10.586, 188.504, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1632, 1882, 'Wassim_RUSSI', 560, 550000, 0, 0, 'None', 96, 1000, 1221.22, -1336.69, 12.739, 272.736, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1085, 0, 1087, 1169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1633, 1511, 'itachi_adreson', 541, 900000, 0, 0, 'IMRANE', 100, 251, 1030.34, -1402.88, 12.753, 270.244, 3, 3, 1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1634, 1601, 'Ryad_Eltchapo', 562, 0, 0, 1, 'xx', 100, 685.383, 1671.31, -2349.76, 1535.11, 93.877, 33, 2, 1, NULL, 3, 2000065, 18647, 1, 3, 1147, 0, 1035, 1040, 0, 1010, 0, 1077, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1635, 1471, 'IRT_WLD_ALI', 401, 300000, 0, 1, 'None', 95, 644.84, 1362.62, -615.654, 108.87, 103.066, 198, 233, 0, NULL, 0, 0, 18648, 1, 0, 1003, 0, 1006, 1017, 0, 1010, 1020, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1636, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2802.92, -1111.38, 30.424, 359.707, 223, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1637, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2806.93, -1111.45, 30.424, 359.171, 223, -1, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1638, 0, 'Nobody', 459, 0, 0, 0, 'None', 100, 1000, 2805.09, -1063.38, 30.606, 180.744, 223, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1640, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2796.84, -1079.03, 30.388, 266.133, 223, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1641, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2796.79, -1096.33, 30.388, 270.741, 223, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1642, 611, '$LOKER_JOKER$$8', 411, 1000000, 0, 0, 'None', 100, 629.328, 2500.62, -2015.33, 13.124, 88.727, 2, 2, 3, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 61, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1643, 1388, 'Finix_boneli', 581, 50000, 0, 0, 'None', 20, 985.355, 559.738, -1263.96, 16.802, 173.986, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1645, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2728.98, -422.39, 17.687, 242.535, 240, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1653, 0, 'Nobody', 463, 0, 0, 0, 'None', 100, 1000, 1829.92, -1118.02, 23.413, 78.525, 240, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, -1, -1379935552, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1654, 0, 'Nobody', 463, 0, 0, 1, 'None', 100, 1000, 1829.98, -1116.61, 23.412, 83.658, 240, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, -1, -1379935552, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1655, 0, 'Nobody', 463, 0, 0, 1, 'None', 100, 1000, 1829.83, -1131.86, 23.415, 92.632, 240, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, -1, -1379935552, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1656, 1463, 'Ninja_l9tal1', 560, 550000, 0, 1, 'None', 9, 593.079, 1282.61, -1292.22, 13.108, 89.187, 1, 1, -1, NULL, 0, 0, 18649, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1657, 1308, 'Musashi_Lucas', 555, 450000, 0, 1, 'None', 15, 997.044, 383.56, -2068.68, 7.52, 175.638, 5, 9, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1658, 498, 'mo_rad', 545, 350000, 0, 1, 'None', 100, 1000, 864.46, -1534.25, 13.366, 354.321, 226, 226, 0, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1659, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2516.57, -2005.11, 13.111, 93.156, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1660, 1804, 'CaTaNa_Ta', 522, 1000000, 0, 1, 'None', 100, 824.108, 1659.01, -2355.91, 1535.05, 88.807, 0, 0, -1, NULL, 3, 2000012, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1663, 2789, 'SI_ALI', 545, 350000, 0, 1, 'None', 100, 1000, 1648.37, -1088.96, 23.717, 272.776, 2, 2, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1664, 1279, '__JO9LI_UX__', 522, 1000000, 0, 0, 'None', 13, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1665, 1279, '__JO9LI_UX__', 545, 350000, 0, 0, 'None', 100, 991.325, 1071.27, -900.14, 43.202, 92.912, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1666, 1504, 'Jaguaar_adreson', 603, 850000, 0, 1, 'None', 100, 251, 1242.2, -1308.19, 12.978, 92.858, 143, 6, 2, NULL, 0, 0, 18649, 1, 3, 1001, 0, 1006, 0, 0, 1010, 1018, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1667, 2641, 'MOUAD_MESSI', 603, 850000, 0, 1, 'None', 100, 1000, 1519.39, -838.385, 67.062, 70.307, 2, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1668, 1471, 'IRT_WLD_ALI', 522, 1000000, 0, 0, 'None', 87, 978.987, 1675.48, -1118.1, 23.479, 269.379, 2, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1669, 653, 'MADA_xvilo', 500, 450000, 0, 1, 'None', 100, 948.124, 1467.1, -1609.58, 14.151, 272.421, 128, 128, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1670, 1500, 'ZORO__XVILO', 581, 50000, 0, 0, 'None', 19, 17121, 2224.66, -1143.05, 25.393, 347.373, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1671, 1865, 'alex_boneli', 468, 100000, 0, 1, 'None', 99, 849.8, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1672, 3175, 'Mr_J4CK', 581, 50000, 0, 1, 'None', 8, 868.698, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1673, 1432, 'Bachta_20', 603, 850000, 0, 1, 'None', 94, 1000, 1146.57, -1366.92, 13.664, 3.783, 178, 0, -1, NULL, 0, 0, 18651, 1, 3, 1001, 0, 1006, 0, 0, 1010, 1018, 1074, 0, 0, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1674, 1279, '__JO9LI_UX__', 424, 550000, 0, 1, 'None', 16, 914.831, 1365.1, -1869.04, 13.343, 110.33, 255, 255, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1675, 2789, 'SI_ALI', 579, 310000, 0, 1, 'None', 100, 994.225, 1648.4, -1084.75, 23.838, 266.77, 3, 3, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1676, 1192, 'I_NAMOSE', 587, 700000, 0, 1, 'None', 100, 880, 1926.5, -1626.56, 13.273, 173.689, 201, 2, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1677, 1179, 'ENZO_MOHAMED', 602, 650000, 0, 0, 'None', 13, 455, 1220.23, -1336.68, 12.975, 259.281, 1, 1, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1678, 1192, 'I_NAMOSE', 560, 550000, 0, 1, 'None', 100, 798.27, 747.586, -1235.34, 13.251, 2.392, 50, 1, 1, NULL, 0, 0, 18648, 1, 0, 1139, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1679, 894, 'TALIANI_WOLF', 587, 700000, 0, 0, 'None', 89, 479.607, 1948.8, -1815.18, 13.274, 269.662, 233, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1680, 1882, 'Wassim_RUSSI', 541, 900000, 0, 1, 'None', 20, 732.822, 2493.52, -1679.07, 12.928, 327.289, 6, 0, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1681, 421, 'PRO_BOT', 541, 900000, 0, 0, 'None', 17, 1000, 1132.28, -2033.18, 68.632, 269.017, 10, 7, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1682, 2117, 'zindigui_12', 580, 300000, 5000, 0, 'None', 17, 677.682, 1649.89, -1903.26, 13.308, 1.808, 2, 2, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1084, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1683, 1601, 'Ryad_Eltchapo', 576, 330000, 0, 1, 'None', 100, 957.153, 1659.4, -2351.06, 1535.09, 267.075, 3, 4, -1, NULL, 3, 2000065, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1684, 1074, 'PABLO_WOLF', 482, 450000, 0, 0, 'None', 15, 980.719, 1944.3, -1806.69, 13.663, 269.593, 2, 2, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1685, 1191, 'ZIZEWAR_X', 555, 450000, 0, 1, 'None', 94, 1000, 1629.78, -1084.9, 23.59, 88.797, 0, 0, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1686, 894, 'TALIANI_WOLF', 422, 450000, 0, 0, 'None', 82, 977.328, 1948.73, -1811.29, 13.467, 265.568, 2, 2, 3, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1687, 894, 'TALIANI_WOLF', 489, 400000, 0, 0, 'None', 0, 775.395, 1948.17, -1806.18, 13.642, 265.809, 10, 10, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1688, 1074, 'PABLO_WOLF', 587, 700000, 0, 0, 'None', 89, 675.347, 1944.45, -1811.21, 13.238, 271.038, 17, 17, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1689, 2968, 'ilyass_xx', 487, 15550000, 0, 0, 'None', 100, 1000, 1881.02, -1393.28, 13.743, 330.993, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1690, 1192, 'I_NAMOSE', 541, 900000, 0, 1, 'None', 100, 901.913, 1536.1, -1676.88, 12.979, 180.074, 241, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1691, 1534, 'Vergas__', 541, 900000, 0, 1, 'None', 19, 997.606, 1925.65, -1625.95, 13.172, 181.693, 1, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1692, 2789, 'SI_ALI', 541, 900000, 0, 0, 'None', 99, 979.445, 1649.31, -1097.37, 23.531, 86.917, 6, 0, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1693, 3129, 'WLD_LHAJ_2', 541, 900000, 0, 0, 'None', 100, 1000, 1101.17, -1376.12, 13.482, 180.086, 0, 6, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1694, 1192, 'I_NAMOSE', 541, 900000, 0, 0, 'None', 100, 1000, 1927.97, -1645.08, 13.172, 91.574, 241, 0, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1696, 1471, 'IRT_WLD_ALI', 541, 900000, 0, 1, 'None', 98, 623, 1352.05, -607.882, 108.562, 355.515, 0, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1698, 1192, 'I_NAMOSE', 411, 1000000, 0, 1, 'None', 100, 518.308, 2004.22, -1758.19, 13.225, 99.23, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1699, 1192, 'I_NAMOSE', 411, 1000000, 0, 0, 'None', 98, 300, 682.886, -1180.78, 15.136, 109.618, 158, 158, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1700, 1534, 'Vergas__', 411, 1000000, 0, 0, 'None', 7, 251, 1920.61, -1626.39, 13.243, 175.981, 1, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1701, 1211, 'SRAH_N3AM', 411, 1000000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1702, 1211, 'SRAH_N3AM', 541, 900000, 0, 1, 'None', 10, 1000, 744.946, -1276.31, 13.18, 3.558, 1, 5, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1703, 1211, 'SRAH_N3AM', 500, 450000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(1704, 1211, 'SRAH_N3AM', 579, 310000, 0, 0, 'None', 100, 994.62, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1705, 1211, 'SRAH_N3AM', 482, 450000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1706, 1192, 'I_NAMOSE', 545, 350000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1707, 1192, 'I_NAMOSE', 579, 310000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1708, 1192, 'I_NAMOSE', 579, 310000, 0, 0, 'None', 100, 756, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1709, 1192, 'I_NAMOSE', 579, 310000, 0, 0, 'None', 18, 904.613, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1710, 1719, 'Zizwar_Johnson', 560, 550000, 0, 1, 'None', 2, 741.193, 1955.28, -1767.73, 13.21, 181.317, 0, 0, 1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1029, 1081, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1711, 1211, 'SRAH_N3AM', 541, 900000, 0, 1, 'None', 98, 788.787, 740.574, -1276.43, 13.18, 0.721, 2, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1712, 1211, 'SRAH_N3AM', 468, 100000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1713, 1211, 'SRAH_N3AM', 463, 90000, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1715, 1719, 'Zizwar_Johnson', 522, 1000000, 0, 0, 'None', 20, 959.166, 1280.11, -1445.34, 14.497, 273.847, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1716, 1719, 'Zizwar_Johnson', 541, 900000, 0, 1, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1717, 2385, 'Falcon_Millions', 560, 550000, 0, 1, 'None', 100, 1000, 2491.65, -1674.5, 13.049, 188.634, 0, 0, 1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1078, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 25, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1718, 1887, 'FATAL_MIAL', 468, 100000, 0, 1, 'None', 20, 347.674, 689.353, -1570.3, 13.91, 356.174, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1719, 653, 'Mada_Xvilo', 600, 270000, 0, 0, 'None', 100, 1000, 1212.39, -1420.13, 13.065, 1.392, 0, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1082, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1720, 1765, 'Youssef_Lhaj', 555, 450000, 0, 1, 'None', 19, 751.012, 562.397, -1283.85, 17.0007, 0, 3, 3, -1, NULL, 0, 0, 18647, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1722, 2641, 'MOUAD_MESSI', 541, 900000, 0, 1, 'None', 99, 745.928, 2122.52, -1783.69, 13.013, 0.136, 6, 0, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1724, 597, 'MOULL_SLAWI', 555, 450000, 0, 1, 'None', 8, 934.99, 1881.74, -1740.77, 13.167, 180.826, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1725, 1847, 'zakaria__Xp', 560, 550000, 0, 1, 'None', 0, 251, 1271.74, -1277.57, 13.028, 164.772, 0, 0, 1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 1028, 1081, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1726, 1895, 'SO_LO', 581, 50000, 0, 1, 'None', 100, 989.625, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1727, 535, 'Ilyas_Newton', 522, 1000000, 0, 1, 'None', 98, 1000, 273.096, -1587.14, 32.784, 253.951, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1729, 0, 'Nobody', 525, 0, 0, 0, 'None', 100, 1000, 2017.65, -1765.56, 13.925, 357.685, -1, -1, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 7, -1, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1730, 1589, 'Lil_Tetsuya', 559, 0, 0, 1, 'None', 95, 969.118, 1085.99, -1341.38, 13.476, 270.783, 175, 175, 0, NULL, 0, 0, 18650, 1, 0, 1158, 0, 1068, 1071, 0, 1010, 0, 1080, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1731, 949, 'CASTRELO_MF', 500, 450000, 0, 0, 'None', 75, 853.297, 1963.78, -1785.87, 13.487, 179.703, 1, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1732, 1804, 'CaTaNa_Ta', 500, 450000, 0, 0, 'None', 17, 939.996, 1669.26, -2344.56, 1535.59, 270.673, 0, 0, -1, NULL, 3, 2000012, 18647, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1733, 949, 'CASTRELO_MF', 560, 550000, 0, 0, 'None', 34, 316.929, 1985.98, -1759.7, 13.259, 252.035, 0, 0, 3, NULL, 0, 0, 18650, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 0, 1081, 0, 1087, 1169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1734, 2029, 'Pablo_Vr', 587, 700000, 0, 1, 'None', 100, 837.565, 1530.44, -808.107, 71.983, 271.821, 0, 0, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1735, 2118, 'Edgar_Carlos', 587, 700000, 0, 1, 'MARWA', 100, 620, 1235.48, -1370.2, 12.908, 178.136, 166, 166, -1, NULL, 0, 0, 18647, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1736, 2118, 'Edgar_Carlos', 541, 900000, 0, 1, 'None', 98, 903.992, 1235.28, -1349.11, 12.792, 0.571, 86, 1, -1, NULL, 0, 0, 18647, 0, 2, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1737, 1448, 'antnony_1313', 411, 1000000, 0, 0, 'None', 76, 52783.8, 1219.41, -1318.69, 12.896, 270.295, 1, 1, -1, NULL, 0, 0, 18650, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1738, 1887, 'FATAL_MIAL', 481, 2500, 0, 0, 'None', 20, 1000, 1671.46, -2339.99, 1534.99, 272.225, 0, 0, -1, NULL, 3, 2000054, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1739, 1900, 'Talb_M3acho', 560, 550000, 0, 1, 'None', 97, 1000, 1562.19, -1037.34, 23.875, 242.129, 6, 6, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1740, 1764, 'anas_psico', 411, 1000000, 0, 1, 'None', 100, 882.553, 831.315, -888.458, 68.459, 118.593, 1, 1, 0, NULL, 0, 0, 18648, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1741, 1696, 'STIVEN__X', 509, 2500, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1742, 1603, 'haitam_10169', 411, 1000000, 0, 0, 'None', 100, 251, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1743, 1603, 'haitam_10169', 541, 900000, 0, 0, 'None', 100, 251, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1744, 1592, 'TOXIC_UH', 560, 550000, 0, 1, 'None', 100, 922.222, 2340.48, -2325.56, 13.039, 313.102, 3, 3, 1, NULL, 0, 0, 18647, 0, 0, 1138, 0, 1033, 1030, 0, 1010, 1029, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1745, 1601, 'Ryad_Eltchapo', 541, 900000, 0, 0, 'None', 98, 944.74, 1671.11, -2347.53, 1535.07, 94.851, 3, 0, -1, NULL, 3, 2000065, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1746, 1709, 'SUPRA_MK4', 541, 900000, 0, 0, 'None', 89, 1000, 1777.35, -1887.46, 13.01, 268.478, 1, 187, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1747, 1601, 'Ryad_Eltchapo', 603, 850000, 0, 0, 'None', 18, 958.135, 1671.09, -2345.14, 1535.32, 93.994, 0, 228, -1, NULL, 3, 2000065, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1748, 1024, 'X7___RAJAWI___GB', 560, 550000, 0, 0, 'None', 100, 1000, 1097.8, -1387.93, 13.358, 179.14, 6, 6, -1, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1749, 1852, '_KING_V2', 522, 1000000, 0, 1, 'None', 97, 940.344, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1751, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2205.39, -1157.03, 25.407, 265.874, 190, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1752, 0, 'Nobody', 468, 0, 0, 1, 'None', 100, 1000, 2205.56, -1161.28, 25.16, 273.583, 190, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1753, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2228.84, -1177.07, 25.432, 90.243, 190, 190, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1754, 894, 'TALIANI_WOLF', 541, 900000, 0, 0, 'None', 91, 905.713, 1948.33, -1803.71, 13.172, 265.748, 1, 2, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1755, 894, 'TALIANI_WOLF', 560, 550000, 0, 0, 'None', 82, 751.522, 1941.78, -1803.21, 13.252, 265.894, 241, 1, 1, NULL, 0, 0, 18648, 1, 0, 1138, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1756, 894, 'TALIANI_WOLF', 560, 550000, 0, 0, 'None', 4, 991.64, 1941.63, -1806.86, 13.207, 265.247, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 1138, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1757, 1449, 'ZODYEK_FIRYANDIZ', 560, 550000, 0, 0, 'None', 37, 802.184, 1219.47, -1345.05, 12.875, 261.525, 0, 0, 2, NULL, 0, 0, 18647, 1, 0, 1139, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1758, 894, 'TALIANI_WOLF', 402, 850000, 0, 0, 'None', 17, 1000, 1941.51, -1810.78, 13.378, 274.059, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1759, 894, 'TALIANI_WOLF', 587, 700000, 0, 0, 'None', 96, 847.881, 1941.75, -1815.6, 13.274, 271.214, 5, 5, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1760, 894, 'TALIANI_WOLF', 602, 650000, 0, 0, 'None', 100, 1000, 1940.96, -1819.01, 13.353, 269.891, 1, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1761, 1580, 'Mehdi_Fransesco', 603, 850000, 0, 0, 'None', 92, 631.396, 2469.45, -1726.56, 13.338, 256.625, 6, 6, -1, NULL, 0, 0, 18648, 1, 0, 1023, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1762, 894, 'TALIANI_WOLF', 579, 310000, 0, 0, 'None', 100, 980.885, 1935.07, -1807.27, 13.439, 275.7, 200, 1, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1098, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1763, 1627, 'Raymond_Eltchapo', 560, 550000, 0, 1, 'None', 19, 345.472, 1517.91, -1460.97, 9.205, 8.552, 0, 0, 1, NULL, 0, 0, 18647, 1, 0, 1138, 0, 1033, 1027, 0, 1010, 1028, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1764, 0, 'Nobody', 506, 0, 0, 0, 'None', 100, 1000, 2820.9, -1089.79, 30.425, 87.709, 223, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1765, 0, 'Nobody', 506, 0, 0, 0, 'None', 100, 1000, 2821.08, -1085.73, 30.372, 96.511, 223, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1766, 597, 'MOULL_SLAWI', 424, 550000, 0, 0, 'None', 100, 951.868, 1889.22, -1738.9, 13.186, 182.018, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1768, 1810, 'Zhani_Johnson', 411, 1000000, 0, 1, 'None', 19, 705.654, 1994.12, -1778.1, 14.217, 0.961, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1769, 1810, 'Zhani_Johnson', 522, 1000000, 0, 0, 'None', 99, 935.923, 1106.07, -1440.9, 15.367, 85.651, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1770, 2606, 'said_may78', 541, 900000, 0, 0, 'None', 49, 908.812, 1086.28, -1359.28, 13.482, 269.527, 126, 0, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1771, 1730, 'LF9IH__ADAM', 541, 900000, 0, 1, 'None', 0, 1000, 1535.33, -1677.21, 12.968, 190.233, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1772, 2375, 'NINJA_NETWORK', 541, 900000, 0, 1, 'None', 62, 716.327, 1671.58, -2340.48, 1535.11, 90.13, 125, 125, -1, NULL, 3, 2000072, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 24, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1773, 1279, '__JO9LI_UX__', 580, 300000, 0, 1, 'None', 64, 721.289, 557.867, -1283.98, 17.0007, 0, 2, 2, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1774, 1448, 'antnony_1313', 560, 550000, 0, 0, 'None', 81, 1000, 1241.24, -1361.07, 12.869, 89.822, 1, 2, 3, NULL, 0, 0, 18648, 1, 0, 1139, 0, 1033, 1030, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1775, 828, 'mezo_loco', 560, 550000, 0, 0, 'mezo', 18, 707, 286.085, -1313.38, 53.586, 7.162, 155, 155, 3, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 1030, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1776, 0, 'Nobody', 535, 0, 0, 0, 'None', 100, 1000, 2217.23, -1170.64, 25.491, 268.147, 190, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1777, 0, 'Nobody', 535, 0, 0, 0, 'None', 100, 1000, 2217.12, -1161.87, 25.492, 270.412, 190, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1778, 2690, 'PEDRO_VGS', 411, 1000000, 0, 1, 'None', 90, 689.579, 2822.26, -1562.49, 10.649, 89.179, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1779, 1887, 'FATAL_MIAL', 560, 550000, 0, 0, 'None', 100, 458.34, 1662.72, -2345.27, 1535.15, 269.265, 0, 0, 1, NULL, 3, 2000054, 18649, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 1028, 1081, 0, 1087, 1169, 1141, 0, 0, 100000, 0, 0, 10, 0, 0, 31, 0, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1780, 1279, '__JO9LI_UX__', 579, 310000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1781, 1828, 'MOL_TAJIN', 560, 550000, 0, 1, 'None', 100, 403.119, 1800.82, -1133.95, 23.792, 266.547, 6, 6, 0, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 1030, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1782, 597, 'MOULL_SLAWI', 545, 350000, 0, 1, 'None', 100, 813.601, 1883.81, -1743.73, 13.358, 181.81, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1783, 597, 'MOULL_SLAWI', 545, 350000, 0, 0, 'None', 100, 1000, 1903.64, -1739.26, 13.231, 183.668, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1784, 1852, '_KING_V2', 560, 550000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1785, 1973, 'PECASO_XM8', 603, 850000, 0, 0, 'None', 100, 988.352, 2104.16, -1770.61, 13.233, 112.529, 9, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 1024, 1010, 0, 1076, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1786, 1471, 'IRT_WLD_ALI', 487, 15550000, 0, 1, 'None', 99, 744.504, 1351.9, -653.743, 114.208, 301.539, 2, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1787, 1157, 'ISCOBAR_WOLF', 560, 550000, 0, 0, 'None', 20, 848.745, 2497.95, -1655.51, 13.086, 258.737, 0, 0, 0, NULL, 0, 0, 18649, 1, 0, 1139, 0, 1032, 1027, 0, 1010, 1028, 1079, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1788, 1074, 'PABLO_WOLF', 560, 550000, 0, 0, 'None', 66, 1000, 1935.65, -1801.86, 13.21, 268.42, 0, 0, 1, NULL, 0, 0, 18649, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1096, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1789, 1074, 'PABLO_WOLF', 560, 550000, 0, 0, 'None', 89, 484.198, 1935.38, -1806.66, 13.214, 268.974, 0, 0, 2, NULL, 0, 0, 18647, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1790, 1074, 'PABLO_WOLF', 560, 550000, 0, 0, 'None', 95, 979.117, 1934.82, -1810.89, 13.21, 266.72, 200, 200, -1, NULL, 0, 0, 18647, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1029, 1085, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1791, 1074, 'PABLO_WOLF', 541, 900000, 0, 1, 'None', 73, 596.684, 1943.8, -1820.31, 13.125, 264.43, 0, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1792, 1074, 'PABLO_WOLF', 424, 550000, 0, 0, 'None', 99, 976.822, 1934.95, -1815.63, 13.266, 264.949, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1793, 1946, 'Mimo200p_9', 581, 50000, 0, 0, 'None', 98, 1000, 1242.63, -1320.49, 12.764, 88.361, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1794, 894, 'TALIANI_WOLF', 560, 550000, 0, 0, 'None', 20, 1000, 1935.31, -1811.58, 13.21, 272.957, 7, 7, 1, NULL, 0, 0, 18648, 1, 0, 1139, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1795, 894, 'TALIANI_WOLF', 560, 550000, 0, 0, 'None', 19, 651.415, 1935.33, -1814.99, 13.209, 268.266, 1, 1, 3, NULL, 0, 0, 0, 0, 0, 1138, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1796, 1913, 'hmd_kator', 402, 850000, 0, 0, 'None', 19, 865.977, 1227.34, -1368.26, 13.002, 353.219, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1797, 894, 'TALIANI_WOLF', 500, 450000, 0, 1, 'None', 50, 982.149, 1536.95, -1674.18, 13.542, 184.257, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1798, 2968, 'ilyass_xx', 463, 90000, 0, 0, 'None', 100, 829, 257.118, -1353.8, 52.649, 182.453, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1799, 1709, 'SUPRA_MK4', 461, 100000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1800, 597, 'MOULL_SLAWI', 602, 650000, 0, 0, 'None', 98, 881.815, 1927.22, -1721.7, 13.356, 90.791, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1801, 1519, 'Boonina_', 522, 1000000, 0, 1, 'None', 98, 815.293, 309.981, -1166.3, 80.452, 128.113, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1802, 513, 'YASSINE_CASSTILANO', 471, 70000, 0, 1, 'None', 87, 251, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1803, 1634, 'LHAJ_FRCHITA', 579, 310000, 0, 0, 'None', 100, 974.163, 1896.34, -2336.84, 13.487, 259.219, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1804, 1900, 'Talb_M3acho', 411, 1000000, 0, 1, 'None', 20, 1000, 1219.38, -1366.41, 12.866, 270.925, 1, 1, 0, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1805, 1519, 'Boonina_Millions', 559, 0, 0, 1, 'None', 100, 799, 284.143, -1169.34, 80.513, 311.642, 3, 3, 2, NULL, 0, 0, 18648, 1, 3, 1158, 0, 1067, 0, 0, 1010, 0, 1081, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 31, 24, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1806, 663, 'WLD_NAMOSE', 559, 0, 0, 0, 'None', 84, 904.19, 1219.31, -1473.45, 13.168, 176.667, 1, 1, 2, NULL, 0, 0, 18650, 1, 0, 1158, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1807, 1471, 'IRT_WLD_ALI', 495, 0, 0, 1, 'None', 88, 713.186, 1332.75, -616.321, 109.278, 198.444, 1, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1808, 1471, 'IRT_WLD_ALI', 495, 0, 0, 1, 'None', 98, 990.524, 1326.91, -618.077, 109.352, 198.309, 2, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1809, 1192, 'I_NAMOSE', 562, 0, 0, 1, 'None', 100, 945.4, 267.671, -1359.27, 52.878, 27.323, 3, 3, 2, NULL, 0, 0, 18652, 1, 3, 1146, 0, 1038, 1040, 0, 1010, 0, 1081, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1810, 3545, 'WLD_ZA3IMA', 562, 0, 0, 1, 'None', 100, 992, 1480.56, -1758.48, 17.159, 215.814, 1, 1, 0, NULL, 0, 0, 18648, 1, 0, 1147, 0, 1038, 1041, 0, 1010, 1034, 1079, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1811, 1192, 'I_NAMOSE', 503, 0, 0, 1, 'None', 96, 251, 248.142, -1356.22, 52.959, 305.365, 241, 241, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1812, 1308, 'Musashi_Lucas', 503, 0, 0, 0, 'None', 100, 564.81, 127.595, -1590.89, 10.481, 216.183, 0, 0, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1813, 2789, 'SI_ALI', 504, 0, 0, 0, 'None', 95, 696.223, 1648.19, -1106.16, 23.698, 272.379, 2, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1814, 1519, 'Boonina_Millions', 504, 0, 0, 1, 'None', 100, 956.575, 305.546, -1160.3, 80.657, 135.065, 0, 0, 1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 24, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1815, 1029, 'UTCHIHA_MADARA', 541, 900000, 0, 1, 'None', 12, 1000, 1019.8, -1433.81, 13.172, 177.248, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1816, 1696, 'STIVEN__X', 468, 100000, 0, 0, 'None', 81, 381.306, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1817, 1279, '__JO9LI_UX__', 487, 15550000, 0, 1, 'None', 5, 629.837, 1243.37, -1364.73, 13.342, 3.173, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1818, 1979, 'Mar_Sis', 581, 50000, 0, 1, 'None', 100, 378, 540.988, -1288.61, 16.821, 171.963, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1819, 1501, 'LUFFY_XVILO', 560, 550000, 0, 1, 'None', 99, 980.715, 1148.02, -1413.26, 13.329, 349.928, 3, 3, 3, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1033, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1820, 1662, 'ALMODAMER____98', 411, 1000000, 0, 1, 'None', 100, 342.276, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1821, 1519, '1922_', 602, 650000, 0, 1, 'None', 100, 980, 1671.23, -2339.01, 1535.26, 90.051, 0, 0, -1, NULL, 3, 2000055, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1822, 1972, 'PITER_GM', 559, 0, 0, 0, 'None', 91, 676.076, 1670.63, -2253.82, 13.375, 79.711, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1823, 663, 'WLD_NAMOSE', 586, 50000, 0, 0, 'None', 99, 973, 694.881, -1171.09, 14.943, 322.69, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1824, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 159.33, -1867.06, 3.49, 268.369, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1825, 663, 'WLD_NAMOSE', 560, 550000, 0, 1, 'None', 77, 746.777, 1225.59, -1473.62, 13.252, 175.583, 158, 158, 3, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1032, 1030, 0, 1010, 1029, 1079, 0, 0, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1826, 1953, 'oussama__lfrda', 522, 1000000, 0, 1, 'None', 86, 775, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1827, 1953, 'oussama__lfrda', 463, 90000, 0, 1, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1828, 1211, 'SRAH_N3AM', 545, 350000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1829, 1192, 'I_NAMOSE', 545, 350000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 2, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1830, 1211, 'SRAH_N3AM', 545, 350000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1831, 949, 'CASTRELO_MF', 402, 850000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1832, 877, 'L7AJ_ZIAD', 536, 350000, 0, 1, 'None', 93, 251, 1036.3, -630.532, 119.793, 275.214, 2, 3, 2, NULL, 0, 0, 0, 0, 3, 0, 0, 1128, 0, 0, 1010, 1104, 1079, 0, 1087, 1181, 1183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1833, 1534, 'Vergas__', 536, 350000, 0, 1, 'None', 99, 1000, 1912.81, -1667.85, 13.058, 281.448, 0, 0, 2, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1834, 407, 'oussama_r', 536, 350000, 0, 1, 'None', 100, 1000, 2600.69, -952.804, 80.685, 109.576, 3, 3, 1, NULL, 0, 0, 0, 0, 3, 0, 0, 1103, 0, 0, 1010, 1104, 1078, 0, 1087, 1182, 1184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1835, 862, 'ZOU_HIR', 522, 1000000, 0, 1, 'None', 100, 994.451, 1095.94, -1387.21, 13.277, 86.457, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1836, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2765.51, -1930.73, 13.006, 358.94, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1837, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2773.62, -1948.11, 12.969, 47.347, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1838, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2773.76, -1947.33, 12.966, 45.786, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1839, 0, 'Nobody', 506, 0, 0, 0, 'None', 100, 1000, 1506.32, -2270.96, 13.251, 293.062, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1840, 0, 'Nobody', 506, 0, 0, 1, 'None', 100, 1000, 2505.49, -1694.71, 13.256, 178.935, 44, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1841, 3517, 'SI_DAFIR', 545, 350000, 0, 0, 'None', 100, 669.905, 1256.33, -1426.46, 13.308, 86.746, 1, 1, 0, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1842, 1864, 'BIG__SMOKE_', 522, 1000000, 0, 1, 'None', 100, 732.752, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1843, 1950, 'walid_gim', 500, 450000, 0, 0, 'None', 100, 980.249, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1844, 2606, 'said_may78', 522, 1000000, 0, 1, 'None', 86, 819, 1211.23, -1424.71, 12.955, 0.532, 128, 128, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1845, 877, 'L7AJ_ZIAD', 550, 300000, 0, 1, 'None', 95, 1000, 1031.83, -636.755, 119.952, 276.214, 7, 7, 0, NULL, 0, 0, 18652, 1, 0, 1003, 1005, 1006, 0, 0, 1010, 1020, 1074, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1846, 2001, 'simo__rdr', 579, 310000, 0, 1, 'None', 100, 549.306, 1251.15, -1260.69, 13.169, 87.75, 1, 1, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1847, 3300, 'M9YD__TANJIRO', 560, 550000, 0, 1, 'None', 96, 734.147, 1220.41, -1426.18, 13.012, 357.741, 0, 1, 2, NULL, 0, 0, 18650, 0, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1078, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1848, 2867, 'SALMA_', 560, 550000, 0, 0, 'None', 82, 448.572, 1102.63, -1313.39, 13.489, 180.643, 126, 126, 3, NULL, 0, 0, 18651, 1, 0, 1139, 0, 1032, 1030, 0, 1010, 1029, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1849, 1662, 'ALMODAMER____98', 541, 900000, 0, 1, 'None', 18, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1850, 2024, 'ilyass_lk', 560, 550000, 0, 0, 'None', 12, 1000, 2796.34, -1576.2, 10.598, 269.275, 6, 6, 2, NULL, 0, 0, 18647, 1, 0, 1139, 0, 1033, 1030, 0, 1010, 1028, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1851, 1829, 'https_tweets', 560, 550000, 1000, 1, 'None', 24, 356.009, 1228.57, -1355.6, 12.872, 29.223, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 1029, 1096, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1852, 1953, 'oussama__lfrda', 402, 850000, 0, 0, 'None', 100, 992.831, 1237.75, -1376.95, 12.938, 27.679, 0, 1, 0, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1853, 2022, 'SI_MOR', 581, 50000, 0, 0, 'None', 18, 712.733, 2164.91, -1810.29, 12.971, 101.294, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1854, 0, 'Nobody', 417, 0, 0, 0, 'None', 100, 1000, 647.517, -2334.95, 5.816, 346.757, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1855, 1519, 'SOOOOOOOONIIIIICE_', 489, 400000, 0, 1, 'None', 97, 1000, 278.907, -1162.72, 80.985, 312.023, 0, 0, 2, NULL, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 24, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1856, 1696, 'STIVEN__X', 560, 550000, 0, 0, 'None', 4, 510.435, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1857, 1580, 'Mehdi_Fransesco', 468, 100000, 0, 0, 'None', 0, 695.033, 1218.98, -1363.93, 12.835, 86.07, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1858, 1852, '_KING_V2', 603, 850000, 0, 0, 'None', 16, 677, 2008.66, -1767.3, 13.885, 265.824, 155, 155, -1, NULL, 0, 0, 18648, 1, 0, 1023, 0, 1006, 1017, 0, 1010, 1018, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1859, 1580, 'Mehdi_Fransesco', 579, 310000, 0, 0, 'None', 98, 895.645, 1836.99, -1547.16, 13.392, 339.614, 3, 3, 1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1860, 1804, 'CaTaNa_Ta', 581, 50000, 0, 1, 'None', 81, 949.548, 1669, -1882.39, 13.143, 91.504, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1861, 1988, '@islam_07...', 400, 320000, 0, 1, 'None', 91, 689.728, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1862, 1988, '@islam_07...', 533, 400000, 0, 0, 'None', 8, 627.903, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1863, 1988, '@islam_07...', 411, 1000000, 0, 1, 'None', 19, 586.5, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1864, 2001, 'simo__rdr', 560, 550000, 0, 1, 'None', 100, 675.911, 1257.39, -1261.68, 12.951, 89.486, 0, 0, 0, NULL, 0, 0, 18647, 1, 0, 1139, 0, 1032, 1027, 0, 1010, 1029, 1083, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1865, 1519, 'Boonina_Millions', 452, 0, 0, 1, 'None', 97, 705, 798.425, -1895.8, -0.634, 263.275, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1866, 2033, 'MAHLOUI_MH', 462, 25000, 0, 1, 'None', 95, 985, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1867, 633, 'Za3ima_Aya', 536, 350000, 0, 1, 'None', 96, 691.616, 1098.06, -1376.45, 13.539, 180.929, 6, 6, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1098, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1868, 1962, 'fouade_2023', 522, 1000000, 0, 0, 'None', 100, 300, 1235.49, -1370.31, 12.752, 81.497, 0, 0, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1869, 620, 'Lorenzo_Mp3', 463, 90000, 0, 0, 'None', 59, 1000, 310.192, -1807.95, 4.004, 178.616, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1870, 2101, 'medic_shurox', 560, 550000, 0, 1, 'None', 82, 1000, 1727.19, -1815.59, 13.064, 78.735, 175, 175, -1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1871, 2037, 'on_ziko', 581, 50000, 0, 0, 'None', 12, 957, 551.16, -1284.44, 16.809, 177.3, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1872, 2001, 'simo__rdr', 500, 450000, 0, 1, 'None', 100, 810, 1258.04, -1265.13, 13.416, 91.01, 1, 1, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1873, 1584, 'Morgane_L3ZWA', 411, 1000000, 0, 1, 'None', 90, 774.778, 1467.64, -1626.72, 13.774, 152.579, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1874, 1587, 'ALI_WINs', 560, 550000, 0, 0, 'None', 100, 34428.8, 1980.57, -1735.18, 15.874, 182.48, 6, 6, 1, NULL, 0, 0, 18648, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1029, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1875, 2033, 'MAHLOUI_MH', 496, 250000, 0, 0, 'None', 20, 795.929, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1876, 2789, 'SI_ALI', 522, 1000000, 0, 0, 'None', 86, 777.898, 1675.77, -1121.02, 23.469, 269.116, 126, 126, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1877, 1176, 'brazeli_mezox', 522, 1000000, 1500, 0, 'None', 20, 983, 2477.29, -1947.38, 13.482, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1878, 2299, '[BRZ]LUFFY_L7GAR', 542, 300000, 0, 0, 'None', 100, 505.95, 1218, -1425.69, 13.07, 357.547, 0, 3, 0, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1879, 1804, 'CaTaNa_Ta', 404, 250000, 0, 0, 'None', 100, 1000, 1643.23, -1903.05, 13.234, 2.688, 0, 0, 0, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1885, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1267.93, -1302.24, 13.089, 72.418, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1886, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1267.94, -1302.95, 13.075, 73.21, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1887, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1267.92, -1303.69, 13.078, 73.639, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1894, 1589, 'TiTaN_Hermano', 576, 330000, 0, 0, 'None', 96, 998.775, 837.056, -850.009, 69.431, 198.797, 0, 0, 2, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1895, 1592, 'TOXIC_UH', 482, 450000, 0, 0, 'None', 90, 980.976, 2458.42, -2239.16, 13.619, 258.74, 0, 0, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1896, 1519, 'SOOOOOOOONIIIIICE_', 500, 450000, 0, 1, 'None', 100, 767.461, 284.362, -1157.1, 81.021, 222.297, 0, 0, 1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1897, 1589, 'TiTaN_Hermano', 411, 1000000, 0, 0, 'None', 93, 824.961, 827.847, -866.453, 69.147, 290.29, 3, 3, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1898, 421, 'SENIOR___CASPER', 487, 0, 0, 0, 'None', 20, 470.788, 1892.06, -2328.04, 13.547, 53.463, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1899, 0, 'Nobody', 487, 0, 0, 0, 'None', 100, 1000, 2781.28, -2016.01, 13.731, 284.603, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1410065408, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1900, 0, 'Nobody', 481, 0, 0, 1, 'None', 100, 1000, 2773.67, -1965.04, 12.832, 66.888, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1901, 0, 'Nobody', 481, 0, 0, 0, 'None', 100, 1000, 2773.62, -1964.2, 12.829, 69.81, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1902, 0, 'Nobody', 481, 0, 0, 0, 'None', 100, 1000, 2773.64, -1963.42, 12.822, 66.581, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1903, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2765.71, -1941.97, 13.011, 359.678, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1904, 894, 'TALIANI_WOLF', 603, 850000, 0, 0, 'None', 98, 991.384, 1934.73, -1803.32, 13.356, 272.713, 6, 6, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1025, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1905, 2056, 'vip_piro1', 411, 1000000, 5000, 0, 'None', 80, 859.604, 2468.38, -2076.98, 13.274, 358.748, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1906, 1975, 'saad_az19', 500, 450000, 0, 1, 'None', 100, 997.758, 1128.38, -1405.81, 13.5, 354.118, 128, 128, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1907, 2979, 'Zakaria_ol', 579, 310000, 0, 1, 'None', 95, 855.115, 1348.28, -1750.3, 13.321, 164.404, 3, 3, -1, NULL, 0, 0, 18647, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1908, 2062, 'SI_MOB', 586, 50000, 0, 0, 'None', 89, 777.155, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1910, 663, 'WLD_NAMOSE', 536, 350000, 0, 1, 'None', 98, 837.434, 2160.94, -1182.54, 23.485, 89.612, 0, 0, 2, NULL, 0, 0, 0, 0, 3, 0, 0, 1128, 0, 0, 1010, 1104, 1079, 0, 1087, 1181, 1183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1911, 1301, 'JEFFRY_VEGAS', 509, 2500, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1912, 1968, 'aziz_11', 461, 100000, 0, 0, 'None', 20, 866.292, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(1913, 2037, 'on_ziko', 545, 350000, 1000, 0, 'None', 0, 570.455, 2491.83, -1633.49, 13.262, 179.593, 3, 3, 1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1914, 2169, 'ANASS_OMEGA5', 560, 550000, 0, 1, 'None', 100, 618.522, 2796.32, -1575.89, 10.598, 268.999, 241, 2, -1, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1078, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1915, 2214, '[GLD]PABLO_7AGAR', 560, 550000, 0, 0, 'confirm', 79, 1000, 1229.38, -1331.54, 12.874, 174.151, 3, 1, 2, NULL, 0, 0, 18649, 1, 3, 1138, 0, 1032, 0, 0, 1009, 0, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1917, 2615, 'BO_MM', 560, 550000, 0, 1, 'None', 89, 950.655, 751.42, -1225.21, 13.252, 358.757, 128, 1, -1, NULL, 0, 0, 18649, 1, 3, 1138, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1918, 2085, 'motez_sellami2', 533, 400000, 0, 1, 'None', 100, 924, 1294.51, -1286.26, 13.17, 96.097, 0, 3, 0, NULL, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1919, 2075, 'LFERDA_GNAR', 581, 50000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1920, 2401, 'LOMS_XVILO', 560, 550000, 0, 0, 'None', 20, 667.868, 1585.01, -1605.36, 13.039, 1.352, 6, 6, 0, NULL, 0, 0, 18650, 1, 0, 1139, 0, 1033, 1030, 0, 1010, 1029, 1097, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(1921, 1471, 'IRT_WLD_ALI', 560, 550000, 0, 1, 'None', 92, 605.602, 1310.64, -639.609, 108.329, 200.126, 71, 71, 1, NULL, 0, 0, 18647, 1, 1, 1138, 0, 1033, 1030, 0, 1010, 1029, 1081, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1922, 1211, 'SRAH_N3AM', 496, 250000, 0, 1, 'None', 96, 947.71, 1242.9, -1381.68, 12.892, 88.724, 2, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1923, 1211, 'SRAH_N3AM', 496, 250000, 0, 0, 'None', 20, 1000, 1242.69, -1375.27, 12.886, 91.788, 6, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1924, 1211, 'SRAH_N3AM', 496, 250000, 0, 1, 'None', 18, 942.994, 1994.17, -1766.01, 13.762, 178.719, 1, 2, 0, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1925, 1211, 'SRAH_N3AM', 411, 1000000, 0, 0, 'None', 100, 992.576, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1926, 1211, 'SRAH_N3AM', 411, 1000000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1927, 1211, 'SRAH_N3AM', 411, 1000000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1928, 1887, 'FATAL_MIAL', 482, 450000, 0, 1, 'None', 91, 928.713, 2070.35, -2206.49, 13.583, 181.609, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 100000, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1929, 1211, 'SRAH_N3AM', 602, 650000, 0, 0, 'None', 96, 516.137, 745.038, -1263.35, 13.36, 2.453, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1930, 1211, 'SRAH_N3AM', 602, 650000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1931, 1211, 'SRAH_N3AM', 541, 900000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1932, 1534, 'Vergas__', 411, 1000000, 0, 1, 'None', 5, 971.126, 1923.04, -1626.87, 13.243, 173.149, 6, 6, 1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1933, 1973, 'PECASO_XM8', 411, 1000000, 0, 1, 'None', 93, 795.488, 1670.74, -2340.18, 1535.18, 274.102, 102, 28, -1, NULL, 3, 2000052, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1934, 3429, 'ayman_rofixx', 579, 310000, 0, 0, 'None', 0, 1000, 1249.67, -1425.76, 13.37, 357.085, 6, 6, -1, NULL, 0, 0, 18650, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1935, 1374, 'hamza_nadili', 400, 320000, 0, 0, 'None', 99, 657.292, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1936, 3029, 'WLD_LHAJ_1', 411, 1000000, 0, 1, 'None', 100, 300, 29.062, -1527.42, 4.787, 82.204, 2, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1937, 646, '_BRITILLE_', 603, 850000, 0, 1, 'None', 100, 728.804, 1398.19, -2483.82, 13.364, 268.752, 11, 1, -1, NULL, 0, 0, 18648, 1, 3, 1023, 0, 0, 0, 0, 1010, 0, 1096, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1938, 646, '_BRITILLE_', 541, 900000, 0, 1, 'None', 10, 1000, 1398.17, -2491.82, 13.141, 267.74, 101, 101, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1082, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1939, 646, '_BRITILLE_', 602, 650000, 0, 0, 'None', 100, 674.378, 1398.51, -2495.27, 13.322, 268.505, 57, 57, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1082, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1940, 646, '_BRITILLE_', 402, 850000, 0, 1, 'None', 20, 1000, 1398.6, -2476.86, 13.345, 269.51, 6, 6, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1097, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 40, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1941, 646, '_BRITILLE_', 587, 700000, 0, 1, 'None', 98, 647.036, 1398.55, -2480.36, 13.247, 270.769, 10, 10, 1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1942, 868, 'YASSIN_RESTOVA', 560, 550000, 0, 1, 'None', 100, 987, 1630.63, -1094.71, 23.527, 266.766, 0, 0, 2, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1943, 2492, '_BRAZELI_BRZ_', 560, 550000, 0, 0, 'None', 96, 1000, 2276.59, -1107.69, 37.632, 153.781, 6, 6, 3, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 1030, 0, 1010, 1029, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1944, 2095, 'RP_TANJAW9I', 482, 450000, 0, 0, 'None', 100, 727.023, 1816.4, -1557.44, 13.54, 347.32, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1946, 1829, 'https_tweets', 500, 450000, 0, 0, 'None', 2, 997.791, 2484.39, -1653.79, 13.454, 90.418, 126, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1947, 1519, 'Boonina_Millions', 554, 400000, 0, 1, 'None', 100, 683.4, 315.505, -1169.16, 80.966, 98.958, 0, 0, 2, NULL, 0, 0, 18652, 1, 2, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1948, 1519, 'SOOOOOOOONIIIIICE_', 479, 280000, 0, 1, 'None', 98, 946.669, 1670.8, -2354.99, 1535.24, 89.066, 0, 0, 0, NULL, 3, 2000055, 18651, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1949, 1471, 'IRT_WLD_ALI', 411, 1000000, 0, 1, 'None', 100, 790.926, 1620.31, -1103.08, 23.633, 266.101, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1950, 1279, '__JO9LI_UX__', 452, 19550000, 0, 0, 'None', 100, 945.115, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1951, 2102, 'BIKER_RUSSI', 560, 550000, 0, 0, 'None', 94, 760.015, 1015.55, -1917.7, 12.112, 5.306, 0, 0, 1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1076, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 28, 28, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1952, 2174, 'Vergas__', 541, 900000, 0, 0, 'None', 96, 928, 1925.72, -1626.35, 13.159, 182.478, 6, 0, 2, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1953, 765, 'MICHOO_L3ANTEEZ', 536, 350000, 0, 1, 'None', 96, 868.689, 2502.87, -1648.62, 13.254, 160.883, 137, 2, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 1128, 0, 0, 1010, 1105, 1085, 0, 1087, 1182, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1954, 1973, 'PECASO_XM8', 541, 900000, 0, 0, 'None', 100, 999.909, 1665.07, -2348.5, 1535.07, 89.504, 0, 0, -1, NULL, 3, 2000052, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1955, 1589, 'TiTaN_Hermano', 487, 15550000, 0, 0, 'None', 0, 1000, 820.146, -857.366, 74.201, 26.749, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1956, 1500, 'ZORO__XVILO', 487, 15550000, 0, 1, 'None', 100, 1000, 1095.92, -1359.16, 23.634, 184.084, 6, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1957, 1463, 'Ninja_l9tal1', 541, 900000, 0, 1, 'None', 99, 1000, 1282.74, -1302.82, 13.088, 85.965, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1958, 2098, 'MAHLOUI_KHN', 560, 550000, 0, 0, 'None', 0, 953.941, 1978.7, -1767.32, 13.751, 339.356, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1959, 2049, 'L3ALAWI_STREX', 521, 120000, 0, 0, 'None', 84, 856.008, 2499.39, -1683.25, 12.948, 273.902, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1960, 877, 'L7AJ_ZIAD', 541, 900000, 0, 1, 'None', 68, 13976.8, 1059.2, -636.455, 119.678, 94.814, 6, 0, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1961, 1534, 'Vergas__', 522, 1000000, 0, 1, 'None', 84, 784.451, 1927.39, -1645.35, 13.119, 87.114, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1962, 975, 'supra_out', 489, 400000, 0, 0, 'None', 100, 553.951, 1242.34, -1340.51, 13.268, 100.319, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1963, 2118, 'Edgar_Carlos', 586, 50000, 0, 1, 'None', 100, 854.33, 60.951, -1280.93, 13.648, 303.023, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1964, 421, 'SENIOR___CASPER', 506, 0, 0, 0, 'None', 20, 1000, 2236.35, -1076.26, 1049.02, 146.274, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1966, 421, 'SENIOR___CASPER', 502, 0, 0, 0, 'None', 18, 845.984, 1190.89, -1330.66, 13.299, 166.621, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1967, 421, 'SENIOR___CASPER', 504, 0, 0, 1, 'None', 18, 708, 1802.15, 1177.67, 6.728, 253.212, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1968, 498, 'mo_rad', 411, 1000000, 0, 0, 'None', 85, 40164.5, 859.601, -1523.86, 13.251, 266.214, 5, 5, 2, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1969, 1589, 'TiTaN_Hermano', 500, 450000, 0, 0, 'None', 92, 1000, 822.829, -868.473, 69.963, 292.853, 1, 0, -1, NULL, 0, 0, 18652, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1970, 2101, 'medic_shurox', 581, 50000, 0, 0, 'None', 79, 823.89, 2228.57, -1152.49, 25.421, 260.545, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1971, 421, 'SENIOR___CASPER', 559, 0, 0, 1, 'None', 100, 937.199, 516.305, -1172.89, 58.4, 113.856, 3, 3, 1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1972, 2122, 'Lferda_Ganar', 581, 50000, 0, 1, 'None', 8, 915.706, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1973, 2000, 'SPOP_SMW', 581, 50000, 0, 0, 'None', 14, 1000, 1223.83, -1413.91, 12.88, 3.541, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1974, 2000, 'SPOP_SMW', 586, 50000, 0, 1, 'None', 14, 1000, 1222.89, -1414.95, 12.841, 355.166, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1975, 1968, 'aziz_11', 579, 310000, 0, 0, 'None', 56, 956.664, 1235.36, -1370.24, 13.143, 357.483, 1, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1976, 2106, 'RIO_RUSSI', 560, 550000, 0, 0, 'None', 96, 985.075, 557.867, -1283.98, 17.0007, 0, 4, 4, 0, NULL, 0, 0, 18651, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1977, 1962, 'fouade_2023', 402, 850000, 500, 1, 'None', 52, 710.236, 1281.84, -1328.01, 13.207, 86.59, 198, 0, -1, NULL, 0, 0, 18648, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1978, 2036, 'King_99', 581, 50000, 0, 1, 'None', 100, 994.75, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1979, 2112, 'SI_BONDGANI', 471, 70000, 0, 1, 'None', 100, 251, 2826.7, -1109.25, 24.087, 150.134, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1980, 1975, 'saad_az19', 418, 450000, 0, 1, 'None', 90, 966.876, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1981, 2375, 'NINJA_NETWORK', 560, 550000, 0, 1, 'None', 50, 931.917, 1109.31, -1413.09, 13.247, 350.495, 240, 240, 0, NULL, 0, 0, 18651, 1, 0, 1139, 0, 1033, 1030, 0, 1010, 0, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1982, 1975, 'saad_az19', 522, 1000000, 0, 1, 'None', 81, 969.405, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1983, 2545, 'SHELBY_TALIANI', 411, 1000000, 0, 1, 'None', 34, 1000, 1002.45, -933.617, 41.868, 279.304, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1984, 1908, 'mastafa_ue_06', 411, 1000000, 0, 0, 'None', 88, 1000, 1548.02, -1670.73, 13.279, 89.091, 154, 154, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1985, 602, 'Paul_Walker', 411, 1000000, 0, 0, 'None', 94, 776.505, 317.743, -1808.82, 4.217, 179.888, 0, 0, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1986, 2133, 'ATAY_65', 411, 1000000, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1987, 2036, 'King_99', 603, 850000, 4500, 1, 'None', 100, 460.154, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1988, 983, 'LODING_LUCIANO', 411, 1000000, 0, 1, 'None', 100, 519, 539.252, -1283.89, 16.729, 174.545, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1989, 2105, 'DARK_RUSSI', 581, 50000, 0, 1, 'None', 100, 494.237, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1990, 1471, 'IRT_WLD_ALI', 559, 0, 0, 1, 'None', 94, 697, 1338.18, -614.477, 108.564, 196.29, 3, 3, 2, NULL, 0, 0, 18649, 1, 3, 1158, 0, 1067, 1071, 0, 1010, 1066, 1085, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1991, 2155, 'ZODIAC_XVILO0', 510, 10000, 0, 0, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1992, 0, 'Nobody', 541, 0, 0, 0, 'None', 100, 1000, 299.335, -1537.41, 24.218, 69.517, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, 105, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1993, 646, '_BRITILLE_', 429, 9000000, 0, 1, 'None', 65, 659.01, 1256.51, -1433.99, 13.195, 263.302, 145, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1097, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 31, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1994, 2141, 'WAHBI_HHH', 400, 320000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1995, 2174, 'Vergas__', 411, 1000000, 0, 0, 'None', 99, 797.358, 1533.32, -1701.3, 13.11, 182.137, 1, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1996, 2174, 'Vergas__', 402, 850000, 0, 0, 'None', 89, 867.43, 1917.42, -1626.56, 13.333, 179.905, 1, 1, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1997, 3027, 'WLD_LAHJ_2', 560, 550000, 0, 0, 'None', 0, 842.986, 1246.73, -1424.16, 13.21, 1.488, 126, 126, -1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1033, 1030, 0, 1010, 1029, 1081, 0, 1087, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1998, 663, 'WLD_NAMOSE', 482, 450000, 0, 1, 'None', 97, 783.909, 2161.65, -1163.37, 23.874, 89.841, 3, 3, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 31, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1999, 2153, 'ROBIN_GHOST', 461, 100000, 0, 1, 'None', 97, 986.916, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2000, 2890, 'DYABLO_MICROBE', 420, 400000, 0, 0, 'None', 7, 903.658, 1274.9, -1297.18, 13.176, 174.93, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2001, 2168, 'XMAN_X3', 581, 50000, 0, 1, 'None', 77, 711.964, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2002, 1830, 'Eilina_Aya', 521, 120000, 0, 1, 'None', 13, 820.071, 1275.55, -1423.02, 14.524, 89.198, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2003, 2715, 'L9ATAL__ZRZOOR', 554, 400000, 0, 0, 'None', 96, 764.429, 904.475, -1238.94, 16.272, 88.51, 1, 0, 0, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2004, 2105, 'DARK_RUSSI', 581, 50000, 0, 0, 'None', 0, 846.886, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2005, 475, '_FLIPO_', 411, 1000000, 0, 0, 'None', 100, 975.287, 1535.75, -1667.61, 13.086, 0.898, 7, 7, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2006, 2195, 'MUNIR_', 404, 250000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2007, 2102, 'BIKER_RUSSI', 560, 550000, 0, 0, 'None', 85, 792.457, 2228.18, -1166.44, 25.412, 264.3, 1, 1, -1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 1030, 0, 1010, 1029, 1081, 0, 1087, 1170, 1141, 0, 0, 1, 0, 0, 0, 0, 0, 28, 28, 28, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2008, 1975, 'saad_az19', 602, 650000, 0, 1, 'None', 100, 916.038, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2009, 2049, 'L3ALAWI_STREX', 411, 1000000, 0, 0, 'None', 94, 476.711, 2496.66, -1682.35, 13.078, 278.588, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2010, 633, 'Za3ima_Aya', 487, 15550000, 0, 0, 'None', 94, 54701.9, 278.442, -1151.76, 85.655, 224.18, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2011, 1804, 'CaTaNa_Ta', 461, 100000, 0, 0, 'None', 98, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2012, 1804, 'CaTaNa_Ta', 400, 320000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2013, 2214, '[GLD]PABLO_7AGAR', 411, 1000000, 2500, 0, 'None', 99, 300, 1219.84, -1426.22, 13.047, 359.621, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2014, 2093, '__SAYMON_UX__', 481, 2500, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2015, 2101, 'medic_shurox', 410, 300000, 0, 0, 'None', 77, 736.633, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2016, 1501, 'LUFFY_XVILO', 509, 2500, 0, 0, 'None', 100, 992.397, 2007.24, -1764.82, 13.557, 336.35, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2017, 2098, 'MAHLOUI_KHN', 411, 1000000, 0, 0, 'None', 12, 958.003, 1807.09, -1136.2, 23.769, 170.194, 6, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2018, 1473, 'Ninja_adreson', 555, 450000, 0, 1, 'None', 100, 911.762, 1671.28, -2347.67, 1535.17, 91.326, 3, 3, -1, NULL, 3, 2000063, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2019, 2150, 'Oaiss__Xp', 481, 2500, 0, 1, 'None', 100, 976.25, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2020, 1765, 'Youssef_Lhaj', 411, 1000000, 0, 0, 'None', 97, 864.946, 1389.65, -1502.37, 8.252, 37.554, 4, 4, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2021, 2385, 'Falcon_Millions', 541, 900000, 0, 0, 'None', 100, 666.124, 974.933, -935.484, 41.46, 78.981, 2, 103, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 25, 0, 0, 0, 4, 24, 0, 25, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2022, 2282, '_BRAZELI_LOUCO', 411, 1000000, 0, 0, 'None', 20, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2023, 2150, 'Oaiss__Xp', 411, 1000000, 0, 0, 'None', 100, 964, 1043.37, -1474.62, 13.294, 1.643, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2024, 765, '3A_BO9A', 411, 1000000, 0, 1, 'None', 87, 951.824, 1540.71, -2177.66, 13.248, 269.315, 137, 2, 0, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2025, 3329, 'MARYOUL_Drag', 600, 270000, 0, 0, 'None', 100, 973.391, 965.5, -1357.56, 13.056, 359.707, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 55, 0, 0, 31, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2026, 1501, 'LUFFY_XVILO', 581, 50000, 0, 0, 'None', 28, 602, 1100.69, -1408.49, 13.036, 35.047, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2027, 1399, 'achraf_nh', 412, 250000, 0, 0, 'None', 99, 720.444, 1111.55, -1387.82, 13.892, 262.132, 28, 28, 2, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2028, 1519, 'SOOOOOOOONIIIIICE_', 411, 1000000, 0, 1, 'None', 100, 676.33, 1671.35, -2349.33, 1535.16, 89.855, 0, 0, -1, NULL, 3, 2000055, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2029, 1307, 'salah_kanita', 413, 500000, 0, 1, 'None', 20, 993.619, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2031, 0, 'Nobody', 451, 0, 0, 0, 'None', 100, 1000, 613.287, -597.204, 16.924, 269.428, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2032, 0, 'Nobody', 451, 0, 0, 0, 'None', 100, 1000, 610.412, -608.022, 16.924, 0.598, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2033, 0, 'Nobody', 451, 0, 0, 0, 'None', 100, 1000, 613.121, -601.263, 16.924, 272.662, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, -1, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2034, 1214, 'YOUSSEF', 507, 300000, 0, 0, 'None', 100, 983.846, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2035, 1214, 'YOUSSEF', 602, 650000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2036, 1214, 'YOUSSEF', 603, 850000, 0, 0, 'None', 20, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2037, 1279, 'TANJAWI__7ARBI__IS__ON', 451, 0, 0, 0, 'None', 100, 809.007, 1803.8, -1902.9, 13.067, 88.474, 175, 175, 2, NULL, 0, 0, 18652, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2038, 1024, 'X7___RAJAWI___GB', 507, 300000, 0, 1, 'None', 99, 963.854, 1118.41, -1388.8, 13.318, 176.629, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2039, 2220, 'KRAY_TINAA', 510, 10000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2040, 2606, 'said_may78', 602, 650000, 0, 0, 'None', 83, 815.717, 1231.78, -1373.05, 12.776, 104.616, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2041, 2183, 'ZIAAD_ELTCHAPO', 560, 550000, 0, 0, 'None', 16, 251, 2011.03, -1767.27, 13.718, 246.319, 0, 0, 2, NULL, 0, 0, 0, 0, 0, 1138, 0, 1033, 1030, 0, 1010, 1029, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2042, 2789, 'SI_ALI', 560, 550000, 0, 1, 'ZIAD ', 83, 770.121, 1647.63, -1104.24, 23.555, 269.308, 162, 162, 3, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1033, 1030, 0, 1010, 1029, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2043, 1024, 'X7___RAJAWI___GB', 546, 300000, 0, 1, 'None', 67, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2044, 1764, 'anas_psico', 500, 450000, 0, 0, 'None', 91, 678.646, 1075.11, -1608.28, 13.612, 271.953, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2045, 1963, 'HAPPE__BIN', 411, 1000000, 0, 1, 'None', 82, 637.873, 2227.13, -1160.12, 25.455, 208.638, 3, 3, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 29, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2046, 1500, 'ZORO__XVILO', 471, 70000, 0, 1, 'None', 19, 427.107, 1995.25, -1764.19, 13.528, 190.945, 6, 6, -1, NULL, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2047, 975, 'supra_out', 560, 550000, 0, 1, 'None', 100, 52620, 1242.19, -1344.06, 12.822, 96.633, 0, 0, 1, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1032, 0, 0, 1010, 0, 1081, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2048, 1519, 'Boonina_Millions', 402, 850000, 0, 1, 'None', 80, 1000, 292.721, -1338.85, 53.234, 34.761, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2049, 2789, 'SI_ALI', 411, 1000000, 0, 0, 'None', 83, 249, 1422.25, -692.353, 87.127, 242.42, 2, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1008, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 42, 32, 0, 24, 27, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2050, 2285, 'RIFOX_IRT', 475, 270000, 0, 0, 'None', 20, 370.075, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2051, 1471, 'IRT_WLD_ALI', 402, 850000, 0, 0, 'None', 97, 1000, 1318.51, -622.888, 108.913, 204.235, 2, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2052, 526, 'Theo_L3entiz', 533, 400000, 0, 1, 'None', 98, 977.538, 1035.6, -1102.61, 23.541, 180.89, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2053, 1473, 'Ninja_adreson', 587, 700000, 0, 0, 'None', 20, 810.38, 1660.25, -2352.24, 1535.18, 268.735, 2, 2, -1, NULL, 3, 2000063, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 27, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2054, 1473, 'Ninja_adreson', 545, 350000, 0, 0, 'None', 18, 928.241, 1659.84, -2356.84, 1535.29, 270.8, 6, 6, -1, NULL, 3, 2000063, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2055, 1024, 'X7___RAJAWI___GB', 411, 1000000, 0, 1, 'None', 100, 806.457, 681.634, -1189.05, 15.564, 48.549, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2056, 1500, 'ZORO__XVILO', 560, 550000, 0, 0, 'None', 84, 837.232, 1074.42, -1414.34, 13.377, 0.372, 3, 3, 0, NULL, 0, 0, 18648, 1, 0, 1138, 0, 0, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2057, 1307, 'salah_kanita', 587, 700000, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2058, 653, 'MADA_xvilo', 411, 1000000, 0, 0, 'None', 60, 680.995, 1486.63, -1584.76, 13.226, 171.52, 233, 233, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2059, 2210, 'MADARA_R1', 586, 50000, 0, 0, 'None', 100, 560, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2060, 1580, 'Mehdi_Fransesco', 589, 270000, 0, 1, 'None', 54, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2061, 2293, 'walid_maroc', 461, 100000, 0, 1, 'None', 96, 878.555, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2062, 2293, 'walid_maroc', 522, 1000000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2063, 2183, 'ZIAAD_ELTCHAPO', 411, 1000000, 0, 0, 'None', 19, 652.781, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2064, 2183, 'ZIAAD_ELTCHAPO', 541, 900000, 0, 0, 'None', 100, 787.505, 1991.6, -1766.82, 13.613, 223.685, 0, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2065, 1804, 'CaTaNa_Ta', 413, 500000, 0, 0, 'None', 100, 844.339, 1980.43, -1764.72, 14.133, 268.254, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2066, 1414, 'Lmadriya_lkhsiyem', 521, 120000, 0, 1, 'None', 0, 1000, 1991.17, -1756.76, 12.923, 91.566, 8, 8, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1073, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2067, 2389, 'amine_pablo', 468, 100000, 0, 0, 'None', 100, 690.628, 1235.42, -1349.97, 12.836, 336.277, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2068, 765, '3A_BO9A', 576, 330000, 0, 1, 'None', 99, 789.212, 1535.62, -2179.51, 13.098, 178.993, 137, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 1137, 0, 1010, 1136, 1079, 0, 1087, 1190, 1193, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2069, 1973, 'PECASO_XM8', 411, 1000000, 0, 1, 'None', 100, 973.534, 1660.16, -2340.02, 1536.54, 89.092, 1, 1, -1, NULL, 3, 2000052, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2070, 2328, 'ZIKO_LFERDA', 402, 850000, 0, 1, 'None', 20, 251, 2042.49, -1652.1, 13.333, 87.888, 3, 3, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2071, 653, 'MADA_xvilo', 412, 250000, 0, 0, 'None', 100, 785.186, 1492.29, -1609.69, 13.817, 87.407, 0, 0, 0, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2072, 421, 'SENIOR___CASPER', 562, 0, 0, 1, 'None', 17, 1000, 1224.91, -1382.07, 13.17, 140.145, 3, 3, 1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2073, 2789, 'SI_ALI', 541, 900000, 0, 0, 'None', 99, 748.368, 1439.28, -1663.09, 13.139, 162.22, 0, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2074, 2235, 'RINOX_IRT', 402, 850000, 0, 1, 'None', 100, 1000, 1603.99, -1604.03, 13.326, 90.475, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2076, 106, 'ZETSU_XVILO', 521, 120000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2077, 106, 'ZETSU_XVILO', 493, 20750000, 0, 0, 'None', 80, 1000, 330.575, -1908.1, 2.163, 330.882, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2078, 1291, 'Shark_Bernard', 562, 0, 0, 0, 'None', 2, 811.735, 1984.84, -1764.06, 13.678, 183.679, 2, 2, 2, NULL, 0, 0, 18652, 1, 3, 1147, 0, 1038, 1040, 0, 1010, 1034, 1076, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2079, 2141, 'WAHBI_HHH', 411, 1000000, 0, 0, 'None', 49, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2080, 2214, '[GLD]PABLO_7AGAR', 522, 1000000, 0, 1, 'None', 100, 845.862, 1217.2, -1365.74, 12.732, 6.882, 4, 4, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2081, 1765, 'Youssef_Lhaj', 411, 1000000, 0, 0, 'None', 90, 941.658, 1371.64, -1568.37, 8.266, 59.314, 0, 0, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2082, 2331, 'YAHYA_ALTCHAPO', 509, 2500, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2083, 2171, 'king_ster', 510, 10000, 0, 0, 'None', 20, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2084, 2329, 'walid_moris', 522, 1000000, 0, 0, 'None', 100, 626.378, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2085, 2277, 'MEHDI__TB', 541, 900000, 0, 1, 'None', 100, 980.353, 1252.96, -1353.66, 12.741, 176.333, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2086, 2210, 'MADARA_R1', 421, 250000, 0, 1, 'None', 20, 251, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2087, 2210, 'MADARA_R1', 560, 550000, 0, 1, 'None', 87, 251, 557.867, -1283.98, 17.0007, 0, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2088, 1900, 'Talb_M3acho', 560, 550000, 0, 0, 'None', 100, 1000, 1948.72, -1800.45, 13.201, 267.856, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1074, 0, 1087, 1169, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2089, 2210, 'MADARA_R1', 481, 2500, 0, 0, 'None', 100, 983, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2090, 2350, 'YOUNES_TL', 411, 1000000, 0, 0, 'None', 97, 251, 2041.87, -1748.77, 13.11, 88.226, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2091, 2192, 'MEHDI_MOCRO', 402, 850000, 0, 0, 'None', 39, 975.48, 2012.08, -1770.93, 13.889, 179.309, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2092, 2267, 'Mohamed_sell15', 541, 900000, 0, 1, 'None', 100, 973, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2093, 862, 'ZOU_HIR', 487, 0, 0, 1, 'None', 96, 778.639, -1106.07, -950.056, 129.394, 170.709, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2094, 2095, 'RP_TANJAW9I', 587, 700000, 0, 1, 'None', 7, 749.883, 1241.78, -1374.21, 12.896, 271.833, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2095, 1592, 'TOXIC_UH', 554, 400000, 0, 1, 'None', 95, 749.093, 1456.81, -1474.14, 13.435, 359.538, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2096, 1501, 'LUFFY_XVILO', 541, 900000, 0, 1, 'None', 89, 984.758, 1215.5, -1426.33, 12.986, 4.999, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2097, 2235, 'RINOX_IRT', 541, 900000, 0, 0, 'None', 100, 355.871, 1556.43, -1607.64, 13.008, 88.468, 6, 8, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2098, 1379, 'UZUI_TENGEN', 579, 310000, 0, 1, 'None', 99, 960.22, 935.59, -1248.01, 16.038, 0.279, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2099, 1953, 'oussama__lfrda', 587, 700000, 0, 0, 'None', 96, 644.742, 1239.07, -1343.31, 12.891, 307.341, 198, 0, 3, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2100, 1973, 'PECASO_XM8', 554, 400000, 0, 1, 'None', 18, 994.13, 1664.31, -2363.71, 1535.57, 359.383, 90, 90, -1, NULL, 3, 2000052, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2101, 1864, 'BIG__SMOKE_', 411, 1000000, 0, 1, 'None', 98, 721.415, 1533.92, -1697.32, 13.388, 185.406, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2102, 2214, '[GLD]PABLO_7AGAR', 541, 900000, 0, 0, 'None', 78, 251, 383.43, -2056.83, 7.706, 181.164, 1, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2103, 1500, 'ZORO__XVILO', 481, 2500, 0, 1, 'None', 20, 958, 552.43, -1260.97, 16.746, 332.528, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2104, 1024, 'X7___RAJAWI___GB', 589, 270000, 0, 0, 'None', 98, 999.604, 1107.68, -1388.01, 13.315, 176.069, 140, 140, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2105, 2667, 'Abdel9ader_Lkhraz', 576, 330000, 0, 1, 'None', 20, 907.466, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2106, 1927, 'Tornido_Eltchapo', 560, 550000, 0, 1, 'None', 96, 695.24, 688.658, -1173.09, 14.917, 263.762, 222, 222, -1, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1076, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2107, 1291, 'Shark_Bernard', 422, 450000, 0, 1, 'None', 19, 872, 1212.97, -1424.7, 13.37, 357.628, 1, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2108, 2389, 'amine_pablo', 541, 900000, 0, 1, 'None', 97, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(2109, 1399, 'achraf_nh', 602, 650000, 0, 0, 'None', 0, 694.672, 1112.24, -1387.77, 13.467, 269.815, 1, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2110, 1500, 'ZORO__XVILO', 510, 10000, 0, 1, 'None', 100, 775.177, 1424.74, -914.591, 35.655, 359.338, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2111, 1577, 'SANJI_XVILO', 509, 2500, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2112, 1577, 'SANJI_XVILO', 510, 10000, 0, 0, 'None', 100, 813.125, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2113, 1577, 'SANJI_XVILO', 481, 2500, 0, 0, 'None', 100, 954.007, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2114, 2298, 'mohamd_lferda', 560, 550000, 0, 1, 'None', 100, 1000, 1277.26, -1357.92, 13, 275.268, 126, 126, 2, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 1028, 1081, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2115, 1804, 'CaTaNa_Ta', 587, 700000, 0, 0, 'None', 82, 923, 283.083, -1532.06, 24.32, 233.851, 127, 127, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2116, 2401, 'LOMS_XVILO', 522, 1000000, 0, 1, 'None', 20, 407.805, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2117, 2641, 'MOUAD_MESSI', 411, 1000000, 0, 1, 'None', 100, 685.015, 1518.24, -837.279, 67.079, 64.823, 2, 3, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2118, 1519, 'SOOOOOOOONIIIIICE_', 560, 550000, 0, 1, 'None', 100, 1000, 1660.22, -2340.01, 1536.45, 90.021, 0, 0, -1, NULL, 3, 2000055, 0, 0, 3, 1139, 0, 1033, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2119, 2319, 'zozo_nfp', 411, 1000000, 0, 1, 'None', 100, 251, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2120, 2267, 'Mohamed_sell15', 587, 700000, 0, 0, 'None', 20, 700.886, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2121, 2267, 'Mohamed_sell15', 600, 270000, 0, 1, 'None', 20, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2122, 2193, 'SPIDER__GR', 541, 900000, 0, 0, 'None', 5, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2123, 862, 'ZOU_HIR', 541, 900000, 0, 1, 'None', 99, 937.955, 1226.47, -1425.63, 13.008, 357.639, 18, 0, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2124, 2329, 'walid_moris', 533, 400000, 0, 0, 'None', 20, 664, 557.867, -1283.98, 17.0007, 0, 88, 88, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2125, 1662, 'ALMODAMER____98', 522, 1000000, 0, 0, 'None', 100, 553, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2126, 355, '_IRMAX_', 509, 2500, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2127, 1291, 'Shark_Bernard', 560, 550000, 0, 1, 'None', 16, 855.256, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2128, 2410, 'BARBARA_CHARAF', 579, 310000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2129, 633, 'Za3ima_Aya', 429, 9000000, 0, 1, 'None', 93, 715, 1620.41, -1107.44, 23.586, 266.396, 5, 5, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2130, 846, '[YKZ]_OSCAR', 586, 50000, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2131, 1024, 'X7___RAJAWI___GB', 522, 1000000, 0, 1, 'None', 54, 912.815, 1192.19, -1329.38, 12.938, 269.267, 170, 170, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2132, 2105, 'DARK_RUSSI', 560, 550000, 0, 0, 'None', 93, 817.633, 557.867, -1283.98, 17.0007, 0, 3, 2, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2133, 2093, '__SAYMON_UX__', 541, 900000, 0, 1, 'None', 100, 1000, 1224.02, -1338.59, 12.794, 187.688, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2134, 653, 'MADA_xvilo', 411, 1000000, 0, 1, 'None', 88, 879.653, 1480.54, -1585.13, 13.225, 173.451, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2135, 2380, 'RIVALDO_XV', 541, 900000, 0, 0, 'None', 100, 894.831, 1995.03, -2414.03, 13.024, 132.246, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2136, 2322, 'IAM_SIGMAA', 579, 310000, 0, 1, 'None', 100, 909.212, 955.555, -1420.14, 13.482, 184.646, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2137, 407, 'oussama_r', 560, 550000, 5000, 1, 'None', 100, 1000, 1212.48, -1426.16, 13.046, 0.986, 52, 1, 3, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2138, 2449, 'Tarik_Dali', 510, 10000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2139, 868, 'YASSIN_RESTOVA', 579, 310000, 5000, 0, 'None', 100, 1000, 1629.91, -1089.93, 23.791, 267.888, 233, 233, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2140, 1887, 'FATAL_MIAL', 541, 900000, 0, 0, 'None', 96, 251, 562.397, -1283.85, 17.0007, 0, 175, 1, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2141, 2026, 'AYOUB_DLAM', 560, 550000, 0, 1, 'None', 16, 909.19, 1219.5, -1367.32, 12.874, 268.645, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2142, 877, 'L7AJ_ZIAD', 421, 250000, 0, 0, 'None', 93, 942.126, 1036.99, -633.303, 120.059, 276.455, 7, 7, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2143, 2026, 'AYOUB_DLAM', 522, 1000000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2145, 1973, 'PECASO_XM8', 560, 550000, 0, 1, 'None', 98, 495.526, 1103.82, -1375.31, 13.523, 1.224, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 1138, 0, 1032, 1027, 0, 1010, 1028, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2146, 1973, 'PECASO_XM8', 462, 25000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2147, 1192, 'I_NAMOSE', 429, 9000000, 0, 0, 'None', 17, 984.49, 1664.47, -2353.72, 1535.12, 91.131, 185, 1, -1, NULL, 3, 2000052, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2148, 2018, 'BODIGARD_MAFIAa', 439, 500000, 0, 1, 'None', 20, 535.24, 2490.47, -1688.24, 13.386, 99.449, 5, 2, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 1013, 1010, 0, 1074, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2149, 929, 'TANGAWI_', 560, 550000, 0, 0, 'None', 0, 974.993, 1912.31, -1718.74, 13.086, 271.906, 126, 126, -1, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1032, 1027, 0, 0, 0, 0, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2150, 1279, 'JO9LI__RPT', 560, 550000, 0, 0, 'None', 88, 347.956, 1912.13, -1713.34, 13.076, 269.272, 131, 1, -1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 0, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2152, 653, 'MADA_xvilo', 541, 900000, 0, 1, 'None', 100, 409.534, 1242.93, -1343.46, 12.784, 92.327, 3, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2153, 1978, 'HN_HIBA', 560, 550000, 0, 1, 'None', 6, 913.458, 1242.72, -1356.12, 12.822, 91.731, 126, 126, 3, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1033, 0, 0, 1010, 1029, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2154, 1589, 'TiTaN_Hermano', 522, 1000000, 0, 0, 'None', 47, 928.516, 827.72, -862.501, 69.492, 294.203, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2155, 2385, 'Falcon_Millions', 481, 2500, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2156, 765, 'Thomas_Shellby', 506, 0, 0, 1, 'None', 78, 950.708, 2499.62, -1647.81, 13.225, 179.368, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2157, 1471, 'IRT_WLD_ALI', 558, 0, 0, 1, 'None', 99, 930.587, 1335.05, -630.161, 108.766, 197.94, 1, 1, 2, NULL, 0, 0, 18648, 1, 3, 1164, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 1166, 1168, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2158, 2968, 'ilyass_xx', 559, 0, 0, 0, 'None', 100, 1000, 2469.29, -1679.8, 13.147, 32.612, 3, 2, 1, NULL, 0, 0, 18647, 1, 0, 1162, 0, 1068, 1071, 0, 1010, 1065, 1082, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2159, 2968, 'ilyass_xx', 565, 0, 0, 1, 'None', 100, 996.885, 2514.13, -1680.35, 13.038, 51.588, 3, 3, 1, NULL, 0, 0, 18647, 1, 0, 1049, 0, 1054, 1052, 0, 1010, 1046, 1081, 0, 1087, 1153, 1150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2160, 2968, 'ilyass_xx', 506, 0, 0, 1, 'None', 100, 1000, 2482.38, -1691.53, 13.196, 354.018, 137, 2, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2161, 1471, 'IRT_WLD_ALI', 562, 0, 0, 1, 'None', 97, 938.947, 1357.76, -621.981, 108.791, 196.648, 1, 1, 0, NULL, 0, 0, 18647, 1, 3, 1147, 0, 1038, 1040, 0, 1010, 1034, 1079, 0, 1087, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2162, 633, 'Za3ima_Aya', 411, 1000000, 0, 0, 'None', 89, 656.797, 1246.57, -1432.32, 13.058, 31, 126, 126, 0, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1008, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2163, 2889, 'VEGAS_JNYN', 411, 1000000, 0, 1, 'None', 100, 1000, 1793.55, -1593.51, 13.208, 131.744, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2164, 2889, 'VEGAS_JNYN', 541, 900000, 0, 0, 'None', 20, 858.247, 2517.4, -1089.81, 54.099, 138.246, 0, 5, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2165, 2498, 'motez_sellami00', 500, 450000, 0, 1, 'None', 20, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2166, 2498, 'motez_sellami00', 602, 650000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2167, 2484, 'amine_ba', 461, 100000, 0, 0, 'None', 100, 884.618, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2168, 2120, 'Mohamed_sell1', 603, 850000, 0, 0, 'None', 20, 697.688, 2271.35, -1105.69, 37.814, 342.263, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2169, 2277, 'MEHDI__TB', 522, 1000000, 0, 0, 'None', 94, 251, 1257.26, -1276.25, 13.015, 193.694, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2170, 1983, 'MAFIA_jordan', 560, 550000, 0, 0, 'None', 14, 251, 1971.8, -2342.47, 13.341, 243.092, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1078, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 29, 24, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2171, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2259.02, -1107.34, 37.684, 246.64, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2172, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2260.62, -1101.99, 37.684, 242.572, 251, 251, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2173, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2251.14, -1104.45, 41.313, 328.491, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2174, 0, 'Nobody', 413, 0, 0, 0, 'None', 100, 1000, 2257.79, -1092.74, 41.703, 146.234, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2175, 0, 'Nobody', 413, 0, 0, 0, 'None', 100, 1000, 2253.08, -1088.98, 41.668, 140.152, 251, 251, 4, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2176, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2262.67, -1099.3, 37.646, 236.919, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2177, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2249.16, -1084.14, 41.271, 127.663, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2178, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2249.55, -1084.84, 41.271, 122.773, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2179, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2260.49, -1105.25, 37.646, 245.112, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2180, 2459, 'HIBA_SMP', 500, 450000, 0, 0, 'None', 100, 648.686, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2181, 106, 'ZETSU_XVILO', 506, 0, 0, 0, 'None', 99, 776.845, 1944.13, -1791.52, 13.166, 89.602, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2182, 2770, 'SI_LHAJ', 412, 250000, 0, 1, 'None', 99, 933, 2819.4, -1075.6, 30.487, 86.649, 0, 0, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2183, 950, 'CHINWI_07', 506, 0, 0, 0, 'None', 100, 1000, 1983.01, -1990.48, 13.547, 109.077, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2184, 950, 'CHINWI_07', 506, 0, 0, 0, 'None', 100, 1000, 1983.41, -1988.52, 13.547, 37.102, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2185, 950, 'CHINWI_07', 506, 0, 0, 0, 'None', 100, 1000, 1983.41, -1988.52, 13.547, 37.102, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2186, 950, 'CHINWI_07', 506, 0, 0, 0, 'None', 100, 1000, 1983.41, -1988.52, 13.547, 37.102, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2187, 950, 'CHINWI_07', 506, 0, 0, 1, 'None', 100, 1000, 1983.41, -1988.52, 13.547, 37.102, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2188, 950, 'CHINWI_07', 506, 0, 0, 0, 'None', 100, 1000, 1983.41, -1988.52, 13.547, 37.102, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2189, 1192, 'I_NAMOSE', 506, 0, 0, 0, 'None', 98, 948, 2228.04, -1162.89, 25.425, 269.957, 211, 211, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 30, 30, 30, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2190, 1192, 'I_NAMOSE', 506, 0, 0, 0, 'None', 86, 401.5, 261.199, -1375.31, 52.767, 301.678, 217, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2191, 975, 'supra_out', 587, 700000, 0, 0, 'None', 100, 53820, 1240.6, -1327.39, 12.896, 103.182, 3, 3, 1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2192, 1973, 'PECASO_XM8', 560, 550000, 0, 0, 'None', 20, 997, 1670.52, -2350.31, 1535.15, 269.889, 1, 1, -1, NULL, 3, 2000052, 18648, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 1028, 1081, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2193, 1973, 'PECASO_XM8', 411, 1000000, 0, 0, 'None', 98, 999.943, 1664.77, -2346, 1535.18, 88.481, 200, 200, -1, NULL, 3, 2000052, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2194, 975, 'supra_out', 411, 1000000, 0, 1, 'None', 100, 832.096, 1241.85, -1347.05, 12.886, 90.512, 2, 2, -1, NULL, 0, 0, 18647, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1082, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2195, 2459, 'HIBA_SMP', 560, 550000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 2, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2196, 2459, 'HIBA_SMP', 560, 550000, 0, 1, 'None', 100, 757.264, 557.867, -1283.98, 17.0007, 0, 3, 3, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2197, 2459, 'HIBA_SMP', 402, 850000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2198, 1192, 'I_NAMOSE', 487, 15550000, 0, 1, 'None', 97, 251, 256.925, -1343.31, 53.266, 291.185, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2199, 2329, 'walid_moris', 589, 270000, 0, 0, 'None', 100, 724.509, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2200, 1815, '@islam_07.', 462, 25000, 0, 0, 'None', 20, 749.655, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2201, 1519, 'Boonina_Millions', 429, 9000000, 0, 1, 'None', 99, 858.46, 1659.98, -2353.4, 1535.1, 267.601, 0, 1, -1, NULL, 3, 2000055, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2202, 2408, 'amine_404', 560, 550000, 0, 0, 'None', 20, 962.062, 562.397, -1283.85, 17.0007, 0, 1, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2203, 2503, 'Davoos_Millions', 411, 1000000, 0, 0, 'None', 3, 650.847, 1326.03, -1452.6, 13.205, 355.599, 1, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2204, 1214, 'BANKAI_FIXA', 541, 900000, 0, 0, 'None', 87, 953.796, 552.818, -1284.13, 17.0007, 0, 2, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2205, 2299, '[BRZ]LUFFY_L7GAR', 589, 270000, 0, 1, 'None', 100, 982.29, 1229.17, -1426.17, 13.125, 355.031, 8, 8, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2206, 2098, 'MAHLOUI_KHN', 522, 1000000, 0, 0, 'None', 100, 1000, 1815.67, -1070.58, 23.64, 351.321, 0, 0, -1, NULL, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2207, 2789, 'SI_ALI', 463, 90000, 0, 1, 'None', 73, 887.614, 1676.38, -1123.8, 23.446, 270.287, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2208, 2523, 'med_said', 410, 300000, 0, 0, 'None', 100, 668.954, -1099.98, -1652.04, 76.021, 92.061, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2210, 1380, 'nobyx_henderson', 560, 550000, 0, 1, 'None', 20, 826.684, 2157.13, -1455.17, 25.244, 270.21, 197, 197, -1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1076, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2211, 1973, 'PECASO_XM8', 560, 550000, 0, 1, 'None', 96, 942.977, 1670.68, -2345.28, 1535.13, 269.561, 200, 200, -1, NULL, 3, 2000052, 18652, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1081, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2212, 1761, 'I_NAMOSE', 541, 900000, 0, 0, 'None', 100, 684.55, 382.255, -2082.71, 7.406, 128.605, 1, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2213, 3517, 'SI_DAFIR', 541, 900000, 0, 1, 'None', 100, 462.751, 320.272, -1807.99, 4.133, 176.858, 6, 4, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2214, 1709, 'SUPRA_MK4', 411, 1000000, 0, 1, 'None', 85, 1000, 1776.61, -1898.97, 13.069, 269.917, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2215, 653, 'MADA_xvilo', 429, 9000000, 0, 0, 'None', 100, 881.312, 2502.54, -2015.88, 13.227, 94.938, 1, 0, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2216, 894, 'TALIANI_WOLF', 429, 9000000, 0, 1, 'None', 75, 804.162, 350.781, -1512.27, 32.667, 113.575, 109, 0, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2217, 620, 'mp3', 587, 700000, 0, 1, 'None', 98, 1000, 341.619, -1789.18, 4.692, 0.137, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2218, 1761, 'I_NAMOSE', 587, 700000, 0, 0, 'None', 59, 1000, 313.412, -1808.39, 4.175, 178.227, 109, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2219, 620, 'mp3', 602, 650000, 0, 1, 'None', 99, 1000, 338.427, -1789.3, 4.729, 1.271, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2220, 638, 'VODKA_GHOST', 560, 550000, 0, 0, 'None', 54, 251, 1208.61, -1426.08, 13.088, 0.417, 3, 3, 0, NULL, 0, 0, 18648, 1, 3, 1138, 0, 1032, 1030, 0, 1010, 1029, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2221, 2542, 'Simo_bakkali', 560, 550000, 0, 0, 'None', 100, 251, 2796.64, -1575.67, 10.597, 90.819, 0, 0, 2, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2222, 2523, 'med_said', 560, 550000, 0, 0, 'None', 96, 251, 2496.97, -2004.87, 13.071, 83.257, 3, 3, 1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1033, 1027, 0, 1010, 1028, 1083, 0, 1087, 0, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 34, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2223, 1709, 'SUPRA_MK4', 560, 550000, 0, 0, 'None', 100, 643.281, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2224, 620, 'mp3', 579, 310000, 0, 1, 'None', 100, 796.014, 346.867, -1808.24, 4.426, 179.15, 198, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2225, 2780, 'MAMADO_x', 411, 1000000, 0, 1, 'None', 69, 751.345, 967.859, -1367.04, 13.032, 179.557, 126, 126, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2226, 3147, 'Nabil_Vinsmoke', 541, 900000, 0, 0, 'None', 87, 737.51, 1281.03, -1344.68, 13.001, 86.861, 109, 122, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2227, 975, 'supra_out', 402, 850000, 0, 0, 'None', 96, 251, 1240.37, -1324.38, 12.999, 92.123, 1, 1, -1, NULL, 0, 0, 18648, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2228, 1585, 'be_znaz', 554, 400000, 0, 0, 'None', 20, 984.649, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2229, 2120, 'Mohamed_sell1', 411, 1000000, 0, 0, 'None', 20, 454.186, 2273.33, -1107.31, 37.704, 337.852, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2230, 427, 'BO9AL_V2', 560, 550000, 0, 1, 'None', 100, 876.043, 2505.89, -1672.56, 13.026, 170.776, 6, 6, 0, NULL, 0, 0, 18651, 1, 0, 1138, 0, 1033, 1027, 0, 1010, 0, 1079, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2231, 1374, 'hamza_nadili', 489, 400000, 0, 1, 'None', 100, 908.983, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2232, 1825, 'HICHAM_casawi', 468, 100000, 0, 1, 'None', 7, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2233, 2492, '_BRAZELI_BRZ_', 487, 0, 0, 0, 'None', 99, 1000, 2243.81, -1111.23, 48.926, 113.632, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2234, 2056, 'vip_piro1', 560, 550000, 0, 0, 'None', 89, 819.153, 2274.16, -1107.25, 37.633, 333.908, 3, 5, 1, NULL, 0, 0, 18647, 1, 0, 1138, 0, 1033, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2235, 1374, 'hamza_nadili', 462, 25000, 0, 1, 'None', 100, 908.508, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2236, 2641, 'MOUAD_MESSI', 411, 1000000, 0, 0, 'None', 96, 996.086, 1519.3, -839.687, 66.757, 85.914, 6, 6, 1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2237, 1761, 'I_NAMOSE', 402, 850000, 0, 0, 'None', 100, 996.518, 1280.27, -1331.59, 13.157, 89.415, 0, 0, -1, NULL, 0, 0, 18648, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2238, 2018, 'BODIGARD_MAFIAa', 560, 550000, 0, 0, 'None', 8, 1000, 1948.19, -1803.91, 13.21, 267.998, 2, 2, 1, NULL, 0, 0, 18649, 1, 0, 1138, 0, 0, 1027, 0, 1010, 0, 1079, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2239, 2968, 'ilyass_xx', 402, 850000, 0, 0, 'None', 100, 831.676, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2240, 2503, 'Davoos_Millions', 541, 900000, 0, 1, 'None', 88, 813, 2002.94, -1777.87, 14.076, 179.349, 194, 127, 3, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2241, 1501, 'LUFFY_XVILO', 402, 850000, 0, 1, 'None', 98, 974.097, 1095.34, -1413.04, 13.428, 358.218, 1, 1, 3, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2242, 2523, 'med_said', 468, 100000, 0, 1, 'None', 100, 1000, 2796.14, -1580.74, 10.584, 105.56, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2243, 2520, 'GHOST_ZOLDYCK', 461, 100000, 0, 0, 'None', 94, 850.705, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2244, 1519, 'SOOOOOOOONIIIIICE_', 541, 900000, 0, 1, 'None', 99, 1000, 1659.59, -2357.93, 1535.06, 269.608, 0, 8, -1, NULL, 3, 2000055, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2245, 2340, 'BO_ZBAL', 489, 400000, 0, 0, 'None', 18, 945.951, 1828.06, -1081.84, 24.075, 269.954, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2246, 653, 'MADA_xvilo', 560, 550000, 0, 0, 'None', 89, 251, 1131.51, -1375.21, 13.52, 89.459, 2, 1, -1, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1028, 1082, 0, 1087, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 20, 29, 31, 4, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2247, 2520, 'GHOST_ZOLDYCK', 521, 120000, 0, 0, 'None', 5, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2248, 2214, '[GLD]PABLO_7AGAR', 481, 2500, 0, 1, 'None', 100, 982.107, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2249, 643, 'VEGAS_PADRI', 560, 550000, 0, 0, 'None', 100, 484.547, 1242.57, -1318.83, 12.825, 175.812, 1, 1, -1, NULL, 0, 0, 18648, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1029, 1075, 0, 1087, 1170, 1140, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2250, 2334, 'zoro_abdou', 468, 100000, 0, 0, 'None', 20, 69500000000000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2251, 1825, 'HICHAM_casawi', 461, 100000, 0, 0, 'None', 55, 466.129, 1226.99, -1379.09, 12.716, 43.383, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2252, 2334, 'zoro_abdou', 541, 900000, 0, 0, 'None', 86, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2253, 1500, 'ZORO__XVILO', 510, 10000, 0, 0, 'None', 100, 999.388, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2254, 2334, 'zoro_abdou', 496, 250000, 0, 0, 'None', 100, 554.314, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2255, 2334, 'zoro_abdou', 522, 1000000, 0, 0, 'None', 100, 878.091, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2256, 2334, 'zoro_abdou', 411, 1000000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2259, 106, 'ZETSU_XVILO', 487, 0, 0, 0, 'None', 100, 750.25, 494.962, -1932.59, 17.387, 136.823, 2, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2260, 1979, 'Mar_Sis', 445, 300000, 0, 0, 'None', 98, 501.304, 1535.98, -1666.71, 13.253, 178.47, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2261, 1192, 'I_NAMOSE', 506, 0, 0, 1, 'None', 92, 778.987, 262.858, -1378, 52.787, 301.927, 1, 1, -1, NULL, 0, 0, 18652, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2262, 1973, 'PECASO_XM8', 487, 0, 0, 1, 'None', 100, 300, 1007.08, -1354.18, 13.513, 58.003, 251, 251, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2263, 2214, '[GLD]PABLO_7AGAR', 412, 250000, 0, 0, 'None', 95, 797.52, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2264, 1519, 'BA9LAWA_', 415, 0, 0, 1, 'None', 75, 48606, 294.588, -1180.76, 80.685, 311.474, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 1023, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 24, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2265, 1660, 'T_RexX', 565, 0, 0, 0, 'None', 100, 629.348, 1986.87, -1745.93, 13.135, 87.074, 1, 1, 0, NULL, 0, 0, 18650, 1, 3, 1049, 0, 1053, 1051, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2266, 2497, 'perlo_amine', 603, 850000, 0, 0, 'None', 100, 703.632, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2267, 1592, 'TOXIC_UH', 507, 300000, 0, 1, 'None', 17, 985.84, 2272.56, -1106.06, 37.801, 331.888, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2268, 929, 'TANGAWI_', 541, 900000, 0, 0, 'None', 0, 1000, 1978.96, -1768.38, 13.625, 268.868, 3, 1, 3, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1082, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2269, 2968, 'ilyass_xx', 482, 450000, 0, 0, 'None', 100, 672.117, 2476.66, -1686.33, 13.541, 326.895, 4, 4, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2270, 2789, 'SI_ALI', 541, 900000, 0, 1, 'None', 92, 613.852, 273.572, -1306.22, 53.391, 202.163, 2, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2271, 2609, 'MARKIZ_RP', 481, 2500, 0, 0, 'None', 100, 975.167, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2272, 2609, 'MARKIZ_RP', 521, 120000, 0, 1, 'None', 94, 683.583, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2273, 929, 'TANGAWI_', 487, 15550000, 0, 1, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2274, 1519, 'Boonina_Millions', 517, 0, 0, 1, 'None', 99, 1000, 286.591, -1339.74, 53.292, 37.451, 0, 0, -1, NULL, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 24, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2275, 1709, 'SUPRA_MK4', 559, 0, 0, 1, 'None', 100, 998.072, 1776.96, -1902.97, 12.973, 271.205, 0, 0, 2, NULL, 0, 0, 0, 1, 3, 1158, 0, 1067, 1071, 0, 1010, 1066, 1085, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2276, 3560, 'Diib_Dark2', 560, 550000, 0, 0, 'None', 82, 388.426, 393.556, -2080.52, 7.543, 276.926, 1, 1, 0, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 0, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2277, 2968, 'ilyass_xx', 603, 850000, 0, 0, 'None', 100, 888.805, 1979.44, -1767.34, 14.084, 175.336, 0, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2278, 1589, 'TiTaN_Hermano', 555, 450000, 0, 0, 'None', 44, 961.299, 832.336, -858.857, 69.58, 198.414, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1084, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2279, 862, 'ZOU_HIR', 560, 550000, 0, 0, 'None', 3, 799.868, 1231.34, -1427.06, 13.167, 91.491, 1, 1, 3, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1033, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2280, 1589, 'TiTaN_Hermano', 429, 9000000, 0, 1, 'None', 100, 754.204, 827.038, -870.191, 68.469, 294.235, 0, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2281, 1589, 'TiTaN_Hermano', 489, 400000, 0, 1, 'None', 100, 955.293, 839.758, -866.131, 69.673, 105.482, 2, 2, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2282, 2634, 'amine_00', 581, 50000, 0, 0, 'None', 100, 473, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2283, 2588, 'ROBIN_CHP', 581, 50000, 0, 1, 'None', 20, 796.594, 2205.92, -1177.13, 25.323, 271.7, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2284, 2593, 'ADILOK_CHP', 461, 100000, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2285, 2635, 'Recardo_Sepastiano', 412, 250000, 0, 0, 'None', 18, 990.752, 682.976, -1182.43, 15.381, 211.3, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2286, 2624, 'HAMZA_ATR', 468, 100000, 0, 1, 'None', 20, 933.699, 1012.3, -1296.25, 13.206, 15.122, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2287, 2624, 'HAMZA_ATR', 468, 100000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2288, 1761, 'I_NAMOSE', 560, 550000, 0, 0, 'None', 98, 745.665, 333.91, -1808.61, 4.166, 178.995, 2, 2, 0, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1098, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 20, 0, 0, 25, 30, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2289, 2855, 'RASK_TA3RFNI', 541, 900000, 0, 1, 'None', 20, 979.846, 1981.08, -1766.69, 13.671, 180.101, 1, 140, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2290, 435, 'RINIO_', 603, 850000, 0, 1, 'None', 100, 645.004, 1253.45, -1427.13, 13.316, 1.356, 0, 3, 1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2291, 2635, 'Recardo_Sepastiano', 560, 550000, 0, 0, 'None', 93, 732.853, 1804.82, -1060.81, 23.627, 259.807, 1, 1, 2, NULL, 0, 0, 18648, 1, 0, 1139, 0, 1033, 1030, 0, 1010, 1028, 1073, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2292, 2578, 'Zbelbola_Millions', 541, 900000, 0, 0, 'None', 89, 637.512, 2758.08, -1424.57, 15.875, 270.199, 179, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 24, 0, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2293, 2641, 'MOUAD_MESSI', 436, 250000, 0, 0, 'None', 100, 995.349, 1519.94, -848.974, 65.502, 136.002, 90, 90, 1, NULL, 0, 0, 18652, 1, 3, 1001, 0, 0, 0, 0, 1010, 1019, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2294, 3068, 'MR_EAGLE', 560, 550000, 0, 1, 'None', 100, 1000, 334.465, -1339.89, 14.179, 205.213, 6, 6, 2, NULL, 0, 0, 18652, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 4, 27, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2295, 2579, 'Firas_Millions', 541, 900000, 0, 1, 'None', 100, 1000, 2211.8, -1175.34, 25.313, 0.182, 136, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 31, 24, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2296, 2580, 'Briwa_Millions', 541, 900000, 0, 0, 'None', 78, 1000, 981.897, -918.458, 41.281, 262.883, 200, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2297, 2641, 'MOUAD_MESSI', 541, 900000, 0, 1, 'None', 100, 1000, 1659.03, -2340.13, 1536.63, 89.995, 7, 3, -1, NULL, 3, 2000075, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2298, 1471, 'IRT_WLD_ALI', 603, 850000, 0, 0, 'None', 48, 832.274, 1321.12, -634.051, 108.973, 199.654, 1, 0, -1, NULL, 0, 0, 18648, 1, 0, 1023, 0, 1006, 0, 0, 1010, 1018, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2299, 2095, 'RP_TANJAW9I', 603, 850000, 0, 1, 'None', 17, 821.51, 2764.38, -1971.38, 13.285, 81.329, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2300, 1577, 'SANJI_XVILO', 560, 550000, 0, 0, 'None', 100, 987.653, 1650.51, -1107.22, 23.569, 91.396, 3, 3, 0, NULL, 0, 0, 18650, 1, 0, 1138, 0, 0, 1027, 0, 1010, 1028, 1085, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2301, 2329, 'walid_moris', 560, 550000, 0, 1, 'None', 100, 451.803, 557.867, -1283.98, 17.0007, 0, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2302, 2578, 'Zbelbola_Millions', 560, 550000, 0, 0, 'None', 97, 986.708, 980.263, -930.333, 41.079, 176.658, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1029, 1082, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2303, 2608, 'TOBA_RESTOVA', 560, 550000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(2304, 2375, 'NINJA_NETWORK', 411, 1000000, 0, 1, 'None', 11, 685.023, 1587.14, -1739.15, 13.232, 91.237, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 31, 27, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2305, 2647, 'SI_DARDOKHI', 521, 120000, 0, 0, 'None', 100, 952.506, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2306, 2626, 'ztla_49', 445, 300000, 0, 1, 'None', 100, 886.829, 1354.3, -1749.03, 13.249, 356.974, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2307, 2503, 'Davoos_Millions', 587, 700000, 0, 1, 'None', 11, 1000, 1242.69, -1311.46, 12.849, 358.23, 13, 2, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2308, 2635, 'Recardo_Sepastiano', 468, 100000, 0, 0, 'None', 19, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2310, 1584, 'Jack_Morgane', 522, 1000000, 0, 1, 'None', 91, 993.713, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2318, 868, 'YASSIN_RESTOVA', 429, 9000000, 0, 1, 'None', 100, 1000, 1630.02, -1085.24, 23.546, 270.436, 128, 0, -1, NULL, 0, 0, 18649, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2319, 2789, 'SI_ALI', 429, 9000000, 0, 0, 'None', 83, 786.093, 1267.09, -1385.01, 12.984, 81.855, 2, 1, -1, NULL, 0, 0, 18652, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2321, 1584, 'Jack_Morgane', 429, 9000000, 0, 1, 'None', 99, 1000, 350.139, -1514.61, 32.724, 143.416, 1, 0, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2329, 765, 'MICHOO_L3ANTEEZ', 487, 15550000, 0, 1, 'None', 18, 684.355, 2531.28, -1678.2, 20.092, 79.859, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2330, 1308, 'Musashi_Lucas', 593, 10000000, 0, 1, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2331, 2655, 'JAMAL_R', 411, 1000000, 0, 0, 'None', 86, 300, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2332, 2626, 'ztla_49', 496, 250000, 0, 0, 'None', 100, 300, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2333, 695, 'LEGOS_PADRI', 468, 100000, 0, 1, 'None', 84, 961.627, 1220.89, -1322.25, 12.836, 83.045, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2334, 2775, 'aya_nn', 507, 300000, 0, 1, 'None', 100, 923.766, 393.322, -2084.15, 7.658, 325.432, 1, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2335, 2666, 'zoro_vip', 602, 650000, 4000, 0, 'None', 100, 837, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2336, 2666, 'zoro_vip', 527, 310000, 0, 0, 'None', 100, 757.853, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2337, 1660, 'T_RexX', 445, 300000, 0, 0, 'None', 20, 1000, 1221.3, -1321.32, 13.044, 172.868, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2338, 972, 'YSF_Mexico', 510, 10000, 0, 0, 'None', 20, 996.197, 1955.82, -2362.73, 13.15, 141.489, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2339, 2579, 'Firas_Millions', 560, 550000, 0, 1, 'None', 99, 741.358, 979.329, -916.794, 41.195, 182.351, 0, 0, 2, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1083, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 75, 10, 0, 0, 31, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2340, 2579, 'Firas_Millions', 522, 1000000, 0, 0, 'None', 81, 879, 2201.68, -1177.87, 25.458, 180.403, 175, 175, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 31, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2341, 2578, 'Zbelbola_Millions', 522, 1000000, 0, 0, 'None', 63, 991.011, 959.22, -920.683, 45.335, 3.567, 249, 249, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2342, 0, 'Nobody', 416, 0, 0, 1, 'None', 100, 1000, 2033.51, -1440.8, 17.398, 92.283, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2343, 0, 'Nobody', 416, 0, 0, 1, 'None', 100, 1000, 2033.51, -1436.28, 17.345, 96.821, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2344, 0, 'Nobody', 487, 0, 0, 1, 'None', 100, 1000, 2016.02, -1414.02, 17.17, 120.214, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2345, 1471, 'IRT_WLD_ALI', 436, 250000, 0, 0, 'None', 72, 707.349, 1308.5, -640.885, 108.325, 195.856, 2, 1, -1, NULL, 0, 0, 18652, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2346, 793, 'KHALIL_ESCOBAR', 411, 1000000, 0, 1, 'None', 95, 983.648, 1272.05, -1545.69, 13.223, 90.126, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2347, 1973, 'PECASO_XM8', 603, 850000, 0, 0, 'None', 93, 881.047, 2110.94, -1782.76, 13.226, 177.943, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2348, 877, 'L7AJ_ZIAD', 560, 550000, 0, 0, 'None', 82, 809.26, 1032.28, -642.057, 119.822, 9.625, 2, 2, -1, NULL, 0, 0, 18652, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 1028, 1075, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2349, 2626, 'ztla_49', 412, 250000, 0, 1, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2350, 929, 'TANGAWI_', 560, 550000, 0, 0, '5', 20, 1000, 1995.32, -1760.28, 13.25, 90.829, 179, 179, 1, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1075, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2351, 2235, 'RINOX_IRT', 522, 1000000, 0, 0, 'None', 98, 310.013, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2352, 929, 'TANGAWI_', 411, 1000000, 0, 0, 'None', 20, 1000, 562.397, -1283.85, 17.0007, 0, 6, 6, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1098, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2353, 2603, 'GLO_OMY', 411, 1000000, 0, 1, 'None', 20, 828.78, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2354, 2694, 'FATI_V2.1', 560, 550000, 0, 0, 'None', 100, 1000, 2054.22, -1763.66, 13.212, 268.232, 126, 126, -1, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1083, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2355, 2049, 'L3ALAWI_STREX', 560, 550000, 0, 0, 'None', 84, 726.686, 557.867, -1283.98, 17.0007, 0, 2, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2356, 929, 'TANGAWI_', 560, 550000, 0, 0, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 175, 175, -1, NULL, 0, 0, 18651, 1, 3, 1138, 0, 1032, 0, 0, 0, 0, 1075, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2357, 2715, 'L9ATAL__ZRZOOR', 411, 1000000, 0, 0, 'None', 94, 622.919, 367.311, -2075.62, 7.563, 270.357, 1, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2358, 2001, 'simo__rdr', 507, 300000, 0, 1, 'None', 98, 1000, 1222.87, -1424.23, 13.175, 356.307, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2359, 2578, 'Zbelbola_Millions', 471, 70000, 0, 0, 'None', 91, 817.267, 964.897, -931.018, 41.908, 184.801, 175, 175, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 75, 0, 0, 24, 31, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2360, 1494, 'AZIZ_LFERDA', 468, 100000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2361, 1494, 'AZIZ_LFERDA', 468, 100000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2362, 929, 'TANGAWI_', 468, 100000, 0, 0, 'None', 87, 976.084, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2363, 1494, 'AZIZ_LFERDA', 468, 100000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2364, 732, 'DANGER_', 468, 100000, 0, 0, 'None', 87, 717.833, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2365, 1494, 'AZIZ_LFERDA', 468, 100000, 0, 0, 'None', 19, 904.925, 2781.08, -1602.12, 10.591, 175.417, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2366, 1494, 'AZIZ_LFERDA', 468, 100000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2367, 1494, 'AZIZ_LFERDA', 468, 100000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2368, 2542, 'Simo_bakkali', 411, 1000000, 0, 1, 'None', 100, 806.704, 2796.06, -1580.33, 10.662, 84.739, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2370, 407, 'oussama_r', 411, 1000000, 0, 1, 'None', 95, 1000, 2593.25, -950.847, 81.121, 193.86, 0, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2371, 2579, 'Firas_Millions', 471, 70000, 0, 0, 'None', 15, 60741, 2202.25, -1180.15, 25.372, 93.657, 1, 1, -1, NULL, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 24, 31, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2373, 1804, 'CaTaNa_Ta', 471, 70000, 0, 0, 'None', 0, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2374, 1983, 'MAFIA_jordan', 411, 1000000, 0, 0, 'None', 6, 251, 1758.94, -1446.63, 12.908, 296.187, 1, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2375, 1983, 'MAFIA_jordan', 522, 1000000, 0, 1, 'None', 89, 854.682, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2376, 1660, 'T_RexX', 522, 1000000, 0, 0, 'None', 20, 988.517, 1232.49, -1361.28, 12.732, 173.081, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2377, 2334, 'zoro_abdou', 521, 120000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2378, 2334, 'zoro_abdou', 422, 450000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2379, 2703, 'ANAS_MARKO', 581, 50000, 0, 0, 'None', 98, 985, 533.235, -1281.26, 16.835, 97.782, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2380, 2436, 'Luos_XD', 424, 550000, 0, 1, 'None', 91, 948.968, 1793.35, -1060.92, 23.742, 353.95, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2381, 2229, 'MOHAMED_1', 581, 50000, 0, 0, 'None', 82, 697.193, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2382, 531, 'LMCH__MI', 545, 350000, 0, 1, 'None', 75, 1000, 381.445, -2047.06, 7.652, 107.382, 79, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2383, 2408, 'amine_404', 463, 90000, 0, 0, 'None', 20, 693, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2384, 2683, '_SALAH_', 581, 50000, 0, 1, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2385, 2704, 'Salah_sas', 540, 300000, 0, 0, 'None', 20, 1000, 1192.48, -1324.97, 13.259, 359.217, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2386, 1963, 'HAPPE__BIN', 585, 300000, 0, 1, 'None', 89, 342.179, 1220.03, -1328.41, 12.751, 2.221, 1, 1, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 29, 27, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2388, 2703, 'ANAS_MARKO', 439, 500000, 0, 1, 'None', 20, 863.927, 533.185, -1283.55, 17.138, 98.515, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2389, 2678, 'lm9ardn_l7away', 581, 50000, 0, 1, 'None', 100, 870.41, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2390, 2789, 'SI_ALI', 506, 0, 0, 1, 'None', 77, 733.168, 1040.36, -641.553, 119.822, 176.182, 175, 175, 3, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2391, 2721, 'POP_SMOKE', 481, 2500, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2392, 1471, 'IRT_WLD_ALI', 533, 400000, 0, 0, 'None', 100, 1000, 1621.54, -1098.24, 23.615, 269.311, 2, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2393, 2523, 'med_said', 445, 300000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2394, 2523, 'med_said', 555, 450000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2395, 2210, 'MADARA_R1', 581, 50000, 0, 0, 'None', 63, 501.263, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2396, 472, 'IMAD_LUCIANO', 487, 0, 0, 1, 'None', 99, 343.384, 2529.34, -1678.44, 20.116, 95.392, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2397, 2706, 'MOTO__ZB', 412, 250000, 0, 0, 'None', 100, 1000, 1240.81, -1365.04, 13.005, 276.749, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2398, 2641, 'MOUAD_MESSI', 506, 0, 0, 1, 'None', 100, 961.994, 1153.95, -1401.33, 13.401, 91.459, 1, 1, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2399, 1859, 'Younsse_Allamy', 468, 100000, 0, 0, 'None', 98, 895.734, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2400, 3648, 'adel_med', 586, 50000, 0, 0, 'None', 100, 575.453, 1216.6, -1420.35, 12.812, 8.434, 3, 3, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2401, 1829, 'https_tweets', 506, 0, 0, 0, 'None', 100, 1000, 1323.35, -1555.83, 13.547, 134.075, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2402, 1279, 'TANJAWI__7ARBI__IS__ON', 559, 0, 0, 0, 'None', 20, 251, 1211.83, -1425.59, 12.92, 1.81, 180, 180, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2403, 1192, 'I_NAMOSE', 558, 0, 0, 1, 'None', 97, 1000, 250.989, -1359.77, 52.69, 304.357, 1, 1, 2, NULL, 0, 0, 18652, 1, 3, 1163, 0, 1088, 1094, 0, 1010, 1089, 1085, 0, 1087, 1166, 1168, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2404, 1519, 'Boonina_Millions', 562, 0, 0, 0, 'None', 100, 999.623, 289.263, -1175.33, 80.575, 310.346, 175, 175, 2, NULL, 0, 0, 18650, 0, 3, 1147, 0, 1038, 1040, 0, 1010, 1034, 1078, 0, 0, 1171, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2405, 1279, 'JO9LI__RPT', 558, 0, 0, 1, 'None', 99, 684, 1803.96, -1899.6, 13.012, 85.271, 1, 1, 1, NULL, 0, 0, 18652, 1, 3, 1164, 0, 1091, 0, 0, 1010, 0, 1081, 0, 1087, 1166, 1168, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2406, 2655, 'JAMAL_R', 600, 270000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2407, 2655, 'JAMAL_R', 462, 25000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2408, 2210, 'MADARA_R1', 545, 350000, 0, 0, 'None', 93, 881.966, 552.818, -1284.13, 17.0007, 0, 1, 0, -1, NULL, 0, 0, 18647, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2409, 2479, 'ELHOUCINE_UE', 468, 100000, 0, 1, 'None', 100, 926.86, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2410, 3029, 'WLD_LHAJ_1', 560, 0, 0, 1, 'None', 100, 887.184, 1241.14, -1308.76, 12.826, 176.388, 126, 126, 0, NULL, 0, 0, 18651, 1, 3, 1139, 0, 1032, 0, 0, 1010, 1028, 1075, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2411, 765, 'NIZAR_XVILO', 559, 0, 0, 1, 'nizar mkwed ', 99, 52992.1, 1086.93, -1347.29, 13.478, 90.047, 137, 2, 0, NULL, 0, 0, 18649, 1, 3, 1162, 0, 1068, 0, 0, 1010, 1065, 1077, 0, 1087, 1160, 1161, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2412, 1279, 'TANJAWI__7ARBI__IS__ON', 451, 0, 0, 1, 'None', 100, 1000, 1671.14, -2338.57, 1535.19, 268.895, 132, 132, -1, NULL, 3, 2000074, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2413, 1973, 'PECASO_XM8', 451, 0, 0, 1, 'None', 57, 654.241, 1086.48, -1338.16, 13.551, 89.255, 91, 91, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2414, 2533, 'amine_smoker', 586, 50000, 0, 0, 'None', 100, 978.046, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2415, 2594, 'Bar9lo_Tn', 463, 90000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2416, 1519, 'SOOOOOOOONIIIIICE_', 451, 0, 0, 0, 'None', 95, 982.016, 299.782, -1186.55, 80.563, 313.973, 0, 0, -1, NULL, 0, 0, 18648, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2417, 1471, 'IRT_WLD_ALI', 463, 90000, 0, 1, 'None', 99, 926, 1675.11, -1126.67, 23.447, 273.826, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2418, 2375, 'NINJA_NETWORK', 555, 450000, 0, 0, 'None', 20, 1000, 1169.71, -1104.13, 24.611, 1.084, 2, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 27, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2419, 1198, 'Hamza_Hercolano', 586, 50000, 0, 0, 'None', 19, 950, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2420, 2706, 'MOTO__ZB', 461, 1000000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2421, 2743, 'cj_yassine', 468, 100000, 0, 0, 'None', 58, 876.82, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2422, 3151, 'taoufik_yagami', 521, 1200000, 0, 1, 'None', 100, 663.705, 2589.17, -949.856, 80.947, 192.635, 0, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2423, 0, 'Nobody', 411, 10000000, 0, 0, 'None', 100, 1000, 2792.56, -1620.57, 10.618, 73.51, 6, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2424, 2789, 'SI_ALI', 487, 15550000, 0, 1, 'None', 100, 1000, 1653.06, -1134.85, 24.083, 109.905, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2425, 1709, 'SUPRA_MK4', 559, 0, 0, 0, 'None', 77, 782.19, 1776.93, -1906.43, 12.972, 272.456, 1, 1, 0, NULL, 0, 0, 18649, 0, 3, 1162, 0, 1067, 1071, 0, 1010, 1066, 1078, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 30, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2426, 2210, 'MADARA_R1', 589, 270000, 0, 1, 'None', 100, 998.343, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2427, 1192, 'I_NAMOSE', 429, 9000000, 0, 1, 'None', 85, 863, 279.383, -1369.89, 52.744, 36.714, 1, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1009, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2428, 2770, 'SI_LHAJ', 555, 450000, 0, 1, 'None', 87, 883.54, 1242.52, -1366.15, 12.852, 294.788, 0, 175, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2429, 2770, 'SI_LHAJ', 533, 400000, 0, 1, 'None', 100, 985.923, 1116.94, -1360.89, 13.531, 277.191, 198, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2430, 2408, 'amine_404', 521, 1200000, 0, 0, 'None', 20, 816.277, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2431, 2017, 'ZENSU_ZOLDYK', 481, 2500, 0, 1, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2432, 2742, 'saad_2033', 463, 90000, 0, 0, 'None', 87, 647.337, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2433, 2443, 'BARBARA_CHAR', 463, 90000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2434, 3374, 'CJ_', 445, 300000, 0, 1, 'None', 100, 982.815, 1241.88, -1355.05, 13.003, 89.879, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1098, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2435, 1388, 'Finix_boneli', 461, 1000000, 0, 0, 'None', 20, 915, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2436, 1157, 'ISCOBAR_WOLF', 581, 50000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2437, 555, 'LVASTO_Alvaro', 509, 2500, 0, 1, 'None', 100, 981, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2438, 1946, 'Mimo200p_9', 521, 1200000, 0, 0, 'None', 100, 981.234, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2439, 1577, 'SANJI_XVILO', 527, 310000, 0, 0, 'None', 52, 399.498, 1104.09, -1388.01, 13.369, 270.098, 6, 6, 0, NULL, 0, 0, 18650, 1, 0, 1014, 0, 0, 1017, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2440, 2545, 'SHELBY_TALIANI', 510, 10000, 0, 1, 'None', 100, 928.516, 1144.41, -1330.5, 13.434, 214.986, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2441, 2299, '[BRZ]LUFFY_L7GAR', 424, 550000, 0, 0, 'None', 100, 814.83, 1211.44, -1425.84, 13.164, 1.336, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2442, 2772, 'PABLO_LMICROBE', 439, 500000, 0, 1, 'None', 97, 58768.3, 2278.96, -1111.73, 37.829, 338.383, 0, 0, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2443, 2761, 'ali_abt', 405, 300000, 0, 1, 'None', 20, 1000, 1811.78, -1115.99, 23.953, 267.883, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2444, 2380, 'RIVALDO_XV', 509, 2500, 0, 1, 'None', 20, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2445, 555, 'LVASTO_Alvaro', 412, 250000, 0, 1, 'None', 20, 658.92, 2052.06, -1769.27, 13.328, 179.625, 134, 2, 3, NULL, 0, 0, 18651, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2446, 2380, 'RIVALDO_XV', 468, 100000, 0, 1, 'None', 20, 918.927, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2447, 2385, 'Falcon_Millions', 600, 270000, 0, 0, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2448, 2380, 'RIVALDO_XV', 481, 2500, 0, 0, 'None', 20, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2449, 2552, 'zoro_10', 600, 270000, 0, 1, 'None', 53, 762.561, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2450, 2820, 'baaby_gaang', 468, 100000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2451, 2588, 'ROBIN_CHP', 547, 300000, 0, 1, 'None', 100, 967.931, 332.878, -1537.84, 32.964, 146.721, 3, 3, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2453, 1106, 'PSIKA_XX', 411, 0, 0, 0, 'None', 79, 926.493, 2205.18, -1176.84, 25.423, 267.2, 154, 154, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 23, 23, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2454, 3674, 'soufian_lm10', 541, 0, 0, 1, 'None', 86, 345.632, 1219.88, -1369.25, 12.794, 94.656, 3, 3, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2455, 1584, 'Ryder_Grv', 536, 3500000, 0, 0, 'None', 100, 879.605, 344.691, -1521.56, 32.97, 140.92, 0, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 1128, 1107, 0, 1010, 0, 1085, 0, 1087, 1181, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2456, 1709, 'SUPRA_MK4', 487, 15550000, 0, 0, 'None', 100, 787.772, 1777.82, -1918.66, 13.563, 268.901, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2457, 2174, 'vergas__', 589, 270000, 0, 0, 'None', 16, 887, 562.397, -1283.85, 17.0007, 0, 3, 3, 0, NULL, 0, 0, 18647, 1, 1, 0, 0, 0, 0, 1024, 1010, 0, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2458, 2566, 'jawad_bada', 462, 25000, 0, 0, 'None', 20, 788.348, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2459, 2641, 'MOUAD_MESSI', 549, 300000, 0, 1, 'None', 100, 898.316, 1515.99, -839.043, 66.753, 79.178, 2, 2, -1, NULL, 0, 0, 18647, 1, 0, 1023, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2460, 1471, 'IRT_WLD_ALI', 545, 350000, 0, 1, 'None', 100, 737.862, 1328.49, -632.494, 108.946, 200.026, 2, 2, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2461, 2641, 'MOUAD_MESSI', 445, 300000, 0, 1, 'None', 100, 934.415, 1660.26, -2343.44, 1535.36, 265.872, 3, 3, -1, NULL, 3, 2000075, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2462, 1973, 'PECASO_XM8', 576, 330000, 0, 0, 'None', 100, 872.142, 552.818, -1284.13, 17.0007, 0, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2463, 868, 'YASSIN_RESTOVA', 487, 15550000, 0, 0, 'None', 100, 898.807, 2192.77, -1185.4, 33.705, 355.878, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2464, 2742, 'saad_2033', 521, 1200000, 0, 0, 'None', 76, 942.612, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2465, 3376, 'Ruok_Sense', 560, 5500000, 0, 0, 'None', 77, 590.387, 1102.4, -1386.95, 13.406, 91.015, 0, 0, 1, NULL, 0, 0, 18648, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 1029, 1075, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2466, 2214, '[GLD]PABLO_7AGAR', 576, 330000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2467, 2214, '[GLD]PABLO_7AGAR', 422, 450000, 0, 0, 'None', 100, 980.758, 1228.77, -1371.2, 13.156, 359.188, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2468, 2214, '[GLD]PABLO_7AGAR', 436, 250000, 0, 0, 'None', 100, 972.427, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2469, 2214, '[GLD]PABLO_7AGAR', 589, 270000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2470, 2214, '[GLD]PABLO_7AGAR', 458, 280000, 0, 0, 'None', 100, 989.021, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2471, 2214, '[GLD]PABLO_7AGAR', 479, 280000, 0, 0, 'None', 100, 911.819, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2472, 2214, '[GLD]PABLO_7AGAR', 404, 250000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2473, 2214, '[GLD]PABLO_7AGAR', 545, 350000, 0, 0, 'None', 20, 700.609, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2474, 2329, 'walid_moris', 418, 450000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2475, 1962, 'fouade_2023', 418, 450000, 0, 1, 'None', 88, 669.424, 1282.61, -1379.05, 13.377, 179.452, 158, 158, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2476, 1471, 'IRT_WLD_ALI', 482, 4500000, 0, 1, 'None', 98, 672.348, 1101.61, -1412.79, 13.666, 356.969, 0, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2477, 1012, 'Akram_Messi', 500, 4500000, 0, 1, 'None', 100, 971.387, 1220.42, -1425.29, 13.44, 359.165, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2478, 1859, 'Younsse_Allamy', 401, 300000, 0, 0, 'None', 100, 976.481, 1983.84, -1760.65, 13.502, 37.98, 1, 2, -1, NULL, 0, 0, 18648, 1, 0, 1003, 0, 1006, 0, 0, 0, 1020, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2479, 2868, 'FLASH_LM9AWAD', 481, 2500, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2480, 2214, '[GLD]PABLO_7AGAR', 521, 1200000, 0, 0, 'None', 100, 964.493, 2588.95, -949.966, 80.95, 187.916, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2481, 2214, '[GLD]PABLO_7AGAR', 461, 1000000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2482, 2214, '[GLD]PABLO_7AGAR', 471, 70000, 0, 0, 'None', 100, 1000, 1231.57, -1350.26, 12.781, 330.783, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2483, 2214, '[GLD]PABLO_7AGAR', 510, 10000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2484, 1973, 'PECASO_XM8', 429, 9000000, 2500, 0, 'None', 100, 975.594, 859.562, -1532.09, 13.234, 268.753, 109, 39, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1082, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2485, 1501, 'LUFFY_XVILO', 487, 15550000, 0, 1, 'None', 87, 16219, 1108.65, -1356.12, 23.629, 176.176, 6, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2486, 1279, 'JO9LI__RPT', 429, 9000000, 0, 1, 'None', 83, 942, 1959.24, -1754.5, 13.014, 270.031, 175, 0, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2487, 0, 'Nobody', 411, 10000000, 0, 0, 'None', 100, 1000, 968.622, -925.465, 45.493, 1.28, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2488, 0, 'Nobody', 541, 9000000, 0, 0, 'None', 100, 1000, 973.501, -925.766, 45.396, 4.033, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2489, 0, 'Nobody', 429, 9000000, 0, 0, 'None', 100, 1000, 950.613, -923.188, 43.735, 179.885, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2490, 877, 'L7AJ_ZIAD', 429, 9000000, 0, 1, 'None', 65, 863.464, 1031.17, -634.486, 119.814, 279.474, 2, 1, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2491, 1285, 'WALD_FAVELAS', 429, 9000000, 0, 0, 'None', 64, 1000, 1231.17, -1419.97, 13.011, 28.953, 6, 9, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2492, 0, 'Nobody', 487, 15550000, 0, 0, 'None', 100, 1000, 974.199, -916.537, 45.942, 93.305, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2493, 1237, 'MOTCHA_LOTch', 581, 50000, 0, 0, 'None', 42, 928.702, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2494, 3358, 'ayman_robnex', 581, 50000, 0, 1, 'None', 100, 859, 1225.85, -1414.54, 12.922, 0.942, 8, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2495, 2533, 'amine_smoker', 580, 300000, 0, 1, 'None', 20, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2496, 1477, 'simo_mohmed', 586, 50000, 0, 0, 'None', 43, 636.598, 1065.95, -1317.05, 12.903, 356.329, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2497, 653, 'MADA_xvilo', 492, 270000, 0, 1, 'None', 100, 875.259, 1460.57, -1610.1, 13.829, 358.1, 2, 1, -1, NULL, 0, 0, 0, 0, 0, 1000, 0, 1006, 0, 0, 1010, 0, 1076, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2498, 1973, 'PECASO_XM8', 420, 400000, 0, 1, 'None', 18, 959.203, 1989.87, -1727.41, 13.962, 270.918, 3, 3, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2499, 2548, 'KRAY_TIN', 586, 50000, 0, 1, 'None', 74, 1000, 2205.12, -1160.54, 25.255, 268.401, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2500, 1279, 'JO9LI__RPT', 506, 0, 0, 1, 'None', 99, 914.537, 1777.56, -1915.86, 13.09, 268.992, 175, 175, -1, NULL, 0, 0, 18647, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2501, 1471, 'IRT_WLD_ALI', 487, 0, 0, 1, 'None', 100, 891.645, 1345.67, -640.093, 114.2, 130.131, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2502, 3148, 'ALAA_VINSMOKE', 589, 270000, 0, 0, 'None', 99, 635.787, 1116.27, -1355.76, 13.719, 347.708, 0, 0, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 1006, 1017, 0, 1008, 1020, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2503, 2974, 'Mr_Strand', 551, 300000, 0, 1, 'None', 20, 648.356, 79.202, -1516.16, 4.201, 228.281, 198, 175, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2504, 1106, 'PSIKA_XX', 550, 300000, 0, 1, 'None', 83, 1000, 2451.23, -2117.67, 13.335, 351.026, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 1003, 1005, 1006, 0, 0, 1010, 1019, 1075, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2505, 1946, 'Mimo200p_9', 589, 270000, 0, 1, 'None', 100, 975.142, 1220.32, -1359.32, 12.826, 266.491, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 1005, 1006, 0, 0, 1010, 1020, 1081, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2506, 1369, 'L3alawi_OTCHIHA', 412, 250000, 0, 0, 'None', 14, 962.957, 1545.69, -1613.76, 13.221, 85.892, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2507, 1785, 'carlos_bertone', 555, 450000, 0, 1, 'None', 20, 251, 1746.55, -1057.06, 23.641, 230.513, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2508, 2299, '[BRZ]LUFFY_L7GAR', 555, 450000, 0, 1, 'None', 100, 911, 1208.19, -1426.11, 13.059, 356.661, 9, 9, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2509, 2913, 'Lucas_Alferdo', 426, 300000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2511, 1448, 'antnony_1313', 589, 270000, 0, 1, 'None', 100, 1000, 1241.41, -1360.6, 12.78, 85.83, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 1005, 1006, 1017, 0, 1010, 1020, 1075, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2512, 2214, '[GLD]PABLO_7AGAR', 600, 270000, 0, 0, 'None', 19, 969.424, 1242.37, -1374.69, 12.885, 90.957, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2513, 1279, 'JO9LI__RPT', 474, 280000, 0, 0, 'None', 100, 775.738, 1241.99, -1378.5, 12.929, 101.004, 136, 136, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2514, 407, 'oussama_r', 436, 250000, 0, 1, 'None', 100, 996.365, 1215.77, -1426.08, 13.143, 1.488, 200, 1, -1, NULL, 0, 0, 0, 0, 0, 1003, 0, 0, 0, 1013, 1010, 1019, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2515, 2214, '[GLD]PABLO_7AGAR', 410, 300000, 0, 1, 'None', 20, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2516, 3158, 'trock_bangala', 491, 270000, 0, 1, 'None', 100, 868.655, 1256.62, -1432.2, 13.285, 86.093, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2517, 1963, 'HAPPE__BIN', 579, 3100000, 0, 0, 'None', 97, 994.18, 1811.07, -1120.94, 24.005, 270.034, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29, 31, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(2518, 2001, 'simo__rdr', 491, 270000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2519, 2712, 'ABDE_LKHALQ', 445, 300000, 0, 0, 'None', 99, 824.038, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2520, 2712, 'ABDE_LKHALQ', 586, 50000, 0, 0, 'None', 99, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2521, 2712, 'ABDE_LKHALQ', 471, 70000, 0, 0, 'None', 99, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2523, 1369, 'L3alawi_OTCHIHA', 533, 400000, 0, 1, 'None', 98, 888.092, 2003.12, -1766.64, 13.756, 179.026, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2524, 2533, 'amine_smoker', 555, 450000, 0, 1, 'None', 100, 865.968, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2525, 894, 'TALIANI_WOLF', 589, 270000, 0, 0, 'None', 100, 756.367, 318, -1788.2, 4.337, 180.022, 79, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 1005, 1006, 0, 1024, 1010, 1020, 1081, 0, 0, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2526, 653, 'MADA_xvilo', 589, 270000, 0, 1, 'None', 100, 988.176, 1445.15, -1607.29, 13.671, 265.389, 198, 0, -1, NULL, 0, 0, 18648, 1, 0, 0, 1005, 1006, 1017, 0, 1010, 1020, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2527, 868, 'YASSIN_RESTOVA', 589, 270000, 0, 0, 'None', 100, 747, 1621.5, -1085.45, 23.495, 91.484, 198, 0, 1, NULL, 0, 0, 18648, 1, 0, 0, 1005, 1006, 0, 0, 1010, 1020, 1075, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2528, 2889, 'VEGAS_JNYN', 560, 5500000, 0, 1, 'None', 20, 854.355, 1948.9, -1723.54, 13.251, 0.768, 79, 7, -1, NULL, 0, 0, 18648, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 1028, 1076, 0, 0, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2529, 2889, 'VEGAS_JNYN', 429, 9000000, 0, 0, 'None', 20, 614.245, 1219.78, -1366.12, 12.802, 248.044, 128, 0, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2530, 1012, 'Akram_Messi', 581, 50000, 0, 1, 'None', 100, 904.714, 1214, -1426.76, 12.98, 4.715, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2531, 1815, '@islam_07.', 554, 400000, 0, 1, 'None', 100, 781.925, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2532, 1815, '@islam_07.', 400, 320000, 0, 1, 'None', 20, 984.494, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2533, 1192, 'I_NAMOSE', 422, 450000, 0, 0, 'None', 94, 892.384, 271.549, -1336.67, 53.602, 48.755, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2534, 2908, 'bos_7liwa', 401, 300000, 0, 1, 'None', 90, 434.617, 707.751, -1744.28, 13.949, 252.197, 77, 77, 3, NULL, 0, 0, 18650, 1, 3, 1001, 1005, 1006, 0, 1013, 1010, 1020, 1078, 0, 0, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2535, 975, 'supra_out', 506, 0, 0, 1, 'None', 97, 1000, 1241.94, -1365.45, 12.869, 105.54, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1082, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2536, 2443, 'BARBARA_CHAR', 521, 1200000, 0, 1, 'None', 94, 998.744, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2537, 2578, 'Zbelbola_Millions', 549, 300000, 0, 0, 'None', 18, 982.552, 979.979, -938.907, 40.928, 178.361, 43, 43, -1, NULL, 0, 0, 18647, 1, 3, 1023, 1012, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2538, 1761, 'I_NAMOSE', 549, 300000, 0, 0, 'None', 100, 1000, 1280.6, -1338.15, 13.05, 90.484, 3, 3, 0, NULL, 0, 0, 18647, 1, 0, 1003, 1011, 0, 1017, 0, 1010, 1020, 1079, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2541, 1285, 'WALD_FAVELAS', 429, 9000000, 0, 1, 'None', 92, 831.642, 1086.97, -1362.29, 13.49, 270.643, 9, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2542, 2578, 'Zbelbola_Millions', 580, 300000, 0, 0, 'None', 19, 971.207, 988.973, -908.019, 41.987, 181.682, 0, 0, -1, NULL, 0, 0, 18650, 1, 3, 1001, 0, 1006, 1017, 0, 1010, 1020, 1075, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2543, 1499, 'RWAYZA_SBK', 510, 10000, 0, 0, 'None', 100, 569, 2271.04, -1103.72, 37.566, 344.069, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2544, 1592, 'TOXIC_UH', 510, 10000, 0, 1, 'None', 100, 948.267, 2273.22, -1104.45, 37.583, 327.784, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2545, 1471, 'IRT_WLD_ALI', 502, 0, 0, 1, 'None', 98, 786.398, 1347.23, -625.647, 108.968, 197.018, 175, 175, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2546, 0, 'Nobody', 541, 0, 0, 0, 'None', 100, 1000, 2288.88, -1115.53, 37.602, 67.972, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2547, 0, 'Nobody', 541, 0, 0, 0, 'None', 100, 1000, 2290.13, -1112.58, 37.601, 66.389, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2548, 0, 'Nobody', 562, 0, 0, 0, 'None', 100, 1000, 2273.92, -1106.24, 37.636, 154.72, 1, 1, 1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2549, 2578, 'Zbelbola_Millions', 492, 270000, 0, 1, 'None', 95, 977.693, 2273.77, -1107.72, 37.758, 156.217, 158, 158, -1, NULL, 0, 0, 18647, 1, 2, 1000, 1005, 1006, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2550, 1593, 'Khalil__XP__XX0', 419, 250000, 0, 0, 'None', 100, 929.761, 285.425, -1526.44, 24.352, 235.473, 1, 1, -1, NULL, 0, 0, 18647, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2551, 2690, 'PEDRO_VGS', 419, 250000, 0, 0, 'None', 100, 784.488, 1280.77, -1333.14, 13.169, 91.441, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2552, 2496, 'zri9a_genova77', 461, 1000000, 0, 0, 'None', 100, 841.749, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2553, 1587, 'ALI_WINs', 481, 2500, 0, 0, 'None', 100, 839, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1097, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2554, 1399, 'achraf_nh', 411, 10000000, 0, 0, 'None', 70, 716.282, 1104.12, -1413.32, 13.315, 359.367, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2555, 1308, 'Musashi_Lucas', 487, 15550000, 0, 0, 'None', 61, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2556, 0, 'Nobody', 522, 10000000, 0, 1, 'None', 100, 1000, 966.648, -913.431, 45.336, 181.914, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2557, 0, 'Nobody', 412, 250000, 0, 0, 'None', 100, 1000, 964.377, -925.251, 45.604, 2.536, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2558, 531, 'LMCH__MI', 496, 250000, 0, 0, 'None', 11, 405.788, 1221.77, -1370.81, 12.885, 105.707, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2559, 2001, 'simo__rdr', 445, 300000, 0, 1, 'None', 98, 903.018, 1367.69, -1723.72, 13.423, 77.864, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2560, 531, 'LMCH__MI', 547, 300000, 0, 0, 'None', 0, 634.241, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2561, 2001, 'simo__rdr', 468, 100000, 0, 0, 'None', 75, 743, 860.337, -601.641, 18.09, 262.578, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2562, 2908, 'bos_7liwa', 471, 70000, 0, 1, 'None', 86, 47782.7, 600.287, -1220.22, 17.459, 306.915, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2563, 2797, 'LEO___________MESSI', 566, 300000, 0, 0, 'None', 76, 723.165, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2564, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1255.65, -1822.07, 13.089, 269.878, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2565, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1255.08, -1824.46, 13.079, 267.207, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2566, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1254.91, -1826.92, 13.075, 266.316, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2567, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1254.91, -1829.48, 13.094, 260.803, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2568, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1255.12, -1832.16, 13.08, 264.669, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2569, 329, 'DON_SMOKE', 581, 50000, 0, 1, 'None', 17, 953.836, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2570, 2867, 'SALMA_', 545, 350000, 0, 1, 'None', 77, 251, 1147.4, -1413.12, 13.487, 359.157, 233, 233, 0, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2571, 2761, 'ali_abt', 463, 90000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2572, 467, 'Ilyas_RPT', 468, 100000, 0, 1, 'None', 98, 998.054, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2573, 1380, 'nobyx_henderson', 468, 100000, 0, 1, 'None', 12, 709, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2574, 329, 'DON_SMOKE', 461, 1000000, 0, 1, 'None', 13, 940.029, 382.536, -2079.05, 7.359, 93.791, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2575, 329, 'DON_SMOKE', 589, 270000, 0, 1, 'None', 100, 726.006, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2576, 2761, 'ali_abt', 468, 100000, 0, 1, 'None', 20, 855.917, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2577, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 864.082, -1254.55, 14.548, 270.844, 123, 123, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2578, 2017, 'ZENSU_ZOLDYK', 468, 100000, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2579, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 863.872, -1250.94, 14.566, 270.78, 123, 123, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2580, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 863.855, -1247.27, 14.565, 270.246, 123, 123, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2582, 1519, '44_', 506, 0, 0, 1, 'supra', 99, 1000, 1670.92, -2344.06, 1535.14, 88.84, 0, 0, 1, NULL, 3, 2000055, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2583, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 866.23, -586.193, 17.766, 85.593, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2584, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 866.625, -580.804, 17.916, 86.992, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2585, 0, 'Nobody', 413, 0, 0, 0, 'None', 100, 1000, 851.421, -580.25, 18.324, 180.079, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2586, 0, 'Nobody', 461, 0, 0, 0, 'None', 100, 1000, 838.927, -600.67, 18.003, 273.248, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2587, 0, 'Nobody', 461, 0, 0, 0, 'None', 100, 1000, 838.993, -601.428, 18.005, 273.247, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2588, 0, 'Nobody', 461, 0, 0, 0, 'None', 100, 1000, 838.861, -599.911, 18.001, 273.248, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2589, 0, 'Nobody', 461, 0, 0, 0, 'None', 100, 1000, 838.991, -599.156, 18.003, 276.131, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2590, 0, 'Nobody', 470, 0, 0, 1, 'None', 100, 1000, 83.225, -1552.23, 5.637, 266.09, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2591, 1501, 'LUFFY_XVILO', 559, 0, 2000, 0, 'None', 18, 715.544, 1111.1, -1381.75, 13.485, 82.209, 3, 3, 0, NULL, 0, 0, 18650, 1, 3, 1162, 0, 1068, 1071, 0, 1010, 1066, 1075, 0, 1087, 1160, 1159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2592, 2889, 'VEGAS_JNYN', 560, 5500000, 0, 1, 'None', 20, 1000, 1240.23, -1348.49, 12.869, 2.382, 1, 1, -1, NULL, 0, 0, 18647, 1, 0, 1139, 0, 1032, 1030, 0, 1010, 1028, 1075, 0, 0, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2593, 2497, 'perlo_amine', 482, 4500000, 0, 0, 'None', 100, 827.915, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2594, 2496, 'zri9a_genova77', 482, 4500000, 0, 0, 'None', 99, 852, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2596, 2954, 'ayman_roblex', 549, 300000, 0, 0, 'None', 100, 1000, 1283.86, -1349.08, 13.18, 87.647, 6, 6, 1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2597, 407, 'oussama_r', 429, 9000000, 0, 1, 'None', 100, 918.665, 2591.13, -942.567, 81.08, 193.373, 91, 119, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2598, 3402, 'ayman_rofix', 581, 50000, 0, 1, 'None', 83, 773.214, 1223.94, -1414.16, 12.908, 359.683, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2599, 868, 'YASSIN_RESTOVA', 560, 5500000, 1000, 0, 'None', 100, 996.389, 1621.26, -1089.38, 23.524, 91.4, 2, 2, -1, NULL, 0, 0, 18648, 0, 3, 1138, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2600, 3027, 'WLD_LAHJ_2', 586, 50000, 0, 0, 'None', 74, 642.067, 1188.94, -1330.53, 13.085, 89.842, 126, 126, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2601, 1519, 'Boonina_Millions', 487, 15550000, 0, 1, 'None', 100, 890.623, 278.94, -1151.97, 85.714, 227.419, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2602, 2715, 'L9ATAL__ZRZOOR', 521, 1200000, 0, 0, 'None', 99, 898.836, 1113.94, -1354.7, 13.421, 5.537, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2603, 772, 'mbli_blhxix', 411, 10000000, 0, 0, 'None', 91, 935, 2081.54, -1831.64, 13.079, 90.942, 0, 1, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2604, 3140, 'MOCCI_BLONK', 541, 9000000, 0, 0, 'None', 99, 1000, 1015.52, -1362.99, 12.985, 176.484, 110, 0, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2605, 1866, '@islam_07..', 576, 330000, 0, 1, 'None', 100, 989.233, 1086.78, -1353.23, 13.385, 86.203, 158, 158, -1, NULL, 0, 0, 18647, 0, 3, 0, 0, 0, 0, 0, 1010, 1135, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2606, 2380, 'RIVALDO_XV', 426, 300000, 0, 0, 'None', 70, 857.055, 1216.88, -1425.59, 13.069, 0.102, 126, 126, -1, NULL, 0, 0, 18651, 1, 0, 1001, 1005, 1006, 0, 0, 1010, 1021, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2607, 2968, 'ilyass_xx', 549, 300000, 0, 0, 'None', 100, 981.103, 2517.58, -1662.26, 13.809, 97.605, 226, 226, -1, NULL, 0, 0, 18649, 1, 3, 1003, 1012, 0, 1017, 0, 1010, 1018, 1079, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2608, 1866, '@islam_07..', 545, 350000, 0, 1, 'None', 98, 251, 1213.33, -1426.43, 13.2, 359.213, 226, 226, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2609, 653, 'MADA_xvilo', 555, 450000, 0, 0, 'None', 100, 749.422, 1451.24, -1612.97, 13.723, 1.085, 175, 175, 0, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2610, 1192, 'I_NAMOSE', 487, 15550000, 0, 0, 'None', 95, 723.693, 236.681, -1389.96, 53.287, 311.166, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2611, 663, 'WLD_NAMOSE', 487, 15550000, 0, 1, 'None', 87, 1000, 1278.21, -1365.4, 13.462, 96.012, 198, 3, -1, NULL, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2612, 1191, 'ZIZEWAR_X', 593, 10000000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2613, 1191, 'ZIZEWAR_X', 487, 15550000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2614, 653, 'MADA_xvilo', 426, 300000, 0, 1, 'None', 100, 760.002, 1455.65, -1610.76, 13.742, 353.06, 128, 1, -1, NULL, 0, 0, 18649, 0, 0, 1003, 1005, 1006, 0, 0, 1010, 1021, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2615, 1308, 'Musashi_Lucas', 452, 19550000, 0, 0, 'None', 100, 974.028, 227.485, -1900.41, -0.491, 359.758, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2616, 0, 'Nobody', 487, 0, 0, 0, 'None', 100, 1000, 2259.35, -1077.82, 56.337, 148.683, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2617, 2968, 'ilyass_xx', 535, 0, 0, 1, 'None', 100, 621.845, 2487.49, -1682.99, 13.101, 271.353, 137, 2, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2618, 2968, 'ilyass_xx', 506, 0, 0, 0, 'None', 93, 719.38, 1242.11, -1363.7, 12.864, 87.915, 137, 2, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2619, 1399, 'achraf_nh', 559, 0, 0, 1, 'None', 98, 1000, 1109.52, -1374.91, 13.478, 180.791, 128, 128, 0, NULL, 0, 0, 18650, 0, 0, 1162, 0, 1068, 1071, 0, 1010, 1065, 1079, 0, 1087, 1160, 1161, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2620, 2968, 'ilyass_xx', 451, 0, 0, 1, 'None', 100, 797.34, 2509.85, -1687.29, 13.223, 51.28, 137, 2, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2621, 2742, 'saad_2033', 400, 320000, 0, 0, 'None', 100, 967.703, 562.397, -1283.85, 17.0007, 0, 2, 2, 1, NULL, 0, 0, 18648, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2622, 2443, 'BARBARA_CHAR', 424, 550000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2623, 1192, 'I_NAMOSE', 555, 450000, 0, 1, 'None', 100, 994, 1207.51, -1425.76, 13.068, 358.096, 100, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2624, 3129, 'WLD_LHAJ_2', 545, 350000, 0, 0, 'None', 100, 1000, 1112.4, -1375.74, 13.672, 178.568, 2, 3, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2625, 2715, 'L9ATAL__ZRZOOR', 550, 300000, 0, 0, 'None', 96, 729.442, 996.09, -928.411, 41.996, 103.546, 3, 3, -1, NULL, 0, 0, 18650, 1, 0, 1003, 1005, 1006, 0, 0, 1010, 1020, 1079, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2626, 2580, 'Briwa_Millions', 496, 250000, 0, 0, 'None', 98, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2627, 2580, 'Briwa_Millions', 461, 1000000, 0, 0, 'None', 100, 1000, 978.946, -911.699, 41.101, 276.406, 2, 2, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2628, 2580, 'Briwa_Millions', 405, 300000, 0, 0, 'None', 96, 942, 981.726, -908.386, 41.962, 283.305, 194, 194, -1, NULL, 0, 0, 18650, 1, 3, 1014, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2629, 2580, 'Briwa_Millions', 471, 70000, 0, 0, 'None', 98, 824.501, 963.432, -931.171, 41.871, 182.472, 123, 123, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2630, 2580, 'Briwa_Millions', 418, 450000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2631, 1519, 'SOOOOOOOONIIIIICE_', 561, 0, 0, 1, 'None', 80, 2139000000, 294.288, -1148.85, 80.67, 134.268, 0, 0, 1, NULL, 0, 0, 18647, 1, 3, 1060, 0, 1061, 1062, 0, 1010, 1059, 0, 0, 1087, 1155, 1154, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2632, 3089, 'sfaa7_lmout', 461, 1000000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2633, 3110, '7liwaa_gang', 471, 70000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2634, 2662, 'Narkoos_49', 545, 350000, 0, 1, 'None', 100, 925.581, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2635, 1192, 'I_NAMOSE', 555, 450000, 0, 0, 'None', 100, 713, 562.397, -1283.85, 17.0007, 0, 6, 1, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2636, 877, 'L7AJ_ZIAD', 586, 50000, 0, 1, 'None', 97, 757.145, 294.728, -1338.71, 52.96, 19.6, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2637, 3133, 'MOHAMED_gg', 471, 70000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2638, 1764, 'anas_psico', 463, 90000, 0, 1, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2639, 2210, 'MADARA_R1', 471, 70000, 0, 0, 'None', 89, 709.855, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2640, 0, 'Nobody', 541, 0, 0, 0, 'None', 100, 1000, -2535.68, -602.588, 132.187, 179.542, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1410065407, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2641, 0, 'Nobody', 541, 0, 0, 0, 'None', 100, 1000, -2531.82, -602.167, 132.187, 179.61, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1410065407, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2642, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, -2528.07, -602.162, 132.267, 178.368, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1316134911, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2643, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, -2524.53, -602.216, 132.268, 178.585, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1316134911, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2644, 0, 'Nobody', 480, 0, 0, 0, 'None', 100, 1000, -2520.64, -602.459, 132.337, 177.63, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2645, 0, 'Nobody', 480, 0, 0, 0, 'None', 100, 1000, -2516.9, -602.56, 132.336, 180.902, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, -727379969, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2646, 0, 'Nobody', 403, 0, 0, 0, 'None', 100, 1000, -2498.8, -604.13, 133.169, 176.923, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2647, 0, 'Nobody', 413, 0, 0, 0, 'None', 100, 1000, -2513.3, -602.914, 132.655, 178.934, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2648, 0, 'Nobody', 413, 0, 0, 0, 'None', 100, 1000, -2509.59, -602.773, 132.648, 180.144, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2649, 0, 'Nobody', 435, 0, 0, 0, 'None', 100, 1000, -2494.72, -602.556, 133.194, 178.579, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, -1530494977, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2650, 0, 'Nobody', 522, 0, 0, 0, 'None', 100, 1000, -2505.58, -601.576, 132.13, 183.507, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1410065407, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2651, 0, 'Nobody', 522, 0, 0, 0, 'None', 100, 1000, -2501.76, -602.274, 132.126, 177.839, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1410065407, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2652, 407, 'oussama_r', 458, 280000, 0, 1, 'None', 100, 990.942, 1227.63, -1425.61, 13.317, 1.055, 7, 1, 2, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2653, 653, 'MADA_xvilo', 522, 10000000, 0, 0, 'None', 85, 849.743, 1232.88, -1433.75, 13.132, 178.052, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2656, 0, 'Nobody', 490, 0, 0, 1, 'None', 100, 1000, 1146.56, -1364.99, 13.953, 92.949, 126, 126, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2657, 3070, 'MAX_55', 418, 450000, 0, 0, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2658, 2343, 'Aymaaaan_elq', 550, 300000, 0, 1, 'None', 34, 935.003, 1364.01, -1266.38, 13.367, 178.189, 6, 6, 0, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2659, 3318, 'BILY_', 496, 250000, 0, 0, 'None', 98, 962.506, 1224.02, -1425.79, 13.046, 2.018, 198, 0, 0, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2661, 663, 'WLD_NAMOSE', 429, 9000000, 0, 1, 'None', 54, 801.384, 1222.57, -1473.55, 13.18, 180.109, 0, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2662, 3129, 'WLD_LHAJ_2', 424, 550000, 0, 1, 'None', 89, 784.17, 1109.36, -1375.87, 13.638, 359.857, 126, 126, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2663, 3121, '_SMIRIX_', 507, 300000, 0, 0, 'text', 99, 1000, 1109.35, -1352.76, 14.34, 359.96, 2, 2, 1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2664, 3158, 'trock_bangala', 462, 25000, 0, 1, 'None', 100, 998.001, 1242.9, -1421.18, 13.271, 341.919, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2665, 3159, 'pixxa_bangala', 533, 400000, 0, 1, 'None', 100, 51991, 967.19, -1354.65, 13.019, 356.624, 126, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2666, 407, 'oussama_r', 517, 300000, 0, 1, 'None', 100, 987.976, 1227.57, -1419.41, 13.201, 1.04, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 1003, 0, 0, 0, 0, 1010, 1018, 0, 0, 0, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2667, 1192, 'I_NAMOSE', 533, 400000, 0, 0, 'None', 100, 988, 1211.76, -1425.54, 13.092, 1.578, 128, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2668, 3001, 'Nigga_Saddam', 545, 350000, 0, 0, 'None', 89, 849, 1229.09, -1410.7, 12.976, 273.882, 1, 1, -1, NULL, 0, 0, 18650, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2669, 621, 'ADAM_KLLER', 424, 550000, 0, 1, 'None', 100, 817.2, 1135.47, -1415.53, 13.376, 172.036, 1, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2670, 1192, 'I_NAMOSE', 429, 9000000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2671, 475, '_FLIPO_', 429, 9000000, 0, 1, 'None', 89, 1000, 1535.89, -1667.35, 13.014, 180.899, 2, 0, 2, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2672, 2214, '[GLD]PABLO_7AGAR', 546, 300000, 0, 0, 'None', 100, 830.754, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2673, 862, 'ZOU_HIR', 580, 300000, 0, 1, 'None', 92, 1000, 1220.22, -1388.04, 13.24, 263.377, 1, 1, -1, NULL, 0, 0, 18652, 1, 3, 1001, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 31, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2674, 3129, 'WLD_LHAJ_2', 586, 50000, 0, 1, 'None', 100, 895.131, 1087.33, -1378.18, 13.377, 270.689, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2675, 2771, 'RENDO_BARDOK', 445, 300000, 0, 1, 'None', 98, 985.241, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2676, 0, 'Nobody', 487, 0, 0, 0, 'None', 100, 1000, -2522.22, -679.922, 148.083, 274.564, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2677, 3158, 'trock_bangala', 426, 300000, 0, 1, 'None', 100, 1000, 955.768, -1366.07, 13.201, 90.744, 0, 0, -1, NULL, 0, 0, 18652, 1, 0, 1003, 1005, 1006, 0, 0, 1010, 1021, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2679, 1308, 'Musashi_Lucas', 550, 300000, 0, 1, 'None', 98, 45095.4, 206.18, -1359.18, 50.086, 130.185, 6, 6, -1, NULL, 0, 0, 18648, 0, 0, 1001, 1004, 0, 0, 0, 1010, 1018, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2680, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 1808.49, -1100.29, 23.696, 264.795, 163, 163, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2681, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 1828.48, -1101.03, 23.623, 91.327, 163, 163, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2682, 0, 'Nobody', 482, 0, 0, 0, 'None', 100, 1000, 1823.64, -1146.88, 24.06, 359.779, 163, 163, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, -1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2683, 0, 'Nobody', 482, 0, 0, 0, 'None', 100, 1000, 1815.42, -1147.71, 24.043, 357.661, 163, 163, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2684, 663, 'WLD_NAMOSE', 541, 9000000, 0, 0, 'None', 37, 1000, 1216.24, -1473.53, 13.133, 177.918, 6, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2685, 2908, 'bos_7liwa', 412, 250000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2686, 2771, 'RENDO_BARDOK', 462, 25000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2687, 3183, 'Serial_Killer', 404, 250000, 0, 0, 'None', 93, 936.626, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2688, 653, 'MADA_xvilo', 549, 300000, 0, 1, 'None', 89, 300, 1443.39, -1604.13, 13.342, 268.188, 158, 158, -1, NULL, 0, 0, 18647, 1, 0, 1023, 1011, 0, 1017, 0, 1010, 1020, 1079, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2689, 18, 'KENJI_BUSHIDO', 555, 450000, 0, 0, 'None', 89, 896.026, 552.818, -1284.13, 17.0007, 0, 175, 175, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2690, 2641, 'MOUAD_MESSI', 415, 0, 0, 1, 'None', 97, 993.025, 860.487, -1521.93, 13.555, 123.85, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 1003, 0, 0, 1017, 0, 1010, 1019, 1079, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2691, 407, 'oussama_r', 585, 300000, 0, 1, 'None', 100, 949.602, 1223.84, -1425.53, 12.94, 0.908, 158, 175, 0, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2692, 1584, 'JAAAACK', 419, 250000, 0, 1, 'None', 100, 1000, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2693, 1584, 'JAAAACK', 405, 300000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2694, 1584, 'JAAAACK', 439, 500000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2695, 1584, 'JAAAACK', 589, 270000, 0, 0, 'None', 86, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2696, 0, 'Nobody', 432, 0, 0, 0, 'None', 100, 1000, -2493.24, -662.595, 139.358, 357.755, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2697, 2214, '[GLD]PABLO_7AGAR', 471, 70000, 0, 0, 'None', 96, 1000, 1244.16, -1352.43, 12.996, 93.016, 3, 3, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2698, 3419, 'MODOX_dd', 547, 300000, 0, 1, 'None', 98, 785.11, 1216.21, -1425.86, 13.109, 358.044, 175, 175, -1, NULL, 0, 0, 18648, 1, 3, 1003, 0, 0, 0, 0, 1010, 1020, 1079, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2699, 3145, 'jabr_an', 405, 300000, 0, 1, 'None', 62, 655.814, 1330.87, -1388.89, 13.465, 277.43, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 1001, 0, 0, 0, 0, 1010, 1020, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2700, 3219, 'SA7RAWI_11', 581, 50000, 0, 0, 'None', 100, 694.871, 1514.58, -1698.89, 13.613, 359.63, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2701, 3218, 'Morpho_saad', 451, 0, 0, 0, 'None', 100, 1000, 286.872, -1326.46, 53.296, 44.8, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2702, 1501, 'LUFFY_XVILO', 429, 9000000, 0, 1, 'None', 36, 838.001, 1095.79, -1375.69, 13.489, 180.302, 0, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2703, 1574, 'YOUSSEF_XVILO', 545, 350000, 0, 1, 'None', 94, 924, 1141.02, -1414.02, 13.477, 3.328, 1, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2704, 427, 'BO9AL_V2', 411, 10000000, 0, 1, 'None', 85, 308.149, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2705, 2780, 'MAMADO_x', 429, 0, 0, 1, 'None', 100, 893.123, 967.976, -1354.87, 13.023, 182.804, 3, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2706, 2080, 'NIGGA_S', 424, 550000, 0, 1, 'None', 100, 796.628, 1268.38, -1377.05, 13.175, 358.079, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2707, 663, 'WLD_NAMOSE', 555, 450000, 0, 1, 'None', 99, 914.962, 2161.37, -1187.49, 23.493, 88.656, 102, 12, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1084, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2708, 1764, 'anas_psico', 603, 8500000, 0, 0, 'None', 94, 48233, 1219.89, -1348.82, 12.976, 271.22, 7, 1, -1, NULL, 0, 0, 18648, 1, 0, 1023, 0, 1006, 1017, 1024, 1010, 1019, 1079, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2709, 633, 'AYA_RPT', 471, 70000, 0, 1, 'None', 100, 759.325, 1224.84, -1420.29, 12.801, 7.476, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2710, 2085, 'motez_sellami2', 481, 2500, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2711, 3250, '7liwa_gang', 468, 100000, 0, 0, 'None', 88, 861.902, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2712, 1192, 'I_NAMOSE', 409, 0, 0, 1, 'None', 92, 1000, 271.296, -1371.37, 52.872, 340.905, 0, 0, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2713, 3218, 'Morpho_saad', 468, 100000, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2715, 0, 'Nobody', 473, 0, 0, 1, 'None', 100, 1000, -1514.44, 1296.19, -0.53, 79.728, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1410065407, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2716, 0, 'Nobody', 595, 0, 0, 1, 'None', 100, 1000, -1507.79, 1299.3, -0.085, 95.381, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2717, 614, 'JIMO_HQ1', 506, 0, 0, 1, 'None', 100, 707.484, 2112.78, -1782.98, 13.059, 3.368, 1, 1, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2718, 769, 'ycz_imad', 426, 300000, 0, 1, 'None', 98, 1000, 1106.71, -1376.8, 13.563, 174.865, 198, 0, -1, NULL, 0, 0, 18648, 1, 0, 1003, 1005, 1006, 0, 0, 1010, 1021, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2719, 769, 'ycz_imad', 549, 300000, 0, 1, 'None', 96, 985, 1130.33, -1367.22, 13.554, 1.268, 158, 158, -1, NULL, 0, 0, 18647, 1, 0, 1001, 1012, 0, 0, 0, 1010, 0, 1079, 0, 0, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2720, 3145, 'jabr_an', 410, 300000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(2721, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2158.21, -1809.27, 13.086, 270.068, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2722, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2157.84, -1805.42, 13.079, 273.917, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1000000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2723, 0, 'Nobody', 560, 0, 0, 0, 'None', 100, 1000, 2157.56, -1802.3, 13.073, 267.281, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2724, 0, 'Nobody', 482, 0, 0, 0, 'None', 100, 1000, 2158.49, -1798.99, 13.471, 267.241, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2725, 0, 'Nobody', 482, 0, 0, 0, 'None', 100, 1000, 2158.46, -1795.58, 13.474, 267.415, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2726, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2170.75, -1792.39, 13.026, 176.48, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2727, 0, 'Nobody', 468, 0, 0, 0, 'None', 100, 1000, 2168.72, -1792.33, 13.022, 179.787, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 100000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2728, 0, 'Nobody', 468, 0, 0, 1, 'None', 100, 1000, 2166.43, -1792.4, 13.019, 183.216, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2729, 0, 'Nobody', 482, 0, 0, 0, 'None', 100, 1000, 2158.89, -1792.7, 13.508, 271.391, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 10000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2730, 2885, 'azAZZA_za09', 424, 550000, 0, 0, 'None', 100, 1000, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2731, 3295, 'dadi_gang', 481, 2500, 0, 0, 'None', 100, 1000, 557.867, -1283.98, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2732, 2056, 'vip_piro1', 603, 8500000, 5000, 0, 'None', 94, 535.397, 1109.32, -1352.66, 14.293, 0.595, 1, 0, -1, NULL, 0, 0, 18652, 1, 0, 1023, 0, 0, 0, 0, 1010, 1020, 1075, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2733, 1237, 'MOTCHA_LOTch', 429, 9000000, 0, 0, 'None', 98, 635.498, 2288.93, -1115.92, 37.607, 169.574, 198, 0, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2734, 3275, 'Badis_mhh', 463, 90000, 0, 1, 'None', 96, 889.667, 1930.03, -1767.98, 13.087, 203.302, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2735, 695, 'LEGOS_PADRI', 405, 300000, 0, 0, 'None', 100, 997.868, 1220.06, -1316.51, 13.044, 267.987, 175, 175, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2736, 1432, 'Bachta_20', 420, 400000, 0, 0, 'None', 94, 874.159, 1209.44, -1406.67, 13.039, 269.567, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2737, 2380, 'RIVALDO_XV', 462, 25000, 0, 0, 'None', 72, 973.124, 552.818, -1284.13, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2738, 3158, 'trock_bangala', 536, 3500000, 0, 1, 'None', 100, 1000, 953.997, -1355.18, 13.014, 177.051, 0, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 1128, 0, 0, 1010, 1105, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2739, 2085, 'motez_sellami2', 468, 100000, 0, 1, 'None', 87, 713, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2740, 3625, 'Za@ck_X_Twix', 471, 70000, 0, 0, 'None', 100, 833.026, 562.397, -1283.85, 17.0007, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2741, 3132, 'BLS_ESCANOR', 521, 1200000, 0, 0, 'None', 99, 994.869, 2216.57, -1162.12, 25.297, 82.718, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2743, 1012, 'Akram_Messi', 602, 6500000, 0, 1, 'None', 100, 1000, 1116.66, -1409.44, 13.167, 271.245, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2744, 3275, 'Badis_mhh', 545, 350000, 0, 1, 'None', 96, 825.709, 1535.91, -1672.27, 13.194, 183.974, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2745, 1764, 'anas_psico', 586, 50000, 0, 1, 'None', 81, 436.051, 1233.79, -1371.14, 12.681, 148.149, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2746, 653, 'MADA_xvilo', 410, 300000, 0, 1, 'None', 100, 850.854, 1491.85, -1600.37, 13.201, 92.134, 10, 1, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2747, 3165, 'JNX_BKE', 424, 550000, 0, 1, 'None', 74, 996.139, 1213.28, -1417.81, 13.131, 1.367, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2748, 2772, 'PABLO_LMICROBE', 545, 350000, 0, 1, 'None', 88, 769.822, 1466.34, -1604.06, 13.484, 359.937, 6, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2749, 2772, 'PABLO_LMICROBE', 424, 550000, 0, 1, 'None', 97, 800, 541.739, -1272.94, 17.023, 200.264, 154, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2750, 2380, 'RIVALDO_XV', 424, 550000, 0, 0, 'None', 77, 1000, 562.397, -1283.85, 17.0007, 0, 9, 6, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2751, 2641, 'MOUAD_MESSI', 458, 280000, 0, 0, 'None', 99, 994.724, 1664, -2339.9, 1536.03, 89.941, 10, 10, 1, NULL, 3, 2000075, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2752, 1471, 'IRT_WLD_ALI', 493, 20750000, 0, 0, 'None', 87, 866.517, 243.135, -1895.89, 0.645, 166.889, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2753, 2889, 'VEGAS_JNYN', 549, 300000, 0, 1, 'None', 100, 885.966, 1281.83, -1334.12, 13.052, 91.866, 198, 198, -1, NULL, 0, 0, 18647, 1, 3, 1001, 1012, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2754, 1866, '@islam_07..', 426, 300000, 0, 1, 'None', 100, 655.314, 1221.28, -1410.25, 12.929, 88.146, 158, 0, -1, NULL, 0, 0, 18648, 1, 3, 1001, 1005, 1006, 0, 0, 1010, 0, 1082, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2755, 2214, '[GLD]PABLO_7AGAR', 555, 450000, 0, 0, 'None', 100, 651.39, 2601.47, -952.38, 80.618, 110.47, 1, 178, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2756, 407, 'oussama_r', 439, 500000, 0, 1, 'None', 100, 1000, 1231.31, -1425.72, 13.381, 2.78, 120, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2757, 3326, 'assa_ssin', 551, 300000, 0, 1, 'None', 88, 975.002, 550.735, -1266.96, 16.9693, 215.44, 1, 1, -1, NULL, 0, 0, 18649, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2758, 407, 'oussama_r', 424, 550000, 0, 0, 'None', 100, 932.962, 1246.51, -1439.01, 13.395, 67.021, 67, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2759, 3326, 'assa_ssin', 533, 400000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2760, 827, 'LMBAW9_ALAMI', 468, 100000, 0, 1, 'None', 100, 936, 1223.28, -1419.65, 12.958, 4.152, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2761, 1285, 'WALD_FAVELAS', 541, 9000000, 4000, 0, 'None', 89, 355.2, 1115.66, -1361.56, 13.479, 159.594, 9, 6, -1, NULL, 0, 0, 18652, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2762, 2249, 'ANAS_WILSON', 581, 50000, 0, 1, 'None', 99, 840, 954.947, -922.567, 43.702, 22.449, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2763, 3327, 'Nassim_Jonyor', 589, 270000, 0, 0, 'None', 89, 877, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2764, 3235, 'Youvvef_Lm9wd', 468, 100000, 0, 1, 'None', 95, 717.38, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2765, 3342, 'HERO_ZERO', 510, 10000, 0, 0, 'None', 100, 966.056, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2766, 407, 'oussama_r', 410, 300000, 0, 1, 'None', 96, 883, 1208.04, -1419.53, 13.035, 301.046, 175, 176, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2767, 1908, 'mastafa_ue_06', 462, 25000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2768, 1978, 'HN_HIBA', 551, 300000, 0, 1, 'None', 100, 963.191, 1241.49, -1362.75, 12.936, 93.087, 158, 158, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2769, 1471, 'IRT_WLD_ALI', 452, 19550000, 0, 0, 'None', 99, 1000, 249.153, -1893.65, -0.025, 167.509, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2770, 2889, 'VEGAS_JNYN', 422, 450000, 0, 0, 'None', 100, 985.083, 1212.44, -1417.88, 13.303, 354.639, 6, 6, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2771, 868, 'YASSIN_RESTOVA', 580, 300000, 0, 1, 'None', 100, 687, 1621.29, -1093.95, 23.703, 95.603, 198, 0, -1, NULL, 0, 0, 18652, 1, 0, 1023, 0, 0, 0, 0, 0, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2772, 2979, 'Zakaria_ol', 579, 3100000, 0, 0, 'None', 100, 408, 362.813, 2530.45, 16.613, 188.932, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2773, 2780, 'MAMADO_x', 439, 500000, 0, 1, 'None', 96, 977.146, 968.314, -1373.4, 13.195, 179.123, 222, 222, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2774, 3283, 'Alex_Ornold', 468, 100000, 0, 0, 'None', 95, 300, 1232.03, -1390.31, 13.011, 292.451, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2775, 407, 'oussama_r', 585, 300000, 0, 1, 'None', 100, 810.938, 1219.29, -1419.79, 12.815, 0.373, 1, 1, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1008, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2776, 1501, 'LUFFY_XVILO', 560, 5500000, 0, 1, 'None', 100, 971.904, 1106.99, -1412.87, 13.289, 352.401, 3, 3, 2, NULL, 0, 0, 18651, 1, 3, 1139, 0, 1033, 0, 0, 1010, 0, 1083, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2777, 621, 'ADAM_KLLER', 426, 300000, 0, 0, 'None', 94, 878.305, 705.408, -1215.87, 17.142, 292.441, 127, 127, -1, NULL, 0, 0, 18652, 1, 0, 1003, 1005, 1006, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2778, 1500, 'ZORO__XVILO', 496, 250000, 0, 1, 'None', 55, 1000, 1088.48, -1413.87, 13.325, 358.5, 93, 0, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2779, 0, 'Nobody', 451, 0, 0, 0, 'None', 100, 1000, 2177, -1810.76, 13.156, 0.251, 135, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2780, 0, 'Nobody', 409, 0, 0, 0, 'None', 100, 1000, 960.885, -923.801, 45.566, 0.735, 168, 168, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2781, 0, 'Nobody', 522, 0, 0, 1, 'None', 100, 1000, 2251.05, -1085.94, 41.167, 134.072, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, -1, 1410065407, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2782, 1975, 'saad_az19', 462, 25000, 0, 0, 'None', 74, 991.695, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2783, 407, 'oussama_r', 426, 300000, 0, 1, 'None', 100, 977.657, 1219.67, -1425.9, 13.05, 359.798, 1, 1, -1, NULL, 0, 0, 18652, 1, 3, 1001, 1005, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2784, 3350, '7MIDO_RP', 581, 50000, 0, 0, 'None', 79, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2785, 3341, 'idriss_bishop', 468, 100000, 0, 1, 'None', 73, 992.932, 1228.2, -1372.8, 12.817, 6.951, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2786, 3158, 'trock_bangala', 420, 400000, 0, 1, 'None', 100, 659.162, 1261.14, -1413.91, 13.12, 268.145, 6, 6, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2787, 3374, 'CJ_', 468, 100000, 0, 1, 'None', 99, 852, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2788, 653, 'MADA_xvilo', 580, 300000, 0, 1, 'None', 68, 979, 1220.35, -1423.46, 13.065, 178.537, 1, 1, -1, NULL, 0, 0, 18651, 1, 0, 1001, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2789, 3374, 'CJ_', 527, 310000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2790, 3402, 'ayman_rofix', 468, 100000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2791, 3373, 'RICARDO__op', 439, 500000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2792, 2780, 'MAMADO_x', 580, 300000, 0, 1, 'None', 99, 592.337, 958.348, -1355.02, 13.1, 181.983, 1, 1, -1, NULL, 0, 0, 18652, 1, 3, 1001, 0, 1006, 1017, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2794, 2933, 'X25_YASSINE', 510, 10000, 0, 1, 'None', 100, 994.939, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2795, 3303, 'LH9I9A_LHBIL', 468, 100000, 0, 0, 'None', 94, 956.044, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2796, 3303, 'LH9I9A_LHBIL', 463, 90000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2797, 3303, 'LH9I9A_LHBIL', 400, 320000, 0, 0, 'None', 58, 996.205, 1241.44, -1372.87, 13.262, 265.971, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2798, 868, 'YASSIN_RESTOVA', 587, 7000000, 0, 1, 'None', 100, 813.893, 1628.82, -1107.58, 23.597, 267.217, 3, 0, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2799, 407, 'oussama_r', 474, 280000, 0, 1, 'None', 94, 803.762, 2612.64, -948.609, 79.811, 111.715, 6, 1, -1, NULL, 0, 0, 18650, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2800, 1709, 'SUPRA_MK4', 410, 300000, 0, 1, 'None', 98, 839.308, 1777.12, -1895.2, 12.965, 269.804, 3, 3, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2801, 3329, 'MARYOUL_Drag', 545, 350000, 0, 0, 'None', 100, 704.517, 1221.43, -1364.76, 12.98, 68.851, 1, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 0, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2802, 407, 'oussama_r', 554, 400000, 0, 1, 'None', 100, 901.782, 1208.43, -1425.66, 13.467, 0.052, 1, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2803, 3027, 'WLD_LAHJ_2', 585, 300000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2804, 3434, 'YOUSSF_MRRAKCHI', 510, 10000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2805, 3435, 'L7aj_Celtia', 481, 2500, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2806, 1764, 'anas_psico', 580, 300000, 0, 1, 'None', 100, 584.502, 826.757, -885.296, 68.515, 119.472, 1, 1, -1, NULL, 0, 0, 18651, 1, 3, 1001, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2807, 3159, 'pixxa_bangala', 580, 300000, 0, 1, 'None', 100, 919.775, 1113.76, -1376.89, 13.609, 0.275, 190, 1, -1, NULL, 0, 0, 18652, 1, 3, 1001, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2808, 1370, 'pablo__gg', 461, 1000000, 0, 1, 'None', 98, 893.419, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2809, 2933, 'X25_YASSINE', 468, 100000, 0, 1, 'None', 96, 766.965, 1246.39, -1423.98, 13.17, 172.711, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2810, 1024, 'X7___RAJAWI___GB', 580, 300000, 0, 1, 'None', 67, 1000, 1093.51, -1388.89, 13.42, 181.43, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 1006, 1017, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2811, 3372, 'DINA_MC', 580, 300000, 0, 0, 'None', 94, 927.592, 1235.51, -1370.21, 12.941, 346.282, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2812, 3465, 'MAX_54', 424, 550000, 0, 0, 'None', 100, 504.206, 550.735, -1266.96, 16.9693, 215.44, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2813, 2703, 'Anas_Marko', 521, 1200000, 0, 0, 'None', 100, 641.036, 1189.7, -1317.39, 13.132, 3.882, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2814, 3390, 'YOUSSF_MRAKCHI', 581, 50000, 0, 1, 'None', 40, 897, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2815, 1432, 'Bachta_20', 585, 300000, 0, 0, 'None', 99, 889.868, 1237.65, -1383.46, 12.905, 0.809, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2816, 3029, 'WLD_LHAJ_1', 429, 9000000, 0, 1, 'None', 100, 944.177, 884.526, -1182.23, 16.61, 177.36, 136, 1, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2817, 3508, 'Vortex_X', 426, 300000, 0, 1, 'None', 97, 861.966, 1276.7, -1299.54, 13.038, 180.664, 137, 137, -1, NULL, 0, 0, 18649, 1, 0, 1001, 1005, 1006, 0, 0, 1010, 1019, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2818, 1191, 'ZIZEWAR_X', 549, 300000, 0, 1, 'None', 89, 621.06, 1220.83, -1371.18, 12.847, 265.203, 6, 6, -1, NULL, 0, 0, 18650, 1, 0, 1003, 1012, 0, 0, 0, 1010, 1018, 1083, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2819, 3513, 'NAKATA___MIXICO.', 550, 300000, 0, 1, 'None', 90, 956.254, 1276.69, -1293.52, 13.11, 179.793, 167, 167, -1, NULL, 0, 0, 18651, 1, 0, 1023, 1005, 1006, 0, 0, 1010, 1018, 1081, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2820, 1308, 'Musashi_Lucas', 545, 350000, 0, 0, 'None', 47, 1000, 314.829, -1788.83, 4.44, 182.735, 13, 13, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2821, 3029, 'WLD_LHAJ_1', 424, 550000, 0, 1, 'None', 95, 981.484, 1239.57, -1328.26, 12.949, 178.814, 137, 137, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2822, 2610, 'AP555_RP', 471, 70000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2823, 2609, 'MARKIZ_RP', 581, 50000, 0, 1, 'None', 99, 810.059, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2824, 496, 'KATANA_HQ', 550, 300000, 0, 0, 'None', 100, 612.496, 550.735, -1266.96, 16.9693, 215.44, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 1001, 0, 0, 0, 0, 1010, 0, 1083, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2825, 614, 'JIMO_HQ1', 426, 300000, 0, 0, 'None', 100, 1000, 2103.41, -1770.53, 13.102, 258.912, 1, 1, -1, NULL, 0, 0, 18651, 1, 0, 1003, 1005, 1006, 0, 0, 1010, 0, 1075, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2826, 862, 'ZOU_HIR', 502, 0, 0, 1, 'None', 59, 1000, 1180.97, -1338.64, 13.58, 269.299, 3, 3, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2827, 862, 'ZOU_HIR', 415, 0, 0, 1, 'None', 85, 1000, 1112.17, -1376.02, 13.636, 179.895, 7, 7, -1, NULL, 0, 0, 18650, 1, 0, 1003, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2828, 862, 'ZOU_HIR', 451, 0, 0, 0, 'None', 63, 1000, 1221.66, -1387.82, 13.045, 89.366, 3, 3, -1, NULL, 0, 0, 18651, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2829, 1761, 'I_NAMOSE', 585, 300000, 0, 0, 'None', 76, 731.632, 331.021, -1808.72, 4.051, 178.874, 79, 79, 0, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2830, 653, 'MADA_xvilo', 545, 350000, 0, 0, 'None', 100, 852.495, 1483.7, -1624.85, 13.857, 348.148, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2831, 653, 'MADA_xvilo', 426, 300000, 0, 1, 'None', 100, 996.989, 550.735, -1266.96, 16.9693, 215.44, 1, 1, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2832, 556, 'ninga_Xvilo', 492, 270000, 0, 1, 'None', 76, 773.385, 550.735, -1266.96, 16.9693, 215.44, 86, 86, -1, NULL, 0, 0, 18650, 1, 0, 1000, 1004, 1006, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2833, 3508, 'Vortex_X', 471, 70000, 0, 1, 'None', 99, 788.346, 1276.67, -1314.47, 12.82, 180.664, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2834, 3029, 'WLD_LHAJ_1', 580, 300000, 0, 1, 'None', 100, 888.841, 1220, -1327.12, 12.924, 179.44, 1, 2, -1, NULL, 0, 0, 18652, 1, 0, 1023, 0, 1006, 1017, 0, 1010, 1020, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2835, 3148, 'ALAA_VINSMOKE', 482, 4500000, 0, 0, 'None', 93, 1000, 550.735, -1266.96, 16.9693, 215.44, 3, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2836, 1865, 'alex_boneli', 424, 550000, 0, 1, 'None', 100, 582.661, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2837, 556, 'ninga_Xvilo', 491, 270000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 1, 1, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2838, 653, 'MADA_xvilo', 526, 310000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 1, 1, 1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2839, 653, 'MADA_xvilo', 411, 10000000, 0, 0, 'None', 100, 968.668, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2840, 653, 'MADA_xvilo', 576, 330000, 0, 0, 'None', 100, 865.908, 1137.8, -1431.19, 15.408, 302.094, 0, 0, 2, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2841, 556, 'ninga_Xvilo', 541, 9000000, 0, 0, 'None', 84, 300, 1449.7, -1585.27, 13.147, 182.584, 86, 86, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2842, 653, 'MADA_xvilo', 541, 9000000, 0, 0, 'None', 100, 844.466, 1350.64, -1011.16, 26.298, 208.196, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2843, 556, 'ninga_Xvilo', 541, 9000000, 0, 0, 'None', 100, 974.953, 1456.53, -1584.82, 13.164, 177.267, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2844, 653, 'MADA_xvilo', 402, 8500000, 0, 0, 'None', 97, 880.872, 1473.86, -1585.89, 13.343, 204.162, 3, 3, -1, NULL, 0, 0, 18647, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2845, 653, 'MADA_xvilo', 402, 8500000, 0, 0, 'None', 100, 948.357, 1491.02, -1585.22, 13.389, 179.181, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2846, 653, 'MADA_xvilo', 402, 8500000, 0, 1, 'None', 95, 251, 550.735, -1266.96, 16.9693, 215.44, 6, 6, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2847, 3525, 'YOUSSF_PIDRO', 526, 310000, 0, 0, 'None', 97, 665.208, 1251.39, -1432.99, 13.295, 356.577, 18, 1, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2848, 1819, 'LA_BANDA_16', 589, 270000, 0, 0, 'None', 100, 899, 1203.34, -1435.83, 13.076, 182.605, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 1005, 1006, 1017, 1013, 1010, 0, 1074, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 24, 29, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2849, 407, 'oussama_r', 412, 250000, 0, 1, 'None', 100, 951.34, 1215.65, -1419.44, 13.068, 359.43, 1, 6, -1, NULL, 0, 0, 18649, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2850, 3495, 'salah_sh', 581, 50000, 0, 0, 'None', 94, 973.127, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2851, 1973, 'PECASO_XM8', 506, 0, 0, 1, 'None', 100, 744.573, 859.558, -1529.15, 13.233, 264.64, 200, 200, 0, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2852, 3029, 'WLD_LHAJ_1', 541, 9000000, 0, 1, 'None', 100, 1000, 324.852, -1788.82, 4.366, 179.633, 137, 1, -1, NULL, 0, 0, 18649, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2853, 621, 'ADAM_KLLER', 411, 10000000, 0, 0, 'None', 100, 929.219, 1571.17, -1747.52, 4.131, 76.303, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2854, 1285, 'WALD_FAVELAS', 510, 10000, 0, 0, 'None', 100, 971.5, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2855, 2545, 'SHELBY_TALIANI', 463, 90000, 0, 1, 'None', 100, 941.228, -554.487, -487.828, 25.062, 5.511, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2856, 3411, 'Moemen_X_Twix', 589, 270000, 0, 0, 'None', 100, 981.156, 550.735, -1266.96, 16.9693, 215.44, 158, 158, -1, NULL, 0, 0, 18648, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2857, 3517, 'SI_DAFIR', 468, 100000, 0, 1, 'None', 100, 670.512, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2858, 3461, 'CJ_CJ', 468, 100000, 0, 0, 'None', 22, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2859, 3517, 'SI_DAFIR', 445, 300000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2860, 614, 'JIMO_HQ1', 580, 300000, 0, 1, 'None', 80, 518.052, 2102.23, -1776.78, 13.149, 258.675, 1, 1, -1, NULL, 0, 0, 18651, 1, 0, 1023, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2861, 496, 'KATANA_HQ', 580, 300000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2862, 3508, 'Vortex_X', 585, 300000, 0, 0, 'None', 100, 1000, 1283.82, -1364.72, 13.036, 90.43, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2863, 3300, 'M9YD__TANJIRO', 600, 270000, 0, 1, 'None', 100, 984.533, 1215.16, -1425.59, 13.084, 356.557, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2864, 1978, 'HN_HIBA', 481, 2500, 0, 1, 'None', 100, 1000, 1244.02, -1342.9, 12.677, 95.001, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2865, 868, 'YASSIN_RESTOVA', 495, 0, 0, 1, 'None', 100, 933.673, 1351.01, -1594.91, 13.859, 165.682, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2866, 868, 'YASSIN_RESTOVA', 504, 0, 0, 0, 'None', 100, 943.51, 2228.21, -1162.71, 25.562, 92.452, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2867, 868, 'YASSIN_RESTOVA', 415, 0, 0, 0, 'None', 100, 1000, 1354.45, -1595.1, 13.541, 291.933, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2868, 3545, 'WLD_ZA3IMA', 581, 50000, 0, 0, 'None', 79, 622.588, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2869, 3528, 'AP555._RP', 581, 50000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2870, 3552, 'MOL_SUPRA', 580, 300000, 0, 0, 'None', 97, 980.736, 550.735, -1266.96, 16.9693, 215.44, 6, 6, -1, NULL, 0, 0, 18650, 1, 0, 1001, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2871, 3545, 'WLD_ZA3IMA', 589, 270000, 0, 1, 'None', 85, 510.638, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2872, 435, 'RINIO_', 411, 10000000, 0, 1, 'None', 100, 1000, 1110.76, -1391.53, 13.136, 268.431, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, 23, 29, 24, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2873, 621, 'ADAM_KLLER', 522, 10000000, 0, 0, 'None', 100, 766, 2205.93, -1177.18, 25.29, 271.414, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2874, 1471, 'IRT_WLD_ALI', 429, 9000000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 1, 2, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2875, 1859, 'Younsse_Allamy', 541, 9000000, 0, 0, 'None', 65, 756.622, 1547.99, -1668, 13.145, 95.645, 1, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1008, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2876, 1471, 'IRT_WLD_ALI', 549, 300000, 0, 0, 'None', 100, 968.848, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2877, 1471, 'IRT_WLD_ALI', 555, 450000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2878, 2789, 'SI_ALI', 603, 8500000, 0, 1, 'None', 92, 1000, 1675.96, -1097.31, 23.713, 271.907, 2, 1, -1, NULL, 0, 0, 18652, 1, 3, 1001, 0, 1006, 1017, 0, 1010, 1020, 1083, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2879, 2690, 'PEDRO_VGS', 461, 1000000, 0, 1, 'None', 18, 997.898, 1272.42, -1347.5, 13.08, 353.871, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2880, 3508, 'Vortex_X', 580, 300000, 0, 1, 'None', 100, 972.576, 1276.74, -1310.51, 13.132, 178.698, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2881, 407, 'oussama_r', 576, 330000, 0, 1, 'None', 81, 987.122, 2267.13, -1103.81, 37.585, 157.175, 6, 1, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 1137, 0, 1010, 1135, 1078, 0, 0, 1190, 1192, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2882, 1074, 'PABLO_WOLF', 533, 400000, 0, 1, 'None', 97, 732.332, 968.273, -1378.76, 13.02, 180.651, 175, 158, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2883, 2690, 'PEDRO_VGS', 424, 550000, 0, 1, 'None', 83, 339.479, 1270.43, -1328.27, 13.28, 88.757, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2884, 435, 'RINIO_', 481, 2500, 0, 1, 'None', 100, 998.901, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2885, 3148, 'ALAA_VINSMOKE', 576, 330000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 6, 6, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2886, 653, 'Mada_Xvilo', 510, 10000, 0, 1, 'None', 100, 967.351, 1304.01, -1369.83, 13.172, 177.547, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2887, 3560, 'Diib_Dark2', 468, 100000, 0, 0, 'None', 96, 593.045, 1247.92, -1265.08, 13.023, 104.12, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2888, 3562, 'CHANI9A_SGIR', 589, 270000, 0, 1, 'None', 100, 363.511, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2889, 1962, 'fouade_2023', 533, 400000, 0, 0, 'None', 89, 1000, 1230.04, -1389.62, 13.053, 90.913, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2890, 877, 'L7AJ_ZIAD', 551, 300000, 0, 0, 'None', 100, 1000, 1179.5, -1410.6, 13.142, 269.208, 158, 158, -1, NULL, 0, 0, 18647, 1, 1, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2891, 3429, 'ayman_rofixx', 468, 100000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2892, 3499, 'MYTH_CASSTILANO', 589, 270000, 0, 0, 'None', 98, 652.75, 550.735, -1266.96, 16.9693, 215.44, 201, 201, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2893, 3589, 'PABLO_APATCHI', 471, 70000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2894, 2890, 'DYABLO_MICROBE', 555, 450000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2895, 3566, 'wld__3li', 461, 1000000, 0, 1, 'None', 93, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2896, 3029, 'WLD_LHAJ_1', 566, 300000, 0, 1, 'None', 100, 984.412, 1235.95, -1335.15, 12.95, 179.778, 222, 222, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2897, 3545, 'WLD_ZA3IMA', 540, 300000, 0, 1, 'None', 100, 956.784, 1109.08, -1375.36, 13.67, 359.479, 2, 2, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1078, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2898, 3329, 'MARYOUL_Drag', 533, 400000, 0, 0, 'None', 83, 930.341, 1251.17, -1434.27, 13.26, 357.093, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2899, 1761, 'I_NAMOSE', 412, 250000, 0, 0, 'None', 100, 1000, 327.768, -1809.11, 4.272, 180.591, 3, 3, 1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2900, 620, 'Lorenzo_Mp3', 551, 300000, 0, 0, 'None', 100, 1000, 355.115, -1808.23, 4.37, 180.151, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2901, 1519, 'Boonina_Millions', 533, 400000, 0, 1, 'None', 99, 1000, 309.37, -1321.88, 53.124, 29.604, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2902, 1519, 'Boonina_Millions', 580, 300000, 0, 1, 'None', 98, 846, 308.74, -1330.6, 53.203, 329.992, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 29, 31, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2903, 1519, 'Boonina_Millions', 551, 300000, 0, 1, 'None', 98, 995, 302.076, -1319.51, 53.219, 118.56, 0, 0, -1, NULL, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2904, 3545, 'WLD_ZA3IMA', 400, 320000, 0, 0, 'None', 65, 881.131, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2905, 3461, 'CJ_CJ', 560, 5500000, 0, 0, 'None', 100, 593.335, 1115.66, -1352.34, 14.258, 358.555, 2, 2, -1, NULL, 0, 0, 18648, 1, 0, 1138, 0, 1032, 0, 0, 1010, 1028, 1075, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2906, 3517, 'SI_DAFIR', 560, 5500000, 0, 0, 'None', 85, 46072.8, 550.735, -1266.96, 16.9693, 215.44, 6, 6, -1, NULL, 0, 0, 18650, 1, 3, 1138, 0, 1033, 0, 0, 1010, 1028, 1077, 0, 1087, 1169, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2907, 3029, 'WLD_LHAJ_1', 576, 330000, 0, 0, 'None', 55, 696.977, 1213.98, -1425.21, 12.928, 358.514, 3, 3, 3, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2908, 3461, 'CJ_CJ', 580, 300000, 0, 0, 'None', 64, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2909, 3029, 'WLD_LHAJ_1', 533, 400000, 0, 1, 'None', 99, 1000, 1227.46, -1334.54, 12.851, 177.508, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2910, 3506, 'LFERDA___', 462, 25000, 0, 1, 'None', 87, 868.529, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2911, 2322, 'SIGMAAAAAAAA', 475, 270000, 0, 1, 'None', 61, 861.014, 1211.14, -1382.67, 13.154, 359.339, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2912, 3461, 'CJ_CJ', 461, 1000000, 0, 1, 'None', 80, 981.653, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2913, 585, 'BERNARDO_RPT', 589, 270000, 0, 0, 'None', 100, 994.983, 2488.15, -2014.71, 13.065, 268.634, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2914, 1709, 'SUPRA_MK4', 409, 0, 0, 1, 'None', 100, 578.046, 1776.12, -1891.26, 13.174, 267.542, 0, 0, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`) VALUES
(2915, 1709, 'SUPRA_MK4', 558, 0, 0, 0, 'YS BRO', 90, 805.647, 1777.2, -1909.73, 12.943, 269.931, 56, 56, 2, NULL, 0, 0, 18648, 1, 3, 1164, 0, 1088, 1095, 0, 1010, 1089, 1085, 0, 1087, 1166, 1168, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2916, 1709, 'SUPRA_MK4', 562, 0, 0, 1, 'None', 99, 735.87, 1776.78, -1913, 12.963, 269.514, 1, 1, 2, NULL, 0, 0, 18649, 1, 3, 1147, 0, 1035, 0, 0, 1010, 1034, 1075, 0, 1087, 0, 1149, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2917, 799, 'Omar_Mrakxi', 586, 50000, 0, 1, 'None', 98, 674.789, 437.712, -1732.31, 8.947, 270.934, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2918, 3648, 'adel_med', 555, 450000, 0, 1, 'None', 100, 300, 1214.55, -1419.99, 12.997, 357.827, 198, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2919, 3458, '9TALE_TALIANI', 541, 9000000, 0, 0, 'None', 55, 933.298, 1283.52, -1365.75, 13.041, 88.14, 0, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2920, 3158, 'trock_bangala', 550, 300000, 0, 1, 'None', 94, 924.252, 956.609, -1362.89, 13.307, 88.393, 137, 137, -1, NULL, 0, 0, 18649, 1, 0, 1023, 1005, 1006, 0, 0, 1010, 1019, 1081, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2921, 3029, 'WLD_LHAJ_1', 549, 300000, 0, 1, 'None', 99, 918.272, 1223.59, -1327.03, 12.852, 177.48, 222, 222, -1, NULL, 0, 0, 0, 0, 0, 1023, 1012, 0, 0, 0, 1010, 1019, 1081, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2922, 3029, 'WLD_LHAJ_1', 549, 300000, 0, 0, 'None', 99, 983.443, 1231.78, -1327.18, 12.847, 178.626, 2, 2, -1, NULL, 0, 0, 18648, 1, 0, 1023, 1011, 0, 0, 0, 1010, 1019, 1081, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2923, 3517, 'SI_DAFIR', 550, 300000, 0, 0, 'None', 100, 898.198, 1227.59, -1327.18, 12.959, 177.065, 222, 222, -1, NULL, 0, 0, 18647, 1, 0, 1023, 1005, 1006, 0, 0, 1010, 1019, 1081, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2924, 3029, 'WLD_LHAJ_1', 426, 300000, 0, 1, 'None', 99, 755.291, 1223.36, -1333.91, 12.862, 176.923, 137, 137, -1, NULL, 0, 0, 18649, 1, 0, 1001, 1005, 1006, 0, 0, 1010, 1019, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2925, 3029, 'WLD_LHAJ_1', 426, 300000, 0, 1, 'None', 100, 936.088, 1231.69, -1334.66, 12.862, 178.464, 232, 232, -1, NULL, 0, 0, 18651, 1, 0, 1001, 1005, 1006, 0, 0, 1010, 1019, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2926, 3513, 'NAKATA___MIXICO.', 589, 270000, 0, 0, 'None', 82, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2927, 2780, 'MAMADO_x', 560, 5500000, 0, 0, 'None', 91, 988.747, 962.785, -1360.32, 13.007, 180.876, 3, 3, 1, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1033, 1030, 0, 1010, 1029, 1079, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2928, 3029, 'WLD_LHAJ_1', 545, 350000, 0, 1, 'None', 99, 989.94, 1239.81, -1335.47, 12.984, 177.986, 135, 135, -1, NULL, 0, 0, 18648, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2929, 3029, 'WLD_LHAJ_1', 545, 350000, 0, 1, 'None', 100, 1000, 1227.68, -1327.1, 12.98, 178.028, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2930, 1399, 'achraf_nh', 429, 9000000, 0, 0, 'None', 99, 994.42, 1109.62, -1375.3, 13.737, 182.338, 128, 0, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2931, 3701, 'ryn_mvp', 468, 100000, 0, 0, 'None', 100, 1000, 1761.1, -1070.63, 23.623, 352.977, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2932, 3525, 'YOUSSF_PIDRO', 439, 500000, 0, 1, 'None', 100, 856.79, 550.735, -1266.96, 16.9693, 215.44, 175, 175, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1073, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2933, 894, 'TALIANI_WOLF', 521, 1200000, 0, 0, 'None', 100, 976.947, 1772.25, -1711.82, 13.127, 33.317, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2934, 435, 'RINIO_', 510, 10000, 0, 0, 'None', 100, 829.724, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2935, 435, 'RINIO_', 533, 400000, 0, 1, 'None', 99, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2936, 3235, 'Youvvef_Lm9wd', 560, 5500000, 0, 0, 'None', 100, 811.335, 381.55, -2072.47, 7.541, 130.413, 226, 226, 0, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1098, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2937, 3504, 'JNXx___', 462, 25000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2938, 3641, 'yessin_9os', 411, 10000000, 0, 0, 'None', 98, 773.314, -1028.32, -2153.24, 33.977, 254.088, 79, 79, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 25, 29, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2939, 2675, 'SUPRA_VGS', 541, 9000000, 0, 0, 'None', 99, 722, 1130.3, -1365.93, 13.382, 195.593, 1, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2940, 1519, 'BA9LAWA_', 434, 0, 0, 0, 'None', 96, 1000, 1661.08, -2345.54, 1535.4, 267.436, 0, 0, 4, NULL, 3, 2000055, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1079, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2941, 3158, 'trock_bangala', 550, 300000, 0, 1, 'None', 100, 1000, 956.255, -1372.58, 13.296, 89.768, 198, 198, -1, NULL, 0, 0, 18652, 1, 3, 1023, 1005, 1006, 0, 0, 1010, 1018, 1074, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2942, 620, 'Lorenzo_Mp3', 487, 15550000, 0, 1, 'None', 98, 1000, 353.85, -1739.31, 5.547, 291.215, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2943, 633, 'Za3ima_Aya', 545, 350000, 0, 0, 'None', 98, 991, 1137.34, -1413.51, 13.458, 359.357, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2944, 3158, 'trock_bangala', 426, 300000, 0, 1, 'None', 96, 1000, 956.039, -1369.16, 13.204, 90.554, 166, 0, -1, NULL, 0, 0, 18648, 1, 3, 1001, 1005, 1006, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2945, 3158, 'trock_bangala', 549, 300000, 0, 1, 'None', 97, 971.442, 948.568, -1354.78, 13.021, 180.02, 198, 198, -1, NULL, 0, 0, 18652, 1, 3, 1023, 1012, 0, 0, 0, 1010, 1018, 1074, 0, 1087, 0, 0, 1144, 1145, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2946, 3661, 'ANDRENO_LMICROBE', 462, 25000, 0, 0, 'None', 95, 989.077, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2947, 894, 'TALIANI_WOLF', 549, 300000, 0, 1, 'HAYTAM', 98, 1000, 962.579, -1354.85, 13.021, 178.977, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 1003, 0, 0, 0, 0, 1010, 0, 1077, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2948, 2780, 'MAMADO_x', 474, 280000, 0, 0, 'None', 35, 622.391, 1113.14, -1379.07, 13.554, 7.295, 34, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2949, 3158, 'trock_bangala', 545, 350000, 0, 0, 'None', 98, 996, 1138.59, -1373.12, 13.637, 82.394, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2950, 3158, 'trock_bangala', 467, 280000, 0, 1, 'None', 100, 948.248, 956.69, -1359.77, 13.126, 86.294, 0, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1074, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2951, 3506, 'LFERDA___', 458, 280000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2952, 3654, 'sfa7_vip', 580, 300000, 0, 1, 'None', 100, 300, 1233.4, -1377.8, 12.926, 322.436, 198, 0, -1, NULL, 0, 0, 18648, 1, 0, 1001, 0, 1006, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2953, 3147, 'Nabil_Vinsmoke', 533, 400000, 0, 0, 'None', 84, 1000, 550.735, -1266.96, 16.9693, 215.44, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2954, 3147, 'Nabil_Vinsmoke', 551, 300000, 0, 1, 'None', 100, 969.144, 1222.15, -1362.47, 12.97, 264.347, 6, 6, -1, NULL, 0, 0, 18651, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2955, 3648, 'adel_med', 576, 330000, 0, 1, 'None', 100, 974.522, 1218.94, -1419.96, 12.808, 3.475, 0, 0, 2, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2956, 2780, 'MAMADO_x', 555, 450000, 0, 1, 'None', 99, 1000, 963.073, -1371.66, 13.015, 181.232, 1, 1, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2957, 427, 'BO9AL_V2', 589, 270000, 0, 1, 'None', 99, 980.761, 185.12, -1455.25, 12.863, 37.065, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2958, 1973, 'PECASO_XM8', 586, 50000, 0, 0, 'None', 95, 935, 1089.56, -1387.31, 13.279, 205.658, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2959, 3525, 'YOUSSF_PIDRO', 579, 3100000, 0, 1, 'None', 87, 896.182, 550.735, -1266.96, 16.9693, 215.44, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2960, 3324, 'Ilyass_Crocodile', 521, 1200000, 0, 0, 'None', 62, 1000, 550.735, -1266.96, 16.9693, 215.44, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2961, 2174, 'vergas__', 550, 300000, 0, 1, 'None', 99, 999, 1110.63, -1392.51, 13.262, 94.231, 1, 1, -1, NULL, 0, 0, 18647, 1, 3, 1003, 1005, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 1142, 1143, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2962, 1761, 'I_NAMOSE', 555, 450000, 0, 0, 'None', 100, 1000, 338.241, -1808.36, 4.21, 182.544, 102, 29, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2963, 620, 'Lorenzo_Mp3', 555, 450000, 0, 1, 'None', 100, 986.557, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2964, 620, 'Lorenzo_Mp3', 536, 3500000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2965, 3682, 'REDA_6', 471, 70000, 0, 1, 'None', 100, 945.302, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2966, 3645, 'TANJERO_BLACK', 560, 5500000, 0, 1, 'None', 100, 591.808, 550.735, -1266.96, 16.9693, 215.44, 175, 175, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2967, 498, 'mo_rad', 560, 5500000, 0, 1, 'None', 100, 984.457, 859.333, -1532.44, 13.218, 267.088, 1, 1, 1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 0, 1079, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2968, 621, 'ADAM_KLLER', 560, 5500000, 0, 0, 'None', 82, 978, 955.425, -1387.61, 13.027, 43.261, 3, 3, 1, NULL, 0, 0, 18647, 1, 3, 1138, 0, 1032, 1027, 0, 1010, 1028, 1077, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2969, 3341, 'idriss_bishop', 492, 270000, 0, 0, 'None', 100, 976, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2970, 2933, 'X25_YASSINE', 589, 270000, 0, 0, 'None', 100, 919.28, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2971, 2933, 'X25_YASSINE', 589, 270000, 0, 0, 'None', 100, 968.124, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2972, 3641, 'yessin_9os', 522, 10000000, 0, 0, 'None', 66, 1000, 1231.55, -938.442, 42.083, 279.947, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2973, 3583, 'GOKU_VGS', 521, 1200000, 0, 0, 'None', 90, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2974, 3682, 'REDA_6', 436, 250000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2975, 1785, 'carlos_bertone', 461, 1000000, 0, 1, 'None', 93, 623.847, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2976, 3642, 'imbahlel_9om', 522, 10000000, 0, 0, 'None', 84, 628.82, 1273.82, -1404.62, 12.599, 274.578, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2977, 2780, 'MAMADO_x', 579, 3100000, 0, 1, 'None', 96, 999.166, 963.247, -1378, 13.203, 176.432, 1, 1, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2978, 3504, 'JNXx___', 541, 9000000, 0, 0, 'None', 75, 1000, 1271.56, -1410.39, 12.744, 271.144, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1079, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2979, 3654, 'sfa7_vip', 560, 5500000, 0, 0, 'None', 90, 576.764, 1223.74, -1426.29, 13.055, 353.849, 1, 1, 1, NULL, 0, 0, 18647, 1, 3, 1139, 0, 1032, 1027, 0, 1010, 1029, 1074, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2980, 2049, 'L3ALAWI_STREX', 549, 300000, 0, 1, 'None', 99, 629.331, 1222.16, -1419.92, 12.948, 359.848, 200, 200, -1, NULL, 0, 0, 18647, 1, 3, 1003, 1012, 0, 0, 0, 1010, 0, 1079, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2981, 2174, 'vergas__', 426, 300000, 0, 1, 'None', 79, 861.908, 1116.41, -1391.88, 13.159, 106.033, 0, 0, -1, NULL, 0, 0, 18647, 1, 3, 1003, 1005, 1006, 0, 0, 1010, 0, 1076, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2982, 3147, 'Nabil_Vinsmoke', 426, 300000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2983, 3147, 'Nabil_Vinsmoke', 580, 300000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2984, 3147, 'Nabil_Vinsmoke', 576, 330000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2985, 3715, 'RAYAN_GANG', 589, 270000, 0, 1, 'None', 90, 992.349, 2102.15, -1777.4, 13.051, 91.775, 1, 1, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2986, 3601, '_TOBA', 560, 5500000, 0, 1, 'None', 100, 987, 1116.94, -1358.69, 13.567, 314.343, 3, 3, 3, NULL, 0, 0, 18649, 1, 3, 1138, 0, 1032, 0, 0, 1010, 0, 1079, 0, 1087, 1169, 1141, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2987, 498, 'mo_rad', 586, 50000, 0, 0, 'None', 100, 920.67, 549.886, -1270.58, 16.762, 69.097, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2988, 3601, '_TOBA', 586, 50000, 0, 0, 'None', 77, 740.835, 550.781, -1266.96, 16.757, 213.451, 175, 175, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2989, 0, 'Nobody', 470, 0, 0, 0, 'None', 100, 1000, -551.845, -503.321, 25.514, 180.452, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, -1, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2990, 0, 'Nobody', 470, 0, 0, 0, 'None', 100, 1000, -544.872, -503.232, 25.553, 177.132, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, -1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2991, 0, 'Nobody', 470, 0, 0, 0, 'None', 100, 1000, -539.359, -503.956, 25.492, 170.717, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, -1, 10000000, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2992, 3147, 'Nabil_Vinsmoke', 545, 350000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2993, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1214.26, -1309.72, 13.152, 72.983, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2994, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1214.27, -1310.51, 13.151, 72.983, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2995, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1214.28, -1311.31, 13.154, 72.983, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2996, 0, 'Nobody', 462, 0, 0, 0, 'None', 100, 1000, 1214.29, -1312.1, 13.154, 72.984, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2997, 2675, 'SUPRA_VGS', 586, 50000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2998, 3629, 'JD_MAMADO', 551, 300000, 0, 0, 'None', 67, 251, 1865.84, -2594.8, 13.378, 353.171, 79, 79, -1, NULL, 0, 0, 18652, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 1081, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2999, 3687, 'zoro_1', 429, 9000000, 0, 1, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3000, 3641, 'yessin_9os', 429, 9000000, 0, 0, 'None', 100, 1000, 550.735, -1266.96, 16.9693, 215.44, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `weapons`
--

CREATE TABLE `weapons` (
  `uid` int DEFAULT NULL,
  `slot` tinyint DEFAULT NULL,
  `weaponid` tinyint DEFAULT NULL,
  `ammo` smallint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `anticheat_settings`
--
ALTER TABLE `anticheat_settings`
  ADD UNIQUE KEY `ac_code` (`ac_code`);

--
-- Index pour la table `atms`
--
ALTER TABLE `atms`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `bans`
--
ALTER TABLE `bans`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `billboards`
--
ALTER TABLE `billboards`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `changes`
--
ALTER TABLE `changes`
  ADD UNIQUE KEY `slot` (`slot`);

--
-- Index pour la table `charges`
--
ALTER TABLE `charges`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `clothing`
--
ALTER TABLE `clothing`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `divisions`
--
ALTER TABLE `divisions`
  ADD UNIQUE KEY `id` (`id`,`divisionid`);

--
-- Index pour la table `entrances`
--
ALTER TABLE `entrances`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `factionlockers`
--
ALTER TABLE `factionlockers`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `factionpay`
--
ALTER TABLE `factionpay`
  ADD UNIQUE KEY `id` (`id`,`rank`);

--
-- Index pour la table `factionranks`
--
ALTER TABLE `factionranks`
  ADD UNIQUE KEY `id` (`id`,`rank`);

--
-- Index pour la table `factions`
--
ALTER TABLE `factions`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `factionskins`
--
ALTER TABLE `factionskins`
  ADD UNIQUE KEY `id` (`id`,`slot`);

--
-- Index pour la table `flags`
--
ALTER TABLE `flags`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `furniture`
--
ALTER TABLE `furniture`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `gangranks`
--
ALTER TABLE `gangranks`
  ADD UNIQUE KEY `id` (`id`,`rank`);

--
-- Index pour la table `gangs`
--
ALTER TABLE `gangs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `gangskins`
--
ALTER TABLE `gangskins`
  ADD UNIQUE KEY `id` (`id`,`slot`);

--
-- Index pour la table `garages`
--
ALTER TABLE `garages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `gates`
--
ALTER TABLE `gates`
  ADD PRIMARY KEY (`gateID`);

--
-- Index pour la table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `kills`
--
ALTER TABLE `kills`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `landobjects`
--
ALTER TABLE `landobjects`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `lands`
--
ALTER TABLE `lands`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_admin`
--
ALTER TABLE `log_admin`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_bans`
--
ALTER TABLE `log_bans`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_cheat`
--
ALTER TABLE `log_cheat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_contracts`
--
ALTER TABLE `log_contracts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_faction`
--
ALTER TABLE `log_faction`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_gang`
--
ALTER TABLE `log_gang`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_give`
--
ALTER TABLE `log_give`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_namechanges`
--
ALTER TABLE `log_namechanges`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_property`
--
ALTER TABLE `log_property`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_punishments`
--
ALTER TABLE `log_punishments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_referrals`
--
ALTER TABLE `log_referrals`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_vip`
--
ALTER TABLE `log_vip`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `object`
--
ALTER TABLE `object`
  ADD PRIMARY KEY (`mobjID`);

--
-- Index pour la table `phonebook`
--
ALTER TABLE `phonebook`
  ADD UNIQUE KEY `number` (`number`);

--
-- Index pour la table `phone_contacts`
--
ALTER TABLE `phone_contacts`
  ADD PRIMARY KEY (`contact_id`);

--
-- Index pour la table `points`
--
ALTER TABLE `points`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `shots`
--
ALTER TABLE `shots`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `speedcameras`
--
ALTER TABLE `speedcameras`
  ADD PRIMARY KEY (`speedID`);

--
-- Index pour la table `texts`
--
ALTER TABLE `texts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `turfs`
--
ALTER TABLE `turfs`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- Index pour la table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `weapons`
--
ALTER TABLE `weapons`
  ADD UNIQUE KEY `uid` (`uid`,`slot`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `atms`
--
ALTER TABLE `atms`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `bans`
--
ALTER TABLE `bans`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `billboards`
--
ALTER TABLE `billboards`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `charges`
--
ALTER TABLE `charges`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `clothing`
--
ALTER TABLE `clothing`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `entrances`
--
ALTER TABLE `entrances`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT pour la table `factionlockers`
--
ALTER TABLE `factionlockers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT pour la table `flags`
--
ALTER TABLE `flags`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `furniture`
--
ALTER TABLE `furniture`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `gangs`
--
ALTER TABLE `gangs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `garages`
--
ALTER TABLE `garages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT pour la table `gates`
--
ALTER TABLE `gates`
  MODIFY `gateID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT pour la table `houses`
--
ALTER TABLE `houses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=405;

--
-- AUTO_INCREMENT pour la table `kills`
--
ALTER TABLE `kills`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `landobjects`
--
ALTER TABLE `landobjects`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `lands`
--
ALTER TABLE `lands`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_admin`
--
ALTER TABLE `log_admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_bans`
--
ALTER TABLE `log_bans`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_cheat`
--
ALTER TABLE `log_cheat`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_contracts`
--
ALTER TABLE `log_contracts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_faction`
--
ALTER TABLE `log_faction`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_gang`
--
ALTER TABLE `log_gang`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_give`
--
ALTER TABLE `log_give`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_namechanges`
--
ALTER TABLE `log_namechanges`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_property`
--
ALTER TABLE `log_property`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_punishments`
--
ALTER TABLE `log_punishments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_referrals`
--
ALTER TABLE `log_referrals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `log_vip`
--
ALTER TABLE `log_vip`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `object`
--
ALTER TABLE `object`
  MODIFY `mobjID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `phone_contacts`
--
ALTER TABLE `phone_contacts`
  MODIFY `contact_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `shots`
--
ALTER TABLE `shots`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `speedcameras`
--
ALTER TABLE `speedcameras`
  MODIFY `speedID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `texts`
--
ALTER TABLE `texts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3001;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
